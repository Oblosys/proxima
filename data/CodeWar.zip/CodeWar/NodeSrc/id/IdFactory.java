package skit.id ;

import skit.factory.* ;

public abstract class IdFactory
	implements Factory
{
	private final static String categ = "id" ;
	
	/**
	 * @see skit.factory.Factory
	 */
	public String getCategoryName()
	{
		return categ ;
	}
	
}