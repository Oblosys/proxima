package skit.id ;

import java.util.Enumeration ;

/**
 * An identifier to be used in any identification scheme.
 * An identifier always is considered to be part of another one, hierarchically.
 */
public abstract class Id extends skit.data.BasicSSpecialReadWritable
//	implements java.io.Serializable
{
	public Id()
	{
	}
	
	/**
	 * The representation as a string.
	 * A appropriate factory can reproduce the right Id for it.
	 *
	 * @see ????
	 */
	public String stringRepr()
	{
		Id parent = parentId() ;
		return ( ( parent != null ) ? parent.stringRepr() : "" )
					+ "/" + myStringRepr() ;
	}
	
	/**
	 * The representation as a string of the part administered here.
	 * Meant to be overridden.
	 * 
	 */
	protected abstract String myStringRepr() ;
	
	/**
	 * The hashcode.
	 */
	public int hashCode()
	{
		Id parent = parentId() ;
		return ( ( parent != null ) ? parent.hashCode() : 0 ) ^ myHashCode() ;
	}
	
	/**
	 * The hashcode of the part administered here.
	 * Meant to be overridden.
	 * 
	 */
	protected abstract int myHashCode() ;
	
	/**
	 * @return the parent id, or null if no parent.
	 */
	public Id parentId()
	{
		return null ;
	}
	
	/**
	 * @return Enumeration of ids, starting with this, then the parents.
	 */
	public Enumeration ids()
	{
		return new ParentEnumeration( this ) ;
	}
	
	public void appendStringRepr( StringBuffer buf )
	{
		buf.append( stringRepr() ) ;
	}
	
	/*
	public String toString()
	{
		return stringRepr() ;
	}
	*/
	
	public boolean equals( Object o )
	{
		boolean res = ( o instanceof Id ) ;
		if ( res )
		{
			Id id = (Id)o ;
			Id parent = parentId() ;
			res = myEquals( id ) ;
			if ( res && parent != null )
				res = parent.equals( id.parentId() ) ;
		}
		return res ;
	}
	
	/**
	 * The equals test of the part administered here.
	 * Meant to be overridden.
	 * 
	 */
	protected abstract boolean myEquals( Id id ) ;
	
}

class ParentEnumeration
	implements Enumeration
{
	private Id id ;
	
	public ParentEnumeration( Id id )
	{
		this.id = id ;
	}
	
	public boolean hasMoreElements()
	{
		return id != null ;
	}
	
	public Object nextElement()
	{
		Object res = id ;
		if ( hasMoreElements() )
			id = id.parentId() ;
		return res ;
	}
}