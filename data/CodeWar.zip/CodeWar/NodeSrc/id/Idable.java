package skit.id ;

/**
 * Something which can be retrieved/identified via an id.
 */
public interface Idable
{
	/**
	 * Get the id.
	 */
	public Id getId() ;
	
	/**
	 * Make sure the value is available
	 */
	//void use()
	//	throws skit.SkitIOException ;
	
	/**
	 * Set the id of the Idable.
	 */
	public void setId( Id id ) ;
	
}