package skit.id ;

import java.net.* ;
import java.util.* ;
import java.io.* ;
import skit.* ;
import skit.util.* ;
import skit.data.* ;
import skit.data.value.* ;
import com.objectspace.jgl.* ;
import com.objectspace.jgl.adapters.* ;

/**
 * A UniqueId is guaruanteed to be unique,
 * with respect to location and time.
 * This is accomplished by using information like internet location and current time.
 * This information is put into a sequence of ints which also
 * has as a header contained the version, size, etc, thus catering for future
 * changes an backwards compatibility.
 */
public class UniqueId extends Id
//	implements SValueable
{
	/**
	 * The current version of this identifier mechanism.
	 */
	public static final int ID_VERSION = 1 ;
	
	// system const
	private static final int BITS_PER_INT = 32 ;
	
	// this may never change
	private static final int DEFAULT_HEADER_INX = 0 ;
	private static final int DEFAULT_HEADER_LEN = 1 ;
	private static final int NR_HEADER_FIELDS = 6 ;
	//private static final int NR_HEADER_FIELDS = 6 ;
	
	private static int[] headerFieldPositions ;
	private static int[] headerFieldSizes ;
	
	private static final int HEADER_TOTAL = 0 ;
	private static final int HEADER_VERSION = 1 ;
	private static final int HEADER_HEADER = 2 ;
	private static final int HEADER_MACHINE = 3 ;
	private static final int HEADER_TIME = 4 ;
	private static final int HEADER_COUNTER = 5 ;
	//private static final HEADER_FUTURE = 6 ;
	private static final int FIRST_SUMMABLE_HEADER_FIELD = HEADER_HEADER ;
	private static final int LAST_SUMMABLE_HEADER_FIELD = HEADER_COUNTER ;
	
	// the values (in the header) may change, are encoded in the header.
	private static int[] headerDefaultValues ;

	private static void adjustDefaultFieldPositions()
	{
		for ( int i = 0, pos = 0 ; i < NR_HEADER_FIELDS ; i++ )
		{
			headerFieldPositions[ i ] = pos ;
			pos += headerFieldSizes[ i ] ;
		}
	}
	
	private static void dumpDefaultHeaderInfo()
	{
		for ( int i = 0 ; i < headerFieldPositions.length ; i++ )
		{
			//System.out.println( "DMP " + headerFieldPositions[ i ] + "/" + headerFieldSizes[ i ] + "/" + headerDefaultValues[ i ] ) ;
		}
	}
	
	private static int sumOfDefaultValues( int fromInx, int toInx )
	{
		int sum = 0 ;
		for ( int i = fromInx ; i <= toInx ; i++ )
		{
			sum += getDefaultSize( i ) ;
		}
		return sum ;
	}
	
	private static void setDefaultFieldInfo( int field, int size, int value )
	{
		headerFieldSizes[ field ] = size ;
		setDefaultSize( field, value ) ;
	}
	
	private static int getDefaultFieldPos( int field )
	{
		return headerFieldPositions[ field ] ;
	}
	
	private static int getDefaultFieldSize( int field )
	{
		return headerFieldSizes[ field ] ;
	}
	
	private static int encode( int i )
	{
		return i-1 ;
	}
	
	private static int decode( int i )
	{
		return i+1 ;
	}
	
	private static int getDefaultSize( int field )
	{
		//return decode( headerDefaultValues[ field ] ) ;
		return headerDefaultValues[ field ] ;
	}
	
	private static void setDefaultSize( int field, int value )
	{
		//headerDefaultValues[ field ] = encode( value ) ;
		headerDefaultValues[ field ] = ( value ) ;
	}
	
	private static int mask( int nrOfBits )
	{
		return  ( 1 << nrOfBits ) - 1 ;
	}
	
	private static int getDefaultFieldMask( int field )
	{
		return mask( getDefaultFieldSize( field ) ) ;
	}
	
	private static int extractHeaderField( int header, int field )
	{
		int res ;
		//System.out.println( "EXTR HD " + hex(header) + "/" + field ) ;
		res = decode( ( header >> getDefaultFieldPos( field ) ) & getDefaultFieldMask( field ) ) ;
		//System.out.println( "EXTR'd HD " + hex(header) + "/" + field + "/"  + hex(res) ) ;
		return res ;
	}
	
	private static int updatedHeaderWithField( int header, int field, int value )
	{
		int res ;
		//System.out.println( "UPD HD " + hex(header) + "/" + field + "/"  + value ) ;
		res = header | ( ( encode( value ) & getDefaultFieldMask( field ) ) << getDefaultFieldPos( field ) ) ;
		//System.out.println( "UPD'd HD " + hex(res) + "/" + field + "/"  + value ) ;
		return res ;
	}
	
	static
	{
		headerFieldPositions = new int[ NR_HEADER_FIELDS ] ;
		headerFieldSizes = new int[ NR_HEADER_FIELDS ] ;
		headerDefaultValues = new int[ NR_HEADER_FIELDS ] ;
		setDefaultFieldInfo( HEADER_VERSION, 4, ID_VERSION ) ;
		setDefaultFieldInfo( HEADER_HEADER, 2, DEFAULT_HEADER_LEN ) ;
		setDefaultFieldInfo( HEADER_MACHINE, 4, 1 ) ;
		setDefaultFieldInfo( HEADER_TIME, 3, 2 ) ;
		setDefaultFieldInfo( HEADER_COUNTER, 2, 1 ) ;
		//setDefaultFieldInfo( HEADER_FUTURE, 9, 0 ) ;
		setDefaultFieldInfo( HEADER_TOTAL, 8, sumOfDefaultValues( FIRST_SUMMABLE_HEADER_FIELD, LAST_SUMMABLE_HEADER_FIELD ) ) ;
		adjustDefaultFieldPositions() ;
		dumpDefaultHeaderInfo() ;
	}
	
	private static int theHeader = 0 ;
	
	private static int getDefaultHeader()
	{
		if ( theHeader == 0 )
		{
			int header = 0 ;
			header = updatedHeaderWithField( header, HEADER_VERSION, getDefaultSize( HEADER_VERSION ) ) ;
			header = updatedHeaderWithField( header, HEADER_HEADER, getDefaultSize( HEADER_HEADER ) ) ;
			header = updatedHeaderWithField( header, HEADER_TOTAL, getDefaultSize( HEADER_TOTAL ) ) ;
			header = updatedHeaderWithField( header, HEADER_MACHINE, getDefaultSize( HEADER_MACHINE ) ) ;
			header = updatedHeaderWithField( header, HEADER_TIME, getDefaultSize( HEADER_TIME ) ) ;
			header = updatedHeaderWithField( header, HEADER_COUNTER, getDefaultSize( HEADER_COUNTER ) ) ;
			theHeader = header ;
		}
		return theHeader ;
	}
		
	private static final int ILLEGAL_MACHINE = -1 ;
	private static final int NO_MACHINE = 0 ;
	
	// ???? private InetAddress machine ;
	private static int machine = ILLEGAL_MACHINE ;
	
	private int[] idParts ;
	private long time ;
	private int count ;
	
	/**
	 * The counter just counts, to guaruantee uniques within the granularity of system time.
	 * A prime is used to spread the values evenly, which is necessary for hashing.
	 */
	private static int counter = 1 ;
	
	private static final int counterPrime = 91 ;
	
	protected UniqueId( int m, long t, int c )
	{
		idParts = new int[ getDefaultSize( HEADER_TOTAL ) ] ;
		//System.out.println( "DEF SIZ " + getDefaultSize( HEADER_TOTAL ) ) ;
		setHeader( getDefaultHeader() ) ;
		setPart( HEADER_MACHINE, m ) ;
		setPart( HEADER_TIME, t ) ;
		setPart( HEADER_COUNTER, c ) ;
	}
	
	/**
	 * This constructor should be declared private,
	 * should not be used therefore.
	 * Persistency however requires the possibility of making a new instance in this way.
	 */
	public UniqueId()
	{
		//this( getMachine(), getTime(), getCounter() ) ;
	}
	
	public UniqueId( int machId )
	{
		this( machId, getTime(), getCounter() ) ;
	}
	
	protected void setParts( int pos, int len, long value )
	{
		//System.out.println( "SET PARTS " + pos + "/" + len + "/"  + hex(value) + "/"  + binary(value) ) ;
		for ( int i = pos + len -1 ; i >= pos ; i-- )
		{
			idParts[ i ] = (int)value ;
			value >>= BITS_PER_INT ;
		}
	}
	
	protected void setPart( int field, long value )
	{
		setParts( getPartPos( field ), getPartSize( field ), value ) ;
	}
	
	protected long getParts( int pos, int len )
	{
		long res = 0 ;
		int end = pos + len ;
		for ( ; pos < end ; pos++ )
		{
			res = ( res << BITS_PER_INT ) | ( (long)idParts[ pos ] & (((long)1 << BITS_PER_INT) - 1) ) ;
		}
		return res ;
	}
	
	protected long getPart( int field )
	{
		return getParts( getPartPos( field ), getPartSize( field ) ) ;
	}
	
	protected int getHeaderValue( int field )
	{
		return extractHeaderField( getHeader(), field ) ;
	}
	
	protected int getPartSize( int field )
	{
		return getHeaderValue( field ) ;
	}
	
	protected int getPartPos( int field )
	{
		int pos = 0 ;
		for ( int i = FIRST_SUMMABLE_HEADER_FIELD ; i < field ; i++ )
		{
			pos += getHeaderValue( i ) ;
		}
		//System.out.println( "GET PART POS " + field + "/" + pos ) ;
		return pos ;
	}
	
	protected void setHeader( int header )
	{
		setParts( DEFAULT_HEADER_INX, DEFAULT_HEADER_LEN, header ) ;
	}
	
	protected int getHeader()
	{
		return idParts[ DEFAULT_HEADER_INX ] ;
	}
	
	private static int getCounter()
	{
		return counter++ * counterPrime ;
	}
	
	private static long getTime()
	{
		return Timestamp.timestamp() ;
	}
	
	public static int getMachine()
	{
		if ( machine == ILLEGAL_MACHINE )
		{
			machine = NO_MACHINE ;
		}
		return machine ;
		//return new byte[4] ;
		/*
		try
		{
			count =  ;
			time =  ;
			machine =  ;
			//machine = InetAddress.getLocalHost() ;
		}
		catch( UnknownHostException e )
		{
		}
		catch( Exception e )
		{
			skit.log.Logger.log( "inet trouble", e ) ;
		}
		*/
	}
	
	private static String hex( long i )
	{
		return Long.toHexString( i ) ;
	}
	
	private static String binary( long i )
	{
		return Long.toBinaryString( i ) ;
	}
	
	private static String hex( int i )
	{
		return Integer.toHexString( i ) ;
	}
	
	private static final int REPR_HOW_READABLE = 0 ;
	private static final int REPR_HOW_PARTS = 1 ;
	private static final int REPR_HOW_INTS = 2 ;
	private static final int REPR_HOW_SVALUE = 3 ;
	
	/**
	 * Various ways of getting a string representation out of an id.
	 * 
	 */
	protected String myStringRepr( int how )
	{
		String res ;
		switch( how )
		{
			case REPR_HOW_PARTS :
				res = hex( getPart( HEADER_MACHINE ) ) + ":" + hex( getPart( HEADER_TIME ) ) + ":" + hex( getPart( HEADER_COUNTER ) ) ;
				break ;

			case REPR_HOW_READABLE :
				res = getPart( HEADER_MACHINE ) + ", " + new Date( getPart( HEADER_TIME ) ) + ", " + getPart( HEADER_COUNTER ) ;
				break ;

			case REPR_HOW_SVALUE :
				res = BasicSWritableWriter.toString( this ) ;
				break ;

			case REPR_HOW_INTS :
			default:
				StringBuffer buf ;
				buf = new StringBuffer( 40 ) ;
				buf.append( hex( idParts[ 0 ] ) ) ;
				for ( int i = 1 ; i < idParts.length ; i++ )
				{
					buf.append( ":" ) ;
					buf.append( hex( idParts[ i ] ) ) ;
				}
				res = buf.toString() ;
				break ;
		}
		return res ;
	}
	
	/**
	 * The representation as a string of the part administered here.
	 * Meant to be overridden.
	 * 
	 */
	protected String myStringRepr( )
	{
		//return myStringRepr( REPR_HOW_SVALUE ) + "\\" + myStringRepr( REPR_HOW_READABLE ) + "\\" + myStringRepr( REPR_HOW_PARTS ) + "\\" + myStringRepr( REPR_HOW_INTS ) ;
		return "[" + myStringRepr( REPR_HOW_READABLE ) + "]" ;
	}
	
	/**
	 * The hashcode of the part administered here.
	 * Meant to be overridden.
	 * 
	 */
	protected int myHashCode()
	{
		int h = idParts[ 0 ] ;
		for ( int i = 1 ; i < idParts.length ; i++ )
			h ^= idParts[ i ] ;
		return h ;
	}
	
	protected boolean equalParts( int[] idParts )
	{
		boolean res = idParts.length == this.idParts.length ;
		for( int i = idParts.length-1 ; res && i >= 0 ; i-- )
		{
			res = idParts[ i ] == this.idParts[ i ] ;
		}
		return res ;
	}
	
	/**
	 * The equals test of the part administered here.
	 * Meant to be overridden.
	 * 
	 */
	protected boolean myEquals( Id id )
	{
		UniqueId uid ;
		return ( id instanceof UniqueId )
			&& ( equalParts( ((UniqueId)id).idParts ) )
			;
	}
	
	private Enumeration idParts()
	{
		return new IntArray( idParts ).elements() ;
	}
	
	/**
	 * Fill already instantiated object with values from SReadableReader
	 * @return the filled readable or a suitable replacement for it.
	 */
	public SSpecialReadable fillWithSReadables( Enumeration in )
		throws IOException, SkitIOException
	{
		SInt len = (SInt)in.nextElement() ;
		idParts = new int[ len.intValue() ] ;
		int i = 0 ;
		for ( ; in.hasMoreElements() && i < idParts.length ; i++ )
		{
			SInt v = (SInt)in.nextElement() ;
			idParts[ i ] = v.intValue() ;
		}
		return super.fillWithSReadables( in ) ;
	}
	
	/**
	 * Write the info for the content on an appropriate writer.
	 */
	public void writeSpecialInfo( SWritableWriter out )
		throws SkitIOException, IOException
	{
		out.writeSWritables( getWriterSValues() ) ;
		super.writeSpecialInfo( out ) ;
	}

	/**
	 * Get all the svalues to be put on the writer.
	 */
	private Enumeration getWriterSValues( )
	{
		return 
			new EnumerationSequence
					( new OneEnumeration( new SInt( idParts.length ) )
					, new EnumerationTransformer( idParts(), new IntTransformer() )
					) ;
	}
	

	
}

class IntTransformer implements Transformer
{
	public IntTransformer()
	{
	}
	
	public Object transform( Object v )
	{
		return BasicSValue.newInt( ((Integer)v).intValue() ) ;
	}
}
