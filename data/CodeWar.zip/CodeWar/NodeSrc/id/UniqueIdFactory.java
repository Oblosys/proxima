package skit.id ;

import skit.factory.* ;

public class UniqueIdFactory extends IdFactory
{
	private final static String impl = "unique" ;
	private final static String paramDescr = "not used" ;
	
	public UniqueIdFactory()
	{
	}
	
	/**
	 * @see skit.factory.Factory
	 */
	public String getImplementationName()
	{
		return impl ;
	}
	
	/**
	 * @see skit.factory.Factory
	 */
	public String getParamDescr()
	{
		return paramDescr ;
	}
	
	/**
	 * @see skit.factory.Factory
	 */
	public Object makeIt( Object param )
		throws skit.SkitException
	{
		return new UniqueId( UniqueId.getMachine() ) ;
	}
	
}