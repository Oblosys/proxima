package skit.lang ;

public interface TokenPredicate
{
	/**
	 * Check if a character satisfies a predicate
	 */
	public boolean satisfies( int ch ) ;

}