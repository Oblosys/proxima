package skit.lang ;

/**
 * Token represents a token read from input by TokenReader
 * @see skit.lang.TokenReader
 */
public class Token
{
	public static final int TOKEN_NUMBER = 0 ;
	public static final int TOKEN_CHAR = 1 ;
	public static final int TOKEN_STR = 2 ;
	public static final int TOKEN_ID = 3 ;
	public static final int TOKEN_DELIM = 4 ;
	public static final int TOKEN_EOF = 5 ;
	
	private static final Token eof = new Token( TOKEN_EOF ) ;
	
	public int kind ;
	public Object value ;
	
	public Token( int kind )
	{
		this.kind = kind ;
		value = null ;
	}
	
	public Token( int kind, String str )
	{
		this( kind ) ;
		value = str ;
	}
	
	public Token( String str )
	{
		this( TOKEN_STR, str ) ;
	}
	
	public Token( Number i )
	{
		this( TOKEN_NUMBER ) ;
		value = i ;
	}
	
	public Token( char ch )
	{
		this( TOKEN_CHAR ) ;
		value = new Character( ch ) ;
	}
	
	public static Token eof()
	{
		return eof ;
	}
	
	public boolean equalsEof()
	{
		return this.kind == TOKEN_EOF ;
	}
	
	public boolean isChar()
	{
		return this.kind == TOKEN_CHAR ;
	}
	
	public boolean isId()
	{
		return this.kind == TOKEN_ID ;
	}
	
	public boolean isStr()
	{
		return this.kind == TOKEN_STR ;
	}
	
	public boolean isNum()
	{
		return this.kind == TOKEN_NUMBER ;
	}
	
	public char charValue()
	{
		return ((Character)value).charValue() ;
	}
	
	public String strValue()
	{
		return ((String)value) ;
	}
	
	public long longValue()
	{
		return ((Long)value).longValue() ;
	}
	
	public boolean equals( char ch )
	{
		if ( isChar() )
			return ch == charValue() ;
		else if ( isId() )
		{
			String s = strValue() ;
			return s.length() == 1 && ch == s.charAt( 0 ) ;
		}
		else
			return false ;
	}
	
	public String toString()
	{
		return "TOK " + kind + ": " + value ;
	}
	
}