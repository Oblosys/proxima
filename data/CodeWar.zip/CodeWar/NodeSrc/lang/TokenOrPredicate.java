package skit.lang ;

/**
 * Or combination of 2 predicates
 */
public class TokenOrPredicate implements TokenPredicate
{
	private TokenPredicate pred1 ;
	private TokenPredicate pred2 ;
	
	public TokenOrPredicate( TokenPredicate p1, TokenPredicate p2 )
	{
		pred1 = p1 ;
		pred2 = p2 ;
	}
	
	/**
	 * Check if a character satisfies a predicate
	 */
	public boolean satisfies( int ch )
	{
		return pred1.satisfies( ch ) || pred2.satisfies( ch ) ;
	}

}