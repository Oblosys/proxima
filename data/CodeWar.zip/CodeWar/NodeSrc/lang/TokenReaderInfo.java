package skit.lang ;

import java.io.* ;

/**
 * Info meant for the TokenReader.
 * @see skit.lang.TokenReader
 */
public class TokenReaderInfo
{
	public String whiteSpace ;
	public char lineSep ;
	//public String singles ;
	public TokenPredicate isIdSingle ;
	public char stringQuote ;
	public char stringEscape ;
	public char commentStart ;
	public char commentEnd ;
	public TokenPredicate isIdFirst ;
	public TokenPredicate isId ;
	public TokenPredicate isNrPrefix ;
	public TokenPredicate isNrFirst ;
	public TokenPredicate isNr ;
	
	public TokenReaderInfo
		( String whiteSpace
		, char lineSep
		//, String singles
		, TokenPredicate isIdSingle
		, char stringQuote
		, char stringEscape
		, char commentStart
		, char commentEnd
		, TokenPredicate isIdFirst
		, TokenPredicate isId
		, TokenPredicate isNrPrefix
		, TokenPredicate isNrFirst
		, TokenPredicate isNr
		)
	{
		this.whiteSpace = whiteSpace ;
		this.lineSep = lineSep ;
		//this.singles = singles ;
		this.isIdSingle = isIdSingle ;
		this.stringQuote = stringQuote ;
		this.stringEscape = stringEscape ;
		this.commentStart = commentStart ;
		this.commentEnd = commentEnd ;
		this.isIdFirst = isIdFirst ;
		this.isId = isId ;
		this.isNrPrefix = isNrPrefix ;
		this.isNrFirst = isNrFirst ;
		this.isNr = isNr ;
	}
	

}