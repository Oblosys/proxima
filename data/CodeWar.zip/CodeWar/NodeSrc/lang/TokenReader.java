package skit.lang ;

import java.io.* ;
import skit.util.* ;
import skit.* ;
import com.objectspace.jgl.* ;

/**
 * General purpose class for retrieving tokens from a Reader
 */
public class TokenReader implements IOBehavior
{
	private static final int READ_BUF_LEN = 10 ;
	
	private static final int S_NORMAL = 0 ;
	private static final int S_COMMENT = 1 ;
	private static final int S_NUMBER = 2 ;
	private static final int S_STRING = 3 ;
	private static final int S_STRING_ESC = 4 ;
	private static final int S_ID = 5 ;
	private static final int S_UNKNOWN = 6 ;
	
	private static final int EOF = -1 ;

	private PushbackReader in ;
	private TokenReaderInfo info ;
	
	private int lineNr ;
	private int ch ;
	private Token token ;
	private int state ;
	private StringBuffer buf ;
	private Sequence lookAhead ;
	
	private char[] readBuf = new char[ READ_BUF_LEN ] ;
	private int readBufPos = 0 ;
	
	public TokenReader( Reader in, TokenReaderInfo info )
	{
		this.in = new PushbackReader( in ) ;
		this.info = info ;
		lineNr = 1 ;
		token = null ;
		state = S_NORMAL ;
		lookAhead = new Deque() ;
		try
		{
			stepChar() ;
		}
		catch ( IOException e )
		{
			skit.log.Logger.log( "error in token reader", e ) ;
		}
	}
	
	private boolean isA( int what )
	{
		return what == ch ;
	}
	
	private boolean isA( String what )
	{
		return what.indexOf( (char)ch ) >= 0 ;
	}
	
	private void resetBuf()
	{
		buf = new StringBuffer() ;
	}
	
	private int stepChar()
		throws IOException
	{
		ch = in.read() ;
		readBuf[ readBufPos++ % READ_BUF_LEN ] = (char)ch ;
		//System.out.println( "READ CH TOK: " + (char)ch ) ;
		return ch ;
	}
	
	private int lookAheadChar()
		throws IOException
	{
		int c = in.read() ;
		in.unread( c ) ;
		return c ;
	}
	
	private boolean atEof()
	{
		return ch == EOF && lookAhead.size() == 0 ;
	}
	
	private void append( int c )
	{
		buf.append( (char) c ) ;
	}
	
	/**
	 * Get the lookahead where positions in the future.
	 */
	private Token getLookAhead( int where )
		throws IOException
	{
		for ( ; where < lookAhead.size() ; )
		{
			lookAhead.pushBack( stepToken() ) ;
		}
		return (Token)lookAhead.at( where ) ;
	}
	
	/**
	 * Get the lookahead
	 */
	public Token getLookAhead()
		throws IOException
	{
		return getLookAhead( 0 ) ; 
	}
	
	/**
	 * Advance one token.
	 */
	public Token stepToken()
		throws IOException
	{
		if ( lookAhead.size() > 0 )
			return token = (Token)lookAhead.popFront() ;
		
		for ( ; true ; stepChar() )
		{
			if ( ch == EOF && state == S_NORMAL )
			{
				return token = Token.eof() ;
			}
			
			if ( isA( info.lineSep ) )
				lineNr++ ;
			
			switch ( state )
			{
				case S_NORMAL :
					if ( isA( info.commentStart ) )
					{
						state = S_COMMENT ;
					}
					else if ( isA( info.stringQuote ) )
					{
						state = S_STRING ;
						resetBuf() ;
					}
					else if (  info.isNrFirst.satisfies( ch )
							|| ( info.isNrPrefix.satisfies( ch ) && info.isNrFirst.satisfies( lookAheadChar() ) )
							)
					{
						state = S_NUMBER ;
						resetBuf() ;
						append( ch ) ;
					}
					else if ( info.isIdSingle.satisfies( ch ) )
					{
						token = new Token( Token.TOKEN_ID, String.valueOf( (char)ch ) ) ;
						stepChar() ;
						return token ;
					}
					else if ( info.isIdFirst.satisfies( ch ) )
					{
						state = S_ID ;
						resetBuf() ;
						append( ch ) ;
					}
					else if ( ! isA( info.whiteSpace ) )
					{
						token = new Token( (char)ch ) ;
						stepChar() ;
						return token ;
					}
					break ;
					
				case S_COMMENT :
					if ( isA( info.commentEnd ) || atEof() )
						state = S_NORMAL ;
					break ;
					
				case S_STRING :
					if ( isA( info.stringQuote ) || atEof() )
					{
						state = S_NORMAL ;
						stepChar() ;
						return token = new Token( buf.toString() ) ;
					}
					else if ( isA( info.stringEscape ) )
					{
						state = S_STRING_ESC ;
					}
					else
					{
						append( ch ) ;
					}
					break ;
					
				case S_STRING_ESC :
					switch ( ch ) // ???? should be made more generic
					{
						case 'n' : ch = '\n' ; break ;
						case 'r' : ch = '\r' ; break ;
						case 't' : ch = '\t' ; break ;
						default : break ;
					}
					state = S_STRING ;
					append( ch ) ;
					break ;
					
				case S_ID :
					if ( ! info.isId.satisfies( ch ) || atEof() )
					{
						state = S_NORMAL ;
						return token = new Token( Token.TOKEN_ID, buf.toString() ) ;
					}
					else
					{
						append( ch ) ;
					}
					break ;
					
				case S_NUMBER :
					// should be made fit for numbers in general
					if ( ! info.isNr.satisfies( ch ) || atEof() )
					{
						state = S_NORMAL ;
						return token = new Token( new Long( buf.toString() ) ) ;
					}
					else
					{
						append( ch ) ;
					}
					break ;
					
				default :
					break ;
					
			}
		}
	}
	
	/**
	 * Get the current read token.
	 */
	public Token getCurrentToken()
	{
		if ( lookAhead.size() > 0 )
			return (Token)lookAhead.front() ;
		else
			return token ;
	}
	
	public int getLineNr()
	{
		// ???? take lookahead into account...
		return lineNr ;
	}
	
	private String getReadBufStr()
	{
		int pos = readBufPos % READ_BUF_LEN ;
		int pos1 = (readBufPos-1) % READ_BUF_LEN ;
		return
				( ( readBufPos >= READ_BUF_LEN ) ? new String( readBuf, pos, READ_BUF_LEN-pos ) : "" )
			+	new String( readBuf, 0, pos1 ) ;
	}
	
	/**
	 * Flush data, but do not close.
	 */
	public void flush()
		throws IOException, SkitIOException
	{
	}
	
	/**
	 * Flush data and close.
	 */
	public void close()
		throws IOException, SkitIOException
	{
		in.close() ;
	}
	
	public String toString()
	{
		return "line " + getLineNr() + " [" + getReadBufStr() + "][" + (char)ch + "] " + getCurrentToken() ;
	}
}