import skit.* ;
import skit.id.* ;
import skit.util.* ;
import skit.data.* ;
import skit.change.* ;
import skit.data.content.* ;
import skit.data.node.* ;
import skit.data.store.* ;
import skit.data.relation.* ;
//import skit.value.* ;
//import skit.value.type.* ;
import skit.factory.* ;
import skit.data.value.* ;
import skit.wrap.* ;
import java.io.* ;

public class NodeTest
{
	public static void main( String args[] )
	{
		System.out.println( "---------------------- SKIT TEST ----------------------" ) ;
		try
		{
			Setup.init( new StoreProgress() ) ;
			
			// registry
			/*
			Registry reg = new TreeRegistry( "test", "/", true, false ) ;
			reg.register( "aap", new Integer( 4 ) ) ;
			reg.register( "noot", new Integer( 5 ) ) ;
			System.out.println( "REG " + reg ) ;
			reg = new TreeRegistry( "test", "/", true, false ) ;
			reg.register( "aap/noot", new Integer( 44 ) ) ;
			reg.register( "aap/mies", new Integer( 55 ) ) ;
			reg.registerAsDefault( "aap", new Integer( 66 ) ) ;
			System.out.println( "REG " + reg ) ;
		
			// system mime registries
			System.out.println( Globals.getSValueMimeRegistry() ) ;
			System.out.println( Globals.getSWritableMimeRegistry() ) ;
			//System.out.println( Globals.getRefMimeRegistry() ) ;
			*/

			Object ids[] = new Object[ 2 ] ;
			/*
			for( int i = 0 ; i < 2 ; i++ )
			{
				ids[ i ] = Globals.getFactories().make( "id", "unique", null ) ;
			}
			for( int i = 0 ; i < 2 ; i++ )
			{
				System.out.println( ids[i] + " hash " + ids[i].hashCode() ) ;
			}
			*/

			//Object val = Globals.getFactories().make( "svalue", "string", "hello" ) ;
			SValue attr = BasicSValue.newString( "hello" ) ;
			//Object val2 = Globals.getFactories().make( "svalue", "string", "world" ) ;
			SValue attr2 = BasicSValue.newString( "world" ) ;
			System.out.println( attr ) ;
			
			/*
			Object nv = Globals.getFactories().make( "node", "stored-simple", null ) ;
			Node n = (Node)nv ;
			n.setAttr( "aap", attr ) ;
			n.setAttr( "noot", attr2 ) ;
			System.out.println( n ) ;
			System.out.println( n.getAttr( "noot" ) ) ;
			//System.out.println( n.getAttr( "noot" ).getContentData() ) ;
			System.out.println( n.getAttr( "mies" ) ) ;
			System.out.println( n ) ;
			*/
			
			//Object cval = Globals.getFactories().make( "svalue", "vector", null ) ;
			SSequence comp = BasicSValue.newVector( ) ;
			comp.updateAppend( attr ) ;
			comp.updateAppend( attr2 ) ;
			System.out.println( "vec: " + comp ) ;
			
			// SValue
			SValue sint = BasicSValue.newInt( 34554 ) ;
			SValue ssym = BasicSValue.newSymbol( "pietje" ) ;
			SContentValue sstr = BasicSValue.newString( "pietje" ) ;
			SValue spair1 = BasicSValue.newPair( ssym, sstr ) ;
			SValue spair2 = BasicSValue.newPair( BasicSValue.newSymbol( "puk" ), spair1 ) ;
			SValue spair3 = BasicSValue.newPair( BasicSValue.newPair( BasicSValue.empty(), BasicSValue.empty() ), spair2 ) ;
			System.out.println( "symbol: " + ssym ) ;
			System.out.println( "string: " + sstr ) ;
			System.out.println( "pair1: " + spair1 ) ;
			System.out.println( "pair2: " + spair2 ) ;
			System.out.println( "pair3: " + spair3 ) ;
			System.out.println( "empty: " + BasicSValue.empty() ) ;
			
			// SValue & content
			sstr.switchContent( new FileContent( "blurp-aap-file" ) ) ;
			System.out.println( "string <file>: " + sstr ) ;
			
			// SValue & node
			SNode sn = BasicSValue.newStoredNode( "root" ) ;
			System.out.println( "snode: " + sn ) ;
			sn.updateAt( "key1", sstr ) ;
			sn.updateAt( "key2", ssym ) ;
			sn.updateAt( "key3", sint ) ;
			System.out.println( "snode: " + sn ) ;
			sn.removeAt( "key2" ) ;
			System.out.println( "snode: " + sn ) ;
			//skit.Globals.getStorage().flush() ;
			
			/*
			// SValue reading
			String vrstr = "(5+4 #t #f noot -9 - 9 'a '(- ab) \nq23 + $dfj \"str\"  #() #(3 4) #() #((34) (56)) (\"str\\\"2\") 3)" ;
			BasicSReadableReader svread = new BasicSReadableReader( vrstr ) ;
			//svread.test() ;
			svread = new BasicSReadableReader( vrstr ) ;
			System.out.println( "parsed " + vrstr + ": " + svread.readSReadable() ) ;
			vrstr = "#text/symbol#ref/file(\"blurp-aap-file\")" ;
			svread = new BasicSReadableReader( vrstr ) ;
			//svread.test() ;
			svread = new BasicSReadableReader( vrstr ) ;
			System.out.println( "parsed " + vrstr + ": " + svread.readSReadable() ) ;
			vrstr = "##relation/stored(-1 0##struct/store-info(##id/unique(5 262148 0 206 -1845957972 455)  )  ##struct/part-info(2 #(\"hello\" \"world\")  #(klas jan) ) )" ;
			svread = new BasicSReadableReader( vrstr ) ;
			//svread.test() ;
			svread = new BasicSReadableReader( vrstr ) ;
			System.out.println( "parsed " + vrstr + ": " + svread.readSReadable() ) ;
			*/
			
			// typing
			Type tp1 = SType.from( "?" ) ;
			Type tp2 = SType.from( "aap" ) ;
			Type tp3 = SType.from( "noot" ) ;
			Type tp4 = SType.from( "(alt noot aap mies)" ) ;
			Type tp5 = SType.from( "(alt noot maap mies)" ) ;
			Type tp6 = SType.from( "(seq noot aap mies)" ) ;
			SValue val1 = (SValue)BasicSValue.from( "aap" ) ;
			System.out.println( val1 + " satisfies " + tp1 + ": " + tp1.satisfies( val1 ) ) ;
			System.out.println( val1 + " satisfies " + tp2 + ": " + tp2.satisfies( val1 ) ) ;
			System.out.println( val1 + " satisfies " + tp3 + ": " + tp3.satisfies( val1 ) ) ;
			System.out.println( val1 + " satisfies " + tp4 + ": " + tp4.satisfies( val1 ) ) ;
			System.out.println( val1 + " satisfies " + tp5 + ": " + tp5.satisfies( val1 ) ) ;
			System.out.println( val1 + " satisfies " + tp6 + ": " + tp6.satisfies( val1 ) ) ;
			
			// Relation
			RelationMetaInfo rmeta =
				new RelationMetaInfo
						( new SType( BasicSValue.nil() )
						, (SSequence)BasicSValue.from( "#(first second)" )
						, (SSequence)BasicSValue.from( "#(0)" )
						) ;
			//Object rval = Globals.getFactories().make( "relation", "stored-simple", rmeta ) ;
			SRelation rel = BasicSValue.newStoredRelation( rmeta, "root" ) ;
			Relationship rship1 = rel.newEmptyRelationship() ;
			rship1.updateAppend( attr ) ;
			//rship.updateAppend( n ) ;
			rship1.updateAppend( attr2 ) ;
			System.out.println( rship1 ) ;
			SValue sv1 = (SValue)BasicSValue.from( "klas" ) ;
			SValue sv2 = (SValue)BasicSValue.from( "jan" ) ;
			Relationship rship2 = rel.newEmptyRelationship() ;
			rship2.updateAppend( sv1 ) ;
			//rship.updateAppend( n ) ;
			rship2.updateAppend( sv2 ) ;
			System.out.println( rship2 ) ;
			Relationship rship3 = rel.newEmptyRelationship() ;
			rship3.updateAppend( BasicSValue.newString( "blurp" ) ) ;
			rship3.updateAppend( BasicSValue.newInt( 3434 ) ) ;
			rel.add( rship1, false ) ;
			rel.add( rship2, false ) ;
			rel.add( rship3, false ) ;
			System.out.println( rel ) ;
			
			// querying & removing
			QuerySpec qs1 = QuerySpec.from( "klas ?" ) ;
			Query qu1 = rel.query( qs1 ) ;
			for ( ; qu1.hasMoreElements() ; )
			{
				Relationship rs = qu1.nextRelationship() ;
				System.out.println( rs ) ;
				rel.remove( rs ) ;
			}
			QuerySpec qs2 = QuerySpec.from( "? \"world\"" ) ;
			Query qu2 = rel.query( qs2 ) ;
			for ( ; qu2.hasMoreElements() ; )
				System.out.println( qu2.nextElement() ) ;
			
			// directory
			QuerySpec qs3 = QuerySpec.from( "? ? ?" ) ;
			Query qu3 = skit.Globals.getStorage().getCurrentStore().getDirectory().query( qs3 ) ;
			//for ( ; qu3.hasMoreElements() ; )
			//	System.out.println( qu3.nextElement() ) ;
			
			ChangeGroup testChgrp = skit.Globals.getChangeManager().newChangeGroup() ;
			ParentChildWrapper wrapDir = new ParentChildWrapper
									( skit.Globals.getStorage().getCurrentStore().getDirectory()
									, 0, 2
									, testChgrp
									) ;
			DirectoryWrapper wrapDir2 = new DirectoryWrapper
									( skit.Globals.getStorage().getCurrentStore().getDirectory()
									, skit.Globals.getStorage().getCurrentStore().getRoot()
									, 0, 1, 2
									, testChgrp
									) ;
			wrapDir2.queryResolve( "/Relations/Directory" ) ;
			//QuerySpec qs4 = QuerySpec.from( "? ?" ) ;
			//Query qu4 = wrapDir.query( qs4 ) ;
			//for ( ; qu4.hasMoreElements() ; )
			//	System.out.println( qu4.nextElement() ) ;
			
			//Query qu5 = wrapDir.queryTo( skit.Globals.getStorage().getCurrentStore().getRoot() ) ;
			//for ( ; qu5.hasMoreElements() ; )
			//	System.out.println( qu5.nextElement() ) ;
				
			GraphWalker gw1 = GraphWalker.newBreadthFirstWalker
									( skit.Globals.getStorage().getCurrentStore().getRoot()
									, wrapDir
									, new GraphWalkDisplayer()
									) ;
			//gw1.walk() ;
			
			wrapDir.add
					( skit.Globals.getStorage().getCurrentStore().getRoot()
					, BasicSValue.newStoredNode( "root" )
					, false
					) ;
			
			//gw1.reset() ;
			//gw1.walk() ;
			
			GraphWalker gw2 = GraphWalker.newDepthFirstWalker
									( skit.Globals.getStorage().getCurrentStore().getRoot()
									, wrapDir
									, new GraphWalkDisplayer()
									) ;
			//gw2.walk() ;
			
			new NodeTestViewer
				( skit.Globals.getStorage().getCurrentStore().getRoot()
				, wrapDir
				, testChgrp
				) ;
			
			//Setup.fini() ;
		}
		catch( Exception e )
		{
			skit.log.Logger.log( "test error", e ) ;
		}
	}
}