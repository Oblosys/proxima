import skit.* ;
import skit.id.* ;
import skit.util.* ;
import skit.data.* ;
import skit.change.* ;
import skit.data.content.* ;
import skit.data.node.* ;
import skit.data.relation.* ;
import skit.factory.* ;
import skit.data.value.* ;
import skit.wrap.* ;
import java.io.* ;
import java.awt.* ;
import java.awt.event.* ;
import com.objectspace.jgl.* ;

class GraphWalkLister
	implements GraphWalkStep
{
	private HierList hierList ;
	
	public GraphWalkLister( HierList l )
	{
		hierList = l ;
	}
	
	/**
	 * Pass through a step.
	 * @return	null if can continue, otherwise a value which is considered to be the result.
	 */
	public Object passResultValue( Object val, int level )
	{
		hierList.add( level, hierList.stringRepr( val, level ), (SValue)val ) ;
		return null ;
	}
	
	/**
	 * Check if a possible result is valid.
	 * This check will be done before it is passed as a result value.
	 */
	public boolean isValidValueResult( SValue val, int level )
	{
		return true ;
	}
	
	/**
	 * Pass through a queried relationship.
	 * 
	 */
	public void passRelationship( Relationship rs, int level )
	{
	}
	
	/**
	 * Do the necessary query.
	 */
	public Query query( SValue val, int level, GraphQuerier querier )
		throws SkitIOException
	{
		return querier.query( val ) ;
	}
	
}

class HierList extends List
	implements ChangeListener
{
	private SNode root ;
	private ParentChildWrapper hierarchy ;
	private Deque values ;
	private static final int ILLEGAL_POS = -1 ;
	
	private boolean valFlip ;
	
	public HierList( int nRows )
	{
		super( nRows ) ;
		values = new Deque() ;
		valFlip = true ;
	}
	
	public void add( int level, String repr, SValue val )
	{
		add( repr ) ;
		values.pushBack( new GraphWalkItem( val, level ) ) ;
	}
	
	public String stringRepr( Object val, int level )
	{
		return Misc.spaces( level * 3 ) + val.toString() ;
	}
	
	/**
	 * -1 if none.
	 */
	private int findPrecedingLevel( int listPos )
	{
		int givenLevel = ((GraphWalkItem)values.at( listPos )).getLevel() ;
		for ( listPos-- ; listPos >= 0 ; listPos-- )
		{
			int level = ((GraphWalkItem)values.at( listPos )).getLevel() ;
			if ( level < givenLevel )
				break ;
		}
		return listPos ;
	}
	
	/**
	 * -1 if none.
	 */
	private int findPosition( SValue val )
	{
		int max = values.size() ;
		for ( int i = 0 ; i < max ; i++ )
		{
			GraphWalkItem item = ((GraphWalkItem)values.at( i )) ;
			if ( val.equals( item.getItem() ) )
				return i ;
		}
		return -1 ;
	}
	
	public SValue makeVal()
	{
		if ( valFlip = ( ! valFlip ) )
			return BasicSValue.newStoredNode() ;
		else
			return BasicSValue.newInt( Math.round( Math.random() * 1000 ) ) ;
	}
	
	public SValue copy( int listPos )
		throws SkitIOException
	{
		SValue valHere = ((GraphWalkItem)values.at( listPos )).getItem() ;
		return valHere ;
		//syncUI() ;
	}
	
	public SValue cut( int listPos )
		throws SkitIOException
	{
		SValue valHere = ((GraphWalkItem)values.at( listPos )).getItem() ;
		listPos = findPrecedingLevel( listPos ) ;
		if ( listPos < 0 )
			return null ;
		//SValue valPreceding = ((GraphWalkItem)values.at( listPos )).getItem() ;
		hierarchy.remove( hierarchy.queryParent( valHere ) ) ;
		return valHere ;
		//syncUI() ;
	}
	
	public void addSameLevelAs( int listPos, SValue val )
		throws SkitIOException
	{
		listPos = findPrecedingLevel( listPos ) ;
		if ( listPos < 0 )
			return ;
		SValue valPreceding = ((GraphWalkItem)values.at( listPos )).getItem() ;
		hierarchy.add( valPreceding, val, true ) ;
		//syncUI() ;
	}
	
	public void addBelowLevelAs( int listPos, SValue val )
		throws SkitIOException
	{
		SValue valPreceding = ((GraphWalkItem)values.at( listPos )).getItem() ;
		hierarchy.add( valPreceding, val, true ) ;
		//syncUI() ;
	}
	
	public void addHierarchyToList( SNode r, ParentChildWrapper hier )
	{
		GraphWalker gw = GraphWalker.newDepthFirstWalker
								( root
								, hier
								, new GraphWalkLister( this )
								) ;
		gw.walk() ;
	}
	
	public void setHierarchy( SNode r, ParentChildWrapper hier )
	{
		root = r ;
		hierarchy = hier ;
		syncUI() ;
	}

	private void syncUI( )
	{
		removeAll() ;
		values.clear() ;
		addHierarchyToList( root, hierarchy ) ;
	}

	/**
	 * Receive the change.
	 */
	public void changeUpdate( ChangeEvent evt, ChangeManager fromMgr )
	{
		System.out.println( "HIERLIST chng " + evt ) ;
		if ( evt.getSource() == hierarchy )
		{
			Relationship oldRS = (Relationship)evt.getOldValue() ;
			Relationship newRS = (Relationship)evt.getNewValue() ;
			int pos ;
			
			switch( evt.getChangeKind() )
			{
				case ChangeEvent.CHANGE_ADD :
					SValue parentVal = hierarchy.getParentOfRelationship( newRS ) ;
					pos = findPosition( parentVal ) ;
					System.out.println( "HIERLIST ADD " + pos + "/" + parentVal ) ;
					if ( pos >= 0 )
					{
						GraphWalkItem gwi = (GraphWalkItem)values.at( pos ) ;
						int level = gwi.getLevel() + 1 ;
						SValue childVal = hierarchy.getChildOfRelationship( newRS ) ;
						pos++ ;
						addItem( stringRepr( childVal, level), pos ) ;
						values.insert( pos, new GraphWalkItem( childVal, level ) ) ;
					}
					break ;
					
				case ChangeEvent.CHANGE_REMOVE :
					SValue childVal = hierarchy.getChildOfRelationship( oldRS ) ;
					pos = findPosition( childVal ) ;
					System.out.println( "HIERLIST REMOVE " + pos + "/" + childVal ) ;
					if ( pos >= 0 )
					{
						remove( pos ) ;
						values.remove( pos ) ;
					}
					break ;
					
			}
		}
	}

}

public class NodeTestViewer extends Frame
	implements ActionListener, WindowListener
{
	private SNode root ;
	private ParentChildWrapper hierarchy ;
	private ChangeGroup changeGroup ;
	
	private SValue clipValue ;
	
	private HierList hierList ;
	private Button addSameLevelButton ;
	private Button addBelowLevelButton ;
	private Button cutButton ;
	private Button copyButton ;
	private Button pasteSameLevelButton ;
	private Button pasteBelowLevelButton ;
	private Panel buttonPanel ;
	private TextField clipTextField ;
	
	public NodeTestViewer( SNode r, ParentChildWrapper hier, ChangeGroup chgrp )
	{
		root = r ;
		hierarchy = hier ;
		changeGroup = chgrp ;
		
		clipValue = null ;
		
		setupUI() ;
		addWindowListener( this ) ;
		
		hierList.setHierarchy( root, hierarchy ) ;
		changeGroup.addChangePropagationFromTo( hierarchy, hierList ) ;
		
		pack() ;
		resize( 500, 500 ) ;
		show() ;
	}
	
	
	private Button addButton( String txt )
	{
		Button b = new Button( txt ) ;
		b.addActionListener( this ) ;
		buttonPanel.add( b ) ;
		return b ;
	}
	
	private void setupUI()
	{
		setLayout( new BorderLayout() ) ;
		add( "North", clipTextField = new TextField( 40 ) ) ;

		add( "Center", hierList = new HierList( 40 ) ) ;
		
		buttonPanel = new Panel() ;
		buttonPanel.setLayout( new FlowLayout() ) ;
		
		addSameLevelButton = addButton( "Add on same level" ) ;
		addBelowLevelButton = addButton( "Add below level" ) ;
		cutButton = addButton( "Cut" ) ;
		copyButton = addButton( "Copy" ) ;
		pasteSameLevelButton = addButton( "Paste on same level" ) ;
		pasteBelowLevelButton = addButton( "Paste below level" ) ;
		
		add( "South", buttonPanel ) ;
	}
	
	public void actionPerformed( ActionEvent evt )
	{
		Object target = evt.getSource() ;
		
		int listPos = hierList.getSelectedIndex() ;
		if ( listPos < 0 )
			return ;

		try
		{
			if ( target == addSameLevelButton )
			{
				hierList.addSameLevelAs( listPos, hierList.makeVal() ) ;
			}
			else if ( target == addBelowLevelButton )
			{
				hierList.addBelowLevelAs( listPos, hierList.makeVal() ) ;
			}
			else if ( target == pasteSameLevelButton && clipValue != null )
			{
				hierList.addSameLevelAs( listPos, clipValue ) ;
			}
			else if ( target == pasteBelowLevelButton && clipValue != null )
			{
				hierList.addBelowLevelAs( listPos, clipValue ) ;
			}
			else if ( target == cutButton )
			{
				clipValue = hierList.cut( listPos ) ;
				clipTextField.setText( clipValue.toString() ) ;
			}
			else if ( target == copyButton )
			{
				clipValue = hierList.copy( listPos ) ;
				clipTextField.setText( clipValue.toString() ) ;
			}
		}
		catch ( Exception ex )
		{
			skit.log.Logger.warn( "error in test, ignored", ex ) ;
		}
	}
	
	public void windowClosed(WindowEvent event)
	{
	}

	public void windowDeiconified(WindowEvent event)
	{
	}

	public void windowIconified(WindowEvent event)
	{
	}

	public void windowActivated(WindowEvent event)
	{
	}

	public void windowDeactivated(WindowEvent event)
	{
	}

	public void windowOpened(WindowEvent event)
	{
	}

	public void windowClosing(WindowEvent event)
	{
		changeGroup.close() ; //???? here
		Setup.fini() ;
		dispose() ;
	}

}