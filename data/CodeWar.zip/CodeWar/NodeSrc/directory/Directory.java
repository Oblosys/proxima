package skit.directory ;

import skit.data.relation.* ;

/**
 * Wrapper around ...
 */
public class Directory
{
	public Directory( Relation rel )
	{
	}
}