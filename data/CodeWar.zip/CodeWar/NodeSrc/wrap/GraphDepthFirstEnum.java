package skit.wrap ;

import skit.data.relation.* ;
import skit.data.value.* ;
import skit.* ;
//import com.objectspace.jgl.* ;

/**
 * Enumeration a graph.
 * Depth first fashion.
 */
public class GraphDepthFirstEnum extends GraphEnumeration
{
	public GraphDepthFirstEnum( SValue start, RelationWrapper binRel, GraphWalkStep st, boolean giveEdge )
	{
		super( start, binRel, st, giveEdge ) ;
	}
	
	/**
	 * Add something to do.
	 * Meant to be implemented in subclass as the specific order of walking policy.
	 */
	protected void addToDo( SValue v, int level )
	{
		addFrontIfNotPassed( v, level ) ;
	}
	
	
}