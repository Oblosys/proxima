package skit.wrap ;

import skit.data.relation.* ;
import skit.data.value.* ;
import skit.* ;
//import skit.* ;
//import com.objectspace.jgl.* ;

/**
 * One step in walking a graph.
 * @see skit.wrap.GraphWalker
 */
public class GraphWalkDisplayer
	implements GraphWalkStep
{
	/**
	 * Pass through a step.
	 * @return	null if can continue, otherwise a value which is considered a result.
	 */
	public Object passResultValue( Object val, int level )
	{
		System.out.println( "Graph walk step level " + level + " value " + val ) ;
		return null ;
	}
	
	/**
	 * Check if a possible result is valid.
	 * This check will be done before it is passed as a result value.
	 */
	public boolean isValidValueResult( SValue val, int level )
	{
		return true ;
	}
	
	/**
	 * Pass through a queried relationship.
	 * 
	 */
	public void passRelationship( Relationship rs, int level )
	{
	}
	
	/**
	 * Do the necessary query.
	 */
	public Query query( SValue val, int level, GraphQuerier querier )
		throws SkitIOException
	{
		return querier.query( val ) ;
	}
	
}