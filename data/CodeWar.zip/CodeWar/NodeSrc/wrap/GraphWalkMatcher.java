package skit.wrap ;

import skit.data.relation.* ;
import skit.data.value.* ;
import skit.* ;
//import skit.* ;
//import com.objectspace.jgl.* ;

/**
 * Match graph against something.
 * This something depends on the nesting depth of the graph walking, the level.
 * @see skit.wrap.GraphEnumeration
 */
public abstract class GraphWalkMatcher
	implements GraphWalkStep
{
	private int fromPos ;
	
	public GraphWalkMatcher( int fromP )
	{
		fromPos = fromP ;
	}
	
	/**
	 * Pass through a step.
	 * @return	null if can continue, otherwise a value which is considered a result.
	 */
	public Object passResultValue( Object val, int level )
	{
		System.out.println( "Graph walk step level " + level + " value " + val ) ;
		return null ;
	}
	
	/**
	 * Check if a possible result is valid.
	 * This check will be done before it is passed as a result value.
	 */
	public boolean isValidValueResult( SValue val, int level )
	{
		return true ;
	}
	
	/**
	 * Pass through a queried relationship.
	 * 
	 */
	public void passRelationship( Relationship rs, int level )
	{
		System.out.println( "Graph walk step level " + level + " relship " + rs ) ;
	}
	
	/**
	 * Do the necessary query.
	 */
	public Query query( SValue val, int level, GraphQuerier querier )
		throws SkitIOException
	{
		Query res ;
		if ( canProceedWithLevel( level ) )
		{
			SRelation rel = querier.getRelation() ;
			QuerySpec spec = rel.newQuerySpec() ;
			spec.updateAt( fromPos, val ) ;
			fillSpecForLevel( spec, level ) ;
			res = rel.query( spec ) ;
		}
		else
		{
			res = new EmptyQuery() ;
		}
		return res ;
	}
	
	/**
	 * Fill in the extra details for a query.
	 * To be implemented in a subclass.
	 */
	protected abstract void fillSpecForLevel( QuerySpec val, int level ) ;
	
	/**
	 * Check if can proceed with level.
	 * To be implemented in a subclass.
	 */
	protected abstract boolean canProceedWithLevel( int level ) ;
	
}