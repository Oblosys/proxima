package skit.wrap ;

import skit.data.relation.* ;
import skit.data.value.* ;
import skit.* ;
import skit.change.* ;

/**
 * Abstract class for wrapper around relations.
 */
public abstract class RelationWrapper extends ProjectedRelation
{
	public RelationWrapper( SRelation rel, int[] projPos, ChangeGroup chgrp )
	{
		super( rel, projPos, chgrp ) ;
	}
	
	protected abstract int getFromPosition() ;
	
	protected abstract int getToPosition() ;
	
	/**
	 * Get the successors in the form of a query
	 */
	public Query queryTo( SValue fromVal )
		throws SkitIOException
	{
		return queryFromOne( getFromPosition(), fromVal ) ;
	}
	
	/**
	 * Get the predecessors in the form of a query
	 */
	public Query queryFrom( SValue toVal )
		throws SkitIOException
	{
		return queryFromOne( getToPosition(), toVal ) ;
	}
	
	/**
	 * Get from/to pairs in the form of a query
	 */
	public Query queryFromTo( SValue fromVal, SValue toVal )
		throws SkitIOException
	{
		return queryFromTwo( getFromPosition(), fromVal, getToPosition(), toVal ) ;
	}
	
	/**
	 * Get the from value of the relationship as given by a query of this object.
	 */
	public SValue getFromOfRelationship( Relationship rs )
	{
		return rs.at( getFromPosition() ) ;
	}
	
	/**
	 * Get the from value of the relationship as given by a query of this object.
	 */
	public SValue getToOfRelationship( Relationship rs )
	{
		return rs.at( getToPosition() ) ;
	}
	
}