package skit.wrap ;

import skit.data.relation.* ;
import skit.data.value.* ;
import skit.* ;
//import skit.* ;
//import com.objectspace.jgl.* ;

/**
 * Match graph against something.
 * This something depends on the nesting depth of the graph walking, the level.
 * In this variant, the level corresponds to a SValue from a sequence
 * @see skit.wrap.GraphEnumeration
 * @see skit.wrap.GraphWalkMatcher
 */
public class GraphWalkSeqMatcher extends GraphWalkMatcher
{
	private SequenceBehavior matchSeq ;
	private int matchPos ;
	private int size ;
	
	public GraphWalkSeqMatcher( int fromP, int matchP, SequenceBehavior seq )
	{
		super( fromP ) ;
		matchSeq = seq ;
		matchPos = matchP ;
		size = matchSeq.getSize() ;
	}
	
	/**
	 * Fill in the extra details for a query.
	 * To be implemented in a subclass.
	 */
	protected void fillSpecForLevel( QuerySpec spec, int level )
	{
		spec.updateAt( matchPos, matchSeq.at( level ) ) ;
	}
	
	/**
	 * Check if can proceed with level.
	 * To be implemented in a subclass.
	 */
	protected boolean canProceedWithLevel( int level )
	{
		return level < size ;
	}
	
}