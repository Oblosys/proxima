package skit.wrap ;

import skit.data.relation.* ;
import skit.data.value.* ;
import skit.* ;
import skit.change.* ;

/**
 * Wrapper around relation, interpreting it as a binary one.
 */
public abstract class BinaryRelationWrapper extends RelationWrapper
{
	protected static final int FROM = 0 ;
	protected static final int TO = 1 ;
	protected static final int NR_OF_BINFIELDS = 2 ;
	
	public BinaryRelationWrapper( SRelation rel, int fromPos, int toPos, ChangeGroup chgrp )
	{
		super( rel, makeProj( fromPos, toPos ), chgrp ) ;
	}
	
	private static int[] makeProj( int i1, int i2 )
	{
		int[] proj = { i1, i2 } ;
		return proj ;
	}
	
	protected int getFromPosition()
	{
		return FROM ;
	}
	
	protected int getToPosition()
	{
		return TO ;
	}
	
	/**
	 * Add a from/to pair.
	 * @see skit.data.value.SRelation
	 */
	public Relationship add( SValue fromVal, SValue toVal, boolean checkType )
		throws SkitIOException
	{
		Relationship newRS = newFilledRelationship() ;
		newRS.updateAt( FROM, fromVal ) ;
		newRS.updateAt( TO, toVal ) ;
		return add( newRS, checkType ) ;
	}
	
	/**
	 * Remove a from/to pair.
	 * @see skit.data.value.SRelation
	 */
	/*
	public void remove( SValue fromVal, SValue toVal )
		throws SkitIOException
	{
		QuerySpec sp = QuerySpec.newAllSpec( NR_OF_BINFIELDS ) ;
		sp.updateAt( FROM, fromVal ) ;
		sp.updateAt( TO, toVal ) ;
		Query q = query( sp ) ;
		for ( ; q.hasMoreElements() ; )
		{
			Relationship rs = q.nextRelationship() ;
			rs.getRelation().remove( rs ) ;
		}
	}
	*/
	
}