package skit.wrap ;

//import skit.data.relation.* ;
import skit.data.value.* ;
//import skit.* ;
//import com.objectspace.jgl.* ;

/**
 * An item in the graph walking.
 */
public class GraphWalkItem extends GraphWalkResult
{
	public GraphWalkItem( SValue it, int lv )
	{
		super( it, lv ) ;
	}
	
	public SValue getItem()
	{
		return (SValue)getResult() ;
	}

}