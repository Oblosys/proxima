package skit.wrap ;

import skit.data.relation.* ;
import skit.data.value.* ;
import skit.* ;
//import skit.* ;
//import com.objectspace.jgl.* ;

/**
 * One step in walking a graph.
 * @see skit.wrap.GraphWalker
 */
public interface GraphWalkStep
{
	/**
	 * Pass through a step.
	 * Return of a non-null value makes the GraphWalk stop and return the value.
	 * @return	null if can continue, otherwise a value which is considered a result.
	 */
	public Object passResultValue( Object val, int level ) ;
	
	/**
	 * Check if a possible result is valid.
	 * This check will be done before it is passed as a result value.
	 */
	public boolean isValidValueResult( SValue val, int level ) ;
	
	/**
	 * Pass through a queried relationship.
	 * 
	 */
	public void passRelationship( Relationship rs, int level ) ;
	
	/**
	 * Do the necessary query.
	 */
	public Query query( SValue val, int level, GraphQuerier querier )
		throws SkitIOException ;
	
}