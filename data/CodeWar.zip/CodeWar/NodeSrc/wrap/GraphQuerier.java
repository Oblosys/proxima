package skit.wrap ;

import skit.data.relation.* ;
import skit.data.value.* ;
import skit.* ;

/**
 * Something which is able to to a query for graph walk.
 * ???? necessary
 */
public interface GraphQuerier
{
	/**
	 * Do a query, a default one.
	 */
	public Query query( SValue val )
		throws SkitIOException ;
	
	/**
	 * Get the relation used.
	 */
	public SRelation getRelation() ;
	
}
