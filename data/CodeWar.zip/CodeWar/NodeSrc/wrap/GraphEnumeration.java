package skit.wrap ;

import skit.data.relation.* ;
import skit.data.value.* ;
import skit.* ;
import com.objectspace.jgl.* ;
import java.util.* ;

/**
 * Walking a binary relation as a graph.
 * Molded into a Enumeration which returns all values passed
 * in the form of a GraphWalkItem.
 */
public abstract class GraphEnumeration
	implements Enumeration, GraphQuerier
{
	private RelationWrapper binaryRelation ;
	private Sequence toDo ;
	private Set passedThrough ;
	private GraphWalkStep walkQuery ;
	private SValue startPoint ;
	private boolean hasNext ;
	private GraphWalkResult nextResult ;
	private boolean giveEdgesAsResult ;
	
	public GraphEnumeration( SValue start, RelationWrapper binRel, GraphWalkStep wq, boolean giveEdge )
	{
		binaryRelation = binRel ;
		walkQuery = wq ;
		giveEdgesAsResult = giveEdge ;
		reset( start ) ;
	}
	
	public void reset()
	{
		reset( startPoint ) ;
	}
	
	public void reset( SValue start )
	{
		startPoint = start ;
		toDo = new DList() ;
		passedThrough = new HashSet() ;
		addToDo( start, 0 ) ;
		walkToNext() ;
	}
	
	/**
	 * A default query.
	 * Normally used by the walkQuery if no special querying is needed.
	 */
	public Query query( SValue val )
		throws SkitIOException
	{
		return binaryRelation.queryTo( val ) ;
	}
	
	public SRelation getRelation()
	{
		return binaryRelation ;
	}
	
	public boolean hasMoreElements()
	{
		return hasNext ;
	}
	
	public Object nextElement()
	{
		GraphWalkResult res = nextResult ;
		walkToNext() ;
		return res ;
	}
	
	/**
	 * Do the walking.
	 * Return either null if the complete graph has been walked through,
	 * or the value as returned by the GraphWalkStep.
	 * @see skit.wrap.GraphWalkStep
	 */
	private void walkToNext()
	{
		try
		{
			Object resObj = null ;
			for ( hasNext = false ; hasSomethingToDo() && ( ! hasNext ) ; )
			{
				GraphWalkItem item = getAndRemoveToDo() ;
				int level = item.getLevel() ;
				SValue val = item.getItem() ;
				Query toQuery = walkQuery.query( val, level, this ) ;
				for ( ; toQuery.hasMoreElements() ; )
				{
					Relationship rs = toQuery.nextRelationship() ;
					walkQuery.passRelationship( rs, level ) ;
					SValue toVal = binaryRelation.getToOfRelationship( rs ) ;
					addToDo( toVal, level+1 ) ;
				}
				if ( ! giveEdgesAsResult )
				{
					hasNext = walkQuery.isValidValueResult( val, level ) ;
					nextResult = item ;
				}
			}
		}
		catch ( Exception ex )
		{
			skit.log.Logger.warn( "error in graph enumeration, stopping", ex ) ;
		}
		//return null ;
	}
	
	/**
	 * Add something to do.
	 * Meant to be implemented in subclass as the specific order of walking policy.
	 */
	protected abstract void addToDo( SValue v, int level ) ;
	
	/**
	 * Check if something to do.
	 */
	private boolean hasSomethingToDo()
	{
		return ! toDo.isEmpty() ;
	}
	
	/**
	 * Get something to do.
	 * Mark it as passed.
	 */
	protected GraphWalkItem getAndRemoveToDo()
	{
		GraphWalkItem res = (GraphWalkItem)toDo.popFront() ;
		setPassed( res.getItem() ) ;
		return res ;
	}
	
	/**
	 * Add at front.
	 */
	protected void addFront( SValue v, int level )
	{
		toDo.pushFront( new GraphWalkItem( v, level ) ) ;
	}
	
	/**
	 * Add at front.
	 * Done only if not yet passed.
	 */
	protected void addFrontIfNotPassed( SValue v, int level )
	{
		if ( ! isPassed( v ) )
			addFront( v, level ) ;
	}
	
	/**
	 * Add at back.
	 */
	protected void addBack( SValue v, int level )
	{
		toDo.pushBack( new GraphWalkItem( v, level ) ) ;
	}
	
	/**
	 * Add at back.
	 * Done only if not yet passed.
	 */
	protected void addBackIfNotPassed( SValue v, int level )
	{
		if ( ! isPassed( v ) )
			addBack( v, level ) ;
	}
	
	/**
	 * Add as passed through.
	 */
	protected void setPassed( SValue v )
	{
		passedThrough.add( v ) ;
	}
	
	/**
	 * Add as passed through.
	 */
	protected boolean isPassed( SValue v )
	{
		return passedThrough.get( v ) != null ;
	}
	
}
