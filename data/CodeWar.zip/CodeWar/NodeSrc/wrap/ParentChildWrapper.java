package skit.wrap ;

import skit.data.relation.* ;
import skit.data.value.* ;
import skit.change.* ;
import skit.* ;

/**
 * Wrapper around relation, interpreting it as a parent/child one.
 */
public class ParentChildWrapper extends BinaryRelationWrapper
{
	public ParentChildWrapper( SRelation rel, int parentPos, int childPos, ChangeGroup chgrp )
	{
		super( rel, parentPos, childPos, chgrp ) ;
	}

	/**
	 * Get the parent value of the relationship as given by a query of this object.
	 */
	public SValue getParentOfRelationship( Relationship rs )
	{
		return getFromOfRelationship( rs ) ;
	}
	
	/**
	 * Get the from value of the relationship as given by a query of this object.
	 */
	public SValue getChildOfRelationship( Relationship rs )
	{
		return getToOfRelationship( rs ) ;
	}
	
	/**
	 * Get the children in the form of a query
	 */
	public Query queryChild( SValue parentVal )
		throws SkitIOException
	{
		return queryTo( parentVal ) ;
	}
	
	/**
	 * Get the parents in the form of a query
	 */
	public Query queryParent( SValue childVal )
		throws SkitIOException
	{
		return queryFrom( childVal ) ;
	}
	
}