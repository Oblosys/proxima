package skit.wrap ;

//import skit.data.relation.* ;
import skit.data.value.* ;
//import skit.* ;
//import com.objectspace.jgl.* ;

/**
 * A result from the graph walking.
 */
public class GraphWalkResult
{
	private int level ;
	private Object item ;
	
	public GraphWalkResult( Object it, int lv )
	{
		level = lv ;
		item = it ;
	}
	
	public int getLevel()
	{
		return level ;
	}
	
	public Object getResult()
	{
		return item ;
	}
	
	public String toString()
	{
		return "[" + level + ":" + item + "]" ;
	}
}