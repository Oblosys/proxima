package skit.wrap ;

import skit.data.relation.* ;
import skit.data.value.* ;
import skit.* ;
//import com.objectspace.jgl.* ;

/**
 * Enumeration a graph.
 * Breadth first fashion.
 */
public class GraphBreadthFirstEnum extends GraphEnumeration
{
	public GraphBreadthFirstEnum( SValue start, RelationWrapper binRel, GraphWalkStep st, boolean giveEdge )
	{
		super( start, binRel, st, giveEdge ) ;
	}
	
	/**
	 * Add something to do.
	 * Meant to be implemented in subclass as the specific order of walking policy.
	 */
	protected void addToDo( SValue v, int level )
	{
		addBackIfNotPassed( v, level ) ;
	}
	
	
}