package skit.wrap ;

import skit.data.relation.* ;
import skit.data.value.* ;
import skit.* ;
import com.objectspace.jgl.* ;
import java.util.* ;

/**
 * Walking a binary relation as a graph.
 */
public class GraphWalker
{
	private GraphEnumeration graphEnum ;
	private GraphWalkStep walkStep ;
	
	private GraphWalker( GraphEnumeration e, GraphWalkStep st )
	{
		graphEnum = e ;
		walkStep = st ;
	}
	
	public static GraphWalker newDepthFirstWalker( SValue start, RelationWrapper binRel, GraphWalkStep st )
	{
		return new GraphWalker( new GraphDepthFirstEnum( start, binRel, st, false ), st ) ;
	}
	
	public static GraphWalker newBreadthFirstWalker( SValue start, RelationWrapper binRel, GraphWalkStep st )
	{
		return new GraphWalker( new GraphBreadthFirstEnum( start, binRel, st, false ), st ) ;
	}
	
	/**
	 * Do the walking.
	 * Return either null if the complete graph has been walked through,
	 * or the value as returned by the GraphWalkStep.
	 * @see skit.wrap.GraphWalkStep
	 */
	public Object walk()
	{
		Object res = null ;
		for ( ; graphEnum.hasMoreElements() ; )
		{
			Object o = graphEnum.nextElement() ;
			if ( o == null )
				return null ;
			GraphWalkResult gwr = (GraphWalkResult)o ;
			res = walkStep.passResultValue( gwr.getResult(), gwr.getLevel() ) ;
			if ( res != null )
				break ;
		}
		return res ;
	}
	
}
