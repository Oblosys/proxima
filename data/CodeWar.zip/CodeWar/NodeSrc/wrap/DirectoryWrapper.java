package skit.wrap ;

import skit.data.relation.* ;
import skit.data.value.* ;
import skit.* ;
import skit.util.* ;
import skit.change.* ;
import java.util.* ;

/**
 * Wrapper around relation, interpreting it as a directory, or name resolver.
 * A path is hierarchically organised, with names separated by a separator, 
 * in a more or less standard way (UNIX alike).
 */
public class DirectoryWrapper extends RelationWrapper
{
	protected static final int FROM = 0 ;
	protected static final int NAME = 1 ;
	protected static final int TO = 2 ;
	protected static final int NR_OF_FIELDS = 3 ;
	
	public static final String SEPARATOR = "/" ;
	
	private SValue root ;
	
	public DirectoryWrapper( SRelation rel, SValue root, int fromPos, int namePos, int toPos, ChangeGroup chgrp )
	{
		super( rel, makeProj( fromPos, namePos, toPos ), chgrp ) ;
		this.root = root ;
	}
	
	private static int[] makeProj( int i1, int i2, int i3 )
	{
		int[] proj = { i1, i2, i3 } ;
		return proj ;
	}
	
	protected int getFromPosition()
	{
		return FROM ;
	}
	
	protected int getToPosition()
	{
		return TO ;
	}
	
	/**
	 * Get the content in the form of a query
	 */
	public Query queryByNameTo( SValue fromVal, SValue nameVal )
		throws SkitIOException
	{
		return queryFromTwo( FROM, fromVal, NAME, nameVal ) ;
	}
	
	/*
	class DeeperQueryTransformer
	{
		private String pathName ;
		
		public DeeperQueryTransformer( String pn )
		{
			pathName = pn ;
		}
		
		public Object transform( Object o )
		{
			Relationship rs = (Relationship)o ;
			Query further =
				queryResolve( getToOfRelationship( rs ), pathName ) ;
			if ( ! further.hasMoreElements() )
			{
				further = new EnumerationQuery( new OneEnumeration( rs ) ) ;
			}
			return further ;
		}
	}
	*/
	
	private SVector split( String path )
	{
		StringTokenizer st = new StringTokenizer( path, SEPARATOR ) ;
		SVector res = BasicSValue.newVector( new EnumerationTransformer( st, new StringSValueTransformer() ) ) ;
		System.out.println( "SPLIT " + res ) ;
		return res ;
	}
	
	/**
	 * Resolve a name.
	 * No resolution means empty query.
	 * Ambiguous naming means >1 entry in the query.
	 * @return the query which satisfies.
	 */
	public Query queryResolve( /*SValue fromVal,*/ String pathName )
	{
		GraphWalker gw =
			GraphWalker.newDepthFirstWalker
					( root
					, this
					, new GraphWalkSeqMatcher
							( getFromPosition()
							, NAME
							, split( pathName )
							)
					) ;
		gw.walk() ;
		/*
		String head = pathName ;
		String tail = null ;
		int sepPos = pathName.indexOf( SEPARATOR ) ;
		
		if ( fromVal == null )
			fromVal = root ;
		
		if ( sepPos > 0 )
		{
			head = pathName.substring( 0, sepPos ) ;
			tail = pathName.substring( sepPos+1, pathName.length() ) ;
		}
		
		Query fromHere = queryByNameTo( fromVal, BasicSValue( newString( head ) ) ) ;
		Query hereFurther = fromHere ;
		if ( fromHere.hasMoreElements() )
		{
			fromHere =
				new EnumerationQuery
					( new EnumerationEnumeration
						( new EnumerationTransformer
								( fromHere
								, new DeeperQueryTransformer( tail )
								) ) ) ;
		}
		
		return hereFurther ;
		*/
		return null ;
	}
	
	/**
	 * Get the name value of the relationship as given by a query of this object.
	 */
	public SValue getNameOfRelationship( Relationship rs )
	{
		return rs.at( NAME ) ;
	}
	
	/**
	 * Add a from/to pair.
	 * @see skit.data.value.SRelation
	 */
	public Relationship add( SValue fromVal, SValue nameVal, SValue toVal, boolean checkType )
		throws SkitIOException
	{
		Relationship newRS = newFilledRelationship() ;
		newRS.updateAt( FROM, fromVal ) ;
		newRS.updateAt( NAME, nameVal ) ;
		newRS.updateAt( TO, toVal ) ;
		return add( newRS, checkType ) ;
	}
	
	/**
	 * Remove a from/to pair.
	 * @see skit.data.value.SRelation
	 */
	/*
	public void remove( SValue fromVal, SValue toVal )
		throws SkitIOException
	{
		QuerySpec sp = QuerySpec.newAllSpec( NR_OF_BINFIELDS ) ;
		sp.updateAt( FROM, fromVal ) ;
		sp.updateAt( TO, toVal ) ;
		Query q = query( sp ) ;
		for ( ; q.hasMoreElements() ; )
		{
			Relationship rs = q.nextRelationship() ;
			rs.getRelation().remove( rs ) ;
		}
	}
	*/
	
}