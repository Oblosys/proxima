package skit.factory ;

import skit.* ;

/**
 * A Factory creates things.
 * It has a name, which determines the specific way it makes (ImplementationName).
 * It belongs to a category, which determines the type of things it makes.
 */
public interface Factory
{
	/**
	 * Get the category of the factory, which things are produced.
	 * @return The category of the factory.
	 */
	//String getCategoryName() ;
	
	/**
	 * Get the name/kind of factory, the way things are produced.
	 * @return The name of the factory.
	 */
	//String getImplementationName() ;
	
	/**
	 * Get a description of the meaning/usage of the parameter
	 * @return The description of the parameter in makeIt
	 * @see	makeIt
	 */
	String getParamDescr() ;
	
	/**
	 * Make the thing.
	 * @return The thing.
	 */
	Object makeIt( Object param )
		throws skit.SkitException ;
	
}