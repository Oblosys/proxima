package skit.factory ;

//import com.objectspace.jgl.*;
import java.util.* ;
import skit.util.* ;
import skit.SkitException ;

/**
 * A Factories is a repository for Factory's.
 * This class is a singleton.
 * For each category also a default value is maintained.
 * This one is either set explicitly under impl name "default" for a category,
 * or is the first factory added for a category.
 *
 * @see skit.factory.Factory
 */
public class Factories
{
	private Registry factoryRegistry ;
	
	private static Factories theFactories = null ;
	
	private Factories()
	{
		//factoryRegistry = new FlatRegistry( "factories", false, false ) ;
		factoryRegistry = new TreeRegistry( "factories", "/", true, false ) ;
	}
	
	/**
	 * Create a singleton Factories.
	 */
	public static Factories newFactories()
	{
		if ( theFactories == null )
			theFactories = new Factories() ;
		return theFactories ;
	}
	
	/*
	private Registry findCateg( String cat )
	{
		return (Registry)factoryRegistry.resolve( cat ) ;
	}
	
	private Factory findImpl( Registry impls, String impl )
	{
		return (Factory)( impls.resolve( impl ) ) ;
	}
	
	private Registry ensureCateg( String categ )
	{
		Registry impls = findCateg( categ ) ;
		if ( impls == null )
		{
			impls = new FlatRegistry( categ, true, false ) ;
			factoryRegistry.register( categ, impls ) ;
		}
		return impls ;
	}
	*/
	
	/**
	 * Register the factory.
	 */
	public void registerFactory( String mime, Factory f )
	{
		factoryRegistry.register( mime, f ) ;
	}
	
	/**
	 * Register the factory.
	 */
	public void registerFactory( String mainMime, String subMime, Factory f )
	{
		factoryRegistry.register( mainMime + factoryRegistry.getSeparator() + subMime, f ) ;
	}
	
	/**
	 * Register the factory as default.
	 */
	public void registerAsDefaultFactory( String withIn, Factory f )
	{
		factoryRegistry.register( withIn, f ) ;
	}
	
	/**
	 * Find a factory.
	 * @return The factory, or null if none available.
	 */
	private Factory find( String mime )
	{
		Factory res = (Factory)factoryRegistry.resolve( mime ) ;
		return res ;
	}
	
	/**
	 * Make the thing using a factory.
	 * @return The thing.
	 */
	private Object make( String mime, Factory f, Object param )
		throws SkitException
	{
		if ( f != null )
		{
			return f.makeIt( param ) ;
		}
		else
		{
			throw new SkitException( "no factory for " + mime ) ;
		}
	}
	
	/**
	 * Make the thing.
	 * @return The thing.
	 */
	public Object make( String mime, Object param )
		throws SkitException
	{
		Factory f = find( mime ) ;
		return make( mime, f, param ) ;
	}
	
	/**
	 * @return An Enumeration of all available keys.
	 */
	public Enumeration categories()
	{
		return factoryRegistry.resourceKeys() ;
	}
	
	/**
	 * Get an Enumeration of all available implementations for a category.
	 * If the category does not exist, an empty enumeration is returned.
	 */
	/*
	public Enumeration implementations( String categ )
	{
		Registry impls = findCateg( categ ) ;
		Enumeration res ;
		if ( impls == null )
			res = new EmptyEnumeration() ;
		else
			res = impls.resourceKeys() ;
		return res ;
	}
	*/
	
	/**
	 * Get the description of the parameter used in make.
	 * @see make
	 * @return The factory, or null if none available.
	 */
	public String getParamDescr( String mime )
	{
		Factory f = find( mime ) ;
		return ( f == null ? "??" : f.getParamDescr() ) ;
	}
	
}