package skit.data.relation ;

import skit.data.relation.* ;
import skit.data.value.* ;
import skit.* ;
import skit.util.* ;
import skit.change.* ;
import java.util.* ;

/**
 * A projected view on another relation.
 */
public class ProjectedRelation extends BasicSValue
	implements SRelation, ChangeListener
{
	//protected SRelation relation ;
	protected int[] projectionPositions ;
	
	private ProjectionTransformer projTrf ;
	
	public ProjectedRelation( SRelation rel, int[] projPos, ChangeGroup chgrp )
	{
		setData( rel ) ;
		projectionPositions = projPos ;
		chgrp.addChangePropagationFromTo( rel, this ) ;
		projTrf = new ProjectionTransformer( this ) ;
	}
	
	protected SRelation getRelation()
	{
		return (SRelation)getData() ;
	}
	
	/**
	 * Set the meta info of a relation.
	 * This may influence the actual behavior and performance.
	 */
	public void setMetaInfo( RelationMetaInfo info )
	{
		// ???? unimpl
	}
	
	/**
	 * Make a query spec for the relation which will match any relationship.
	 * Meant to be adapted afterwards to match more precise criteria as used in a query.
	 */
	public QuerySpec newQuerySpec()
	{
		return RelationFunctionality.newQuerySpec( this ) ;
	}
	
	/**
	 * Make a prototypical empty relationship for this relation
	 * @see skit.data.value.SRelation
	 */
	public Relationship newEmptyRelationship()
	{
		// ???? this way ???? wrapper around
		return getRelation().newEmptyRelationship() ;
	}

	/**
	 * Make a prototypical relationship for this relation, though filled with default values
	 * and having the right size.
	 */
	public Relationship newFilledRelationship()
	{
		return RelationFunctionality.newFilledRelationship( this ) ;
		//return new BasicRelationship( null, getType(), 0, BasicSValue.newVector( getRelshipSize(), BasicSValue.nil() ) /*????*/ ) ;
	}

	/**
	 * @return The number of elements in the relation.
	 */
	public int getSize()
	{
		return getRelation().getSize() ;
	}
	
	/**
	 * @return true if empty.
	 */
	public boolean isEmpty()
	{
		return getRelation().isEmpty() ;
	}
	
	/**
	 * @return The type of the relation.
	 */
	public Type getType()
	{
		return getRelation().getType() ; // ????
	}
	
	public int getRelshipSize()
	{
		return projectionPositions.length ;
	}
	
	/**
	 * Check if relation can be updated.
	 */
	public boolean isUpdateable()
	{
		return getRelation().isUpdateable() ;
	}
	
	protected void unprojectInto( Relationship fromRS, Relationship toRS )
	{
		int size = Math.min
						( Math.min
							( projectionPositions.length
							, fromRS.getSize()
							)
						, toRS.getSize()
						) ;
		for ( int i = 0 ; i < size ; i++ )
		{
			toRS.updateAt( projectionPositions[ i ], fromRS.at( i ) ) ;
		}
	}
	
	/**
	 * Get all the relationships in its basic dataform.
	 * I.e. a query giving all of it.
	 *
	 */
	public Enumeration elements()
	{
		return RelationFunctionality.elements( this ) ;
	}
	
	/**
	 * @see skit.data.value.SRelation
	 */
	public Query query( QuerySpec spec )
		throws SkitIOException
	{
		SRelation rel = getRelation() ;
		int size = Math.min( projectionPositions.length, spec.getSize() ) ;
		QuerySpec relSpec = rel.newQuerySpec() ;
		for ( int i = 0 ; i < size ; i++ )
		{
			relSpec.updateAt( projectionPositions[i], spec.at( i ) ) ;
		}
		Query res = rel.query( relSpec ) ;
		return new ProjectedQuery( this, res, relSpec, projectionPositions ) ;
	}

	/**
	 * Do a query, using one value as criterium.
	 */
	public Query queryFromOne( int fromPos, SValue val )
		throws SkitIOException
	{
		QuerySpec spec = QuerySpec.newSeqSpec( getRelshipSize(), SType.TP_ANYTHING ) ;
		spec.updateAt( fromPos, val ) ;
		return query( spec ) ;
	}
	
	/**
	 * Do a query, using two values as criterium.
	 */
	public Query queryFromTwo( int from1Pos, SValue val1, int from2Pos, SValue val2 )
		throws SkitIOException
	{
		QuerySpec spec = QuerySpec.newSeqSpec( getRelshipSize(), SType.TP_ANYTHING ) ;
		spec.updateAt( from1Pos, val1 ) ;
		spec.updateAt( from2Pos, val2 ) ;
		return query( spec ) ;
	}
	
	/**
	 * @see skit.data.value.SRelation
	 */
	public Relationship add( Relationship rs, boolean checkType )
		throws SkitIOException
	{
		SRelation rel = getRelation() ;
		Relationship newRS = rel.newFilledRelationship() ;
		unprojectInto( rs, newRS ) ;
		return new ProjectedRelationship
						( this
						, rel.add( newRS, checkType ) 
						, projectionPositions
						) ;
	}
	
	/**
	 * Remove a relationship at a position in the relation.
	 * This method preferably should not be used,
	 * but is necessary for implementation reasons.
	 * May become obsolete in the future.
	 */
	/*
	public synchronized void removeAt( int pos )
		throws SkitIOException
	{
		getRelation().removeAt( pos ) ;
	}
	*/
	
	/**
	 * Remove a relationship.
	 * If the relationship is not part of the relation,
	 * it will not be removed.
	 */
	public synchronized void remove( Relationship rs )
		throws SkitIOException
	{
		if ( rs.getRelation() == this )
		{
			if ( rs instanceof ProjectedRelationship )
			{
				ProjectedRelationship prs = (ProjectedRelationship)rs ;
				getRelation().remove( prs.getRelationship() ) ;
			}
		}
	}
	
	/**
	 * Remove relationships from the query.
	 * @see skit.data.value.SRelation
	 */
	public void remove( Query remQuery )
		throws SkitIOException
	{
		RelationFunctionality.remove( remQuery ) ;
	}
	
	/**
	 * Update a relationship with values from a new one.
	 * @see skit.data.relation.Relation
	 */
	/*
	public synchronized void updateAt( int pos, Relationship newRS, boolean checkType )
		throws SkitIOException
	{
		if ( isUpdateable() )
		{
			Relationship rs ;
			if ( newRS instanceof ProjectedRelationship )
			{
				rs = ((ProjectedRelationship)newRS).getRelationship() ;
			}
			else
			{
				rs = getRelation().newFilledRelationship() ;
				unprojectInto( newRS, rs ) ;
			}
			getRelation().updateAt( pos, rs, checkType ) ;
		}
	}
	*/
	
	/**
	 * Update a relationship of a relation with values from a new one.
	 * Check if types match if indicated so.
	 * @see skit.data.relation.SRelation
	 */
	public synchronized void update( Relationship oldRS, Relationship newRS, boolean checkType )
		throws SkitIOException
	{
		SRelation rel = getRelation() ;
		if ( oldRS.getRelation() == this )
		{
			if ( oldRS instanceof ProjectedRelationship )
			{
				ProjectedRelationship oldPRS = (ProjectedRelationship)oldRS ;
				Relationship rs ;
				if ( newRS instanceof ProjectedRelationship )
				{
					rs = ((ProjectedRelationship)newRS).getRelationship() ;
				}
				else
				{
					rs = rel.newFilledRelationship() ;
					unprojectInto( newRS, rs ) ;
				}
				rel.update( oldPRS.getRelationship(), rs, checkType ) ;
			}
		}
	}

	/**
	 * Receive the change.
	 * Adapt and ropagate it.
	 */
	public void changeUpdate( ChangeEvent evt, ChangeManager fromMgr )
	{
		fromMgr.changed( new ChangeEvent( this, evt, projTrf ) ) ;
	}
	
}

class ProjectionTransformer
	implements Transformer
{
	private ProjectedRelation projectedRelation ;
	
	public ProjectionTransformer( ProjectedRelation prel )
	{
		projectedRelation = prel ;
	}
	
	public Object transform( Object o )
	{
		if ( o instanceof Relationship )
		{
			return new ProjectedRelationship
							( projectedRelation
							, (Relationship)o
							, projectedRelation.projectionPositions
							) ;
		}
		else
		{
			return null ;
		}
	}
}
