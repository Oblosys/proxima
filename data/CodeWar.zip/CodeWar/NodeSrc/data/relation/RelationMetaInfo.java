package skit.data.relation ;

//import skit.value.* ;
//import skit.value.type.* ;
import java.io.* ;
import java.util.* ;
import skit.* ;
import skit.data.* ;
import skit.data.value.* ;
import com.objectspace.jgl.* ;

/**
 * RelationMetaInfo contains meta information like type of allowed relationships,
 * the names of the fields and information about indexing.
 */
public class RelationMetaInfo extends BasicSSpecialReadWritable
{
	private SType type ;
	private SSequence fieldNames ;
	private SSequence indexFields ;
	
	public RelationMetaInfo()
	{
		this( new SType( BasicSValue.nil() ), BasicSValue.newVector(), BasicSValue.newVector() ) ;
	}
	
	public RelationMetaInfo( SType tp, SSequence fieldNames, SSequence indexFields )
	{
		this.type = tp ;
		this.fieldNames = fieldNames ;
		this.indexFields = indexFields ;
	}
	
	/**
	 * Get the type.
	 */
	public SType getType()
	{
		return type ;
	}

	/**
	 * Get the field names.
	 */
	public SSequence getFieldNames()
	{
		return fieldNames ;
	}

	/**
	 * Get indexing information.
	 */
	public SSequence getIndexFields()
	{
		return indexFields ;
	}

	/**
	 * Write the info for the content on an appropriate writer.
	 */
	public void writeSpecialInfo( SWritableWriter out )
		throws SkitIOException, IOException
	{
		Array a = new Array() ;
		a.pushBack( type ) ;
		a.pushBack( fieldNames ) ;
		a.pushBack( indexFields ) ;
		out.writeSWritables( a.elements() ) ;
	}
	
	/**
	 * Fill already instantiated object with values from SReadableReader
	 * @return the filled readable or a suitable replacement for it.
	 */
	public SSpecialReadable fillWithSReadables( Enumeration in )
		throws IOException, SkitIOException
	{
		type = (SType)in.nextElement() ;
		fieldNames = (SSequence)in.nextElement() ;
		indexFields = (SSequence)in.nextElement() ;
		return this ;
	}
	
	public String toString()
	{
		return "[RelationInfo " + fieldNames + ", index on " + indexFields + "]" ;
	}
	
}