package skit.data.relation ;

import skit.data.value.* ;

/**
 * An entry of a query.
 */
public interface QueryEntry extends SequenceBehavior
{
	/**
	 * @return The relationship.
	 */
	Relationship relationship() ;


}