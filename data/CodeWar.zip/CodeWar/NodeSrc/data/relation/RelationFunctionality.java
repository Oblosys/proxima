package skit.data.relation ;

import java.util.* ;
import skit.data.* ;
import skit.data.value.* ;
import skit.util.* ;
import skit.* ;
//import skit.util.* ;
//import skit.* ;
//import skit.data.* ;
//import com.objectspace.jgl.*;
//import java.io.* ;

/**
 * Shared functionality for relations
 */
public class RelationFunctionality
{
	/**
	 * Get all the relationships in its basic dataform.
	 * I.e. a query giving all of it.
	 *
	 */
	public static Enumeration elements( SRelation rel )
	{
		try
		{
			return //new EnumerationTransformer
						( rel.query( QuerySpec.newAllSpec( rel.getRelshipSize() ) )
						//, new Rship2DataTransformer()
						) ;
		}
		catch ( Exception ex )
		{
			skit.log.Logger.warn( "error in getting elements of relation, returning empty enumeration", ex ) ;
			return new EmptyEnumeration() ;
		}
	}
	
	/**
	 * Remove relationships from the query.
	 * @see skit.data.value.SRelation
	 */
	public static void remove( Query remQuery )
		throws SkitIOException
	{
		for ( ; remQuery.hasMoreElements() ; )
		{
			Relationship rs = remQuery.nextRelationship() ;
			rs.getRelation().remove( rs ) ;
		}
	}
	
	/**
	 * Make a query spec for the relation which will match any relationship.
	 * Meant to be adapted afterwards to match more precise criteria as used in a query.
	 */
	public static QuerySpec newQuerySpec( SRelation rel )
	{
		return QuerySpec.newSeqSpec( rel.getRelshipSize(), SType.TP_ANYTHING ) ;
	}
	
	/**
	 * Make a relationship, filled with default values, of the size required for this relation.
	 */
	public static Relationship newFilledRelationship( SRelation rel )
	{
		return new BasicRelationship
					( null
					, rel.getType()
					, 0
					, BasicSValue.newVector( rel.getRelshipSize(), BasicSValue.nil() )
					) ;
	}
	
}


