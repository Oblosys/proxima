package skit.data.relation ;

import java.util.* ;
import skit.util.* ;
import skit.data.value.* ;

/**
 * Wrapper around Enumeration of Relationships to make it look like a Query.
 */
public class EnumerationQuery
	implements Query
{
	private Enumeration enum ;
	
	public EnumerationQuery( Enumeration elts )
	{
		enum = elts ;
	}
	
	/**
	 * @return The relation to which the query belongs.
	 */
	public Relation getRelation()
	{
		return relation ;
	}
	
	/**
	 * @return The spec of the query.
	 */
	public QuerySpec getQuerySpec()
	{
		return querySpec ;
	}
	
	/**
	 * @see java.util.Enumeration
	 */
	public boolean hasMoreElements()
	{
		return satisfiedEnum.hasMoreElements() ;
	}
	
	/**
	 * @see java.util.Enumeration
	 */
	public Object nextElement()
	{
		if ( hasMoreElements() )
			return satisfiedEnum.nextElement() ;
		else
			return null ;
	}
	
	/**
	 * @see skit.data.relation.Query
	 */
	public Relationship nextRelationship()
	{
		return (Relationship)nextElement() ;
	}
	
	/**
	 * @return The current value in the iteration through the query.
	 */
	/*
	public Relationship getCurrent()
	{
		return current ;
	}
	*/
	
	/**
	 * Step to next value in the query.
	 * @return The current value in the iteration through the query, null if beyond the last one.
	 */
	/*
	public Relationship stepNext()
	{
		return current ;
	}
	*/
	
	/**
	 * Check if gone beyond last value in the query.
	 * @return true if beyond the last value in the query.
	 */
	/*
	public boolean isAtEnd()
	{
		return current == null ;
	}
	*/
	
	
}