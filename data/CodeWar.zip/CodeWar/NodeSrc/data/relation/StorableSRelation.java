package skit.data.relation ;

import com.objectspace.jgl.* ;
import skit.data.store.* ;
//import skit.value.* ;
//import skit.value.type.* ;
import skit.* ;
import skit.util.* ;
import skit.data.value.* ;
import skit.id.* ;
import java.io.* ;
import java.util.Enumeration ;

public class StorableSRelation extends BasicStorable
	implements StorableRelation //, Relation
{
	private final static int MIN_NR_META = 2 ;
	private final static int MIN_NR_DATA = 0 ;
	
	private final static int META_INFO = 0 ;
	private final static int META_INDEX = 1 ;
	
	private int relshipSize = -1 ;
	
	public StorableSRelation()
	{
		this( "root" /* ???? */ ) ;
	}
	
	public StorableSRelation( String storeName )
	{
		super( storeName ) ;
		setIndices( BasicSValue.nil() ) ;
	}
	
	public StorableSRelation( String storeName, UniqueId id )
	{
		super( storeName, id ) ;
	}
	
	public StorableSRelation( RelationMetaInfo metaInfo, String storeName )
	{
		this( storeName ) ;
		setMetaInfo( metaInfo ) ;
	}
	
	/**
	 * Get the minimal number of meta parts.
	 */
	protected int minNrOfMetaParts()
	{
		return MIN_NR_META ;
	}
	
	/**
	 * Get the minimal number of meta parts.
	 */
	protected int minNrOfDataParts()
	{
		return MIN_NR_DATA ;
	}
	
	private void setRelshipSize( int sz )
	{
		relshipSize = sz ;
	}
	
	/**
	 * @return The size of relationships.
	 */
	public int getRelshipSize()
	{
		if ( relshipSize < 0 )
			setRelshipSize( getMetaInfo().getFieldNames().getSize() ) ;
		return relshipSize ;
	}
	
	/**
	 * Get the meta info of a relation.
	 */
	private RelationMetaInfo getMetaInfo()
	{
		return (RelationMetaInfo)getMeta( META_INFO ) ;
	}

	/**
	 * Set the meta info of a relation.
	 * This may influence the actual behavior and performance.
	 */
	public void setMetaInfo( RelationMetaInfo info )
	{
		// ???? checks on size, typing, whatever ....
		putMeta( META_INFO, info ) ;
		setRelshipSize( info.getFieldNames().getSize() ) ;
		setIndexInfo( info.getIndexFields() ) ;
	}
	
	private void setIndexInfo( SSequence inxInfo )
	{
		SSequence inxs = getIndices() ;
		if ( inxs.getSize() < getRelshipSize() )
		{
			inxs = BasicSValue.newVector( relshipSize, BasicSValue.nil() ) ;
		}
		SSequence indices = (SSequence)inxs ;
		for ( Enumeration e = inxInfo.elements() ; e.hasMoreElements() ; )
		{
			Object o = e.nextElement() ;
			//System.out.println( "REL SET INX INF " + o ) ;
			if ( o instanceof SInt )
			{
				//System.out.println( "REL SET INX INF is int " ) ;
				int pos = ((SInt)o).intValue() ;
				if ( pos >= 0 && pos < relshipSize )
				{
					//System.out.println( "REL SET INX INF is " + pos ) ;
					SValue oldInx = indices.at( pos ) ;
					if ( ! ( oldInx instanceof SKeyValue ) )
					{
						indices.updateAt( pos, BasicSValue.newMap() ) ;
						//System.out.println( "REL SET INX INF new map " ) ;
					}
				}
			}
		}
		setIndices( indices ) ;
	}
	
	private SSequence getIndexInfo()
	{
		return getMetaInfo().getIndexFields() ;
	}

	/**
	 * Get the indexes of the relation.
	 */
	private void setIndices( SSequence inxs )
	{
		putMeta( META_INDEX, inxs ) ;
	}

	/**
	 * Get the indexes of the relation.
	 */
	private SSequence getIndices()
	{
		return (SSequence)getMeta( META_INDEX ) ;
	}

	/**
	 * Get a specific index of a position in a relation.
	 */
	private SKeyValue getIndex( int pos )
	{
		SValue inx = getIndices().at( pos ) ;
		return ( inx instanceof SKeyValue ) ? (SKeyValue)inx : null ;
	}

	/**
	 * Get the positions in an index.
	 */
	private static SSequence getPositions( SKeyValue index, SValue val )
	{
		return (SSequence)index.at( val ) ;
	}

	/**
	 * Set the positions in an index.
	 */
	private static void setPositions( SKeyValue index, SValue val, SSequence positions )
	{
		index.updateAt( val, (SValue)positions ) ;
	}

	/**
	 * Set the positions in an index.
	 */
	private static void removePositions( SKeyValue index, SValue val )
	{
		index.removeAt( val ) ;
	}

	/**
	 * Update the index.
	 * Remove indexing on oldVal, update it for newVal.
	 * The position of the relship is the value which is administered.
	 */
	private void updateIndex( SKeyValue index, SValue oldVal, SValue newVal, int relshipPos )
	{
		SInt rPos = BasicSValue.newInt( relshipPos ) ;
		
		if ( oldVal != null )
		{
			SSequence oldPositions = getPositions( index, oldVal ) ;
			if ( oldPositions instanceof SSequence )
				oldPositions.remove( rPos ) ;
			if ( oldPositions.isEmpty() )
				removePositions( index, oldVal ) ;
		}

		if ( newVal != null )
		{
			SSequence newPositions = (SSequence)index.at( newVal ) ;
			if ( ! ( newPositions instanceof SSequence ) )
				setPositions( index, newVal, (SVector)( newPositions = (BasicSValue.newVector()) ) ) ;
			newPositions.updateAppend( rPos ) ;
		}
	}

	/**
	 * Update the indices.
	 * @see skit.data.relation.StoredRelation#updateIndex
	 */
	private void updateIndices( SequenceBehavior oldRS, SequenceBehavior newRS, int relshipPos )
	{
		int max = getRelshipSize() ;
		for ( int i = 0 ; i < max ; i++ )
		{
			SKeyValue index = getIndex( i ) ;
			if ( index != null )
			{
				SValue oldVal = null ;
				SValue newVal = null ;
				if ( oldRS != null )
					oldVal = oldRS.at( i ) ;
				if ( newRS != null )
					newVal = newRS.at( i ) ;
	
				if ( oldVal == null || ( ! oldVal.equals( newVal ) ) )
				{
					updateIndex( index, oldVal, newVal, relshipPos ) ;
				}
			}
		}
	}

	/**
	 * Make a prototypical empty relationship for this relation
	 */
	public Relationship newEmptyRelationship()
	{
		return new BasicRelationship( null, getType(), 0, 0 /*????*/ ) ;
	}

	/**
	 * Make a prototypical relationship for this relation, though filled with default values
	 * and having the right size.
	 */
	public Relationship newFilledRelationship()
	{
		return RelationFunctionality.newFilledRelationship( this ) ;
		//return new BasicRelationship( null, getType(), 0, BasicSValue.newVector( getRelshipSize(), BasicSValue.nil() ) /*????*/ ) ;
	}

	/**
	 * Make a query spec for the relation which will match any relationship.
	 * Meant to be adapted afterwards to match more precise criteria as used in a query.
	 */
	public QuerySpec newQuerySpec()
	{
		return RelationFunctionality.newQuerySpec( this ) ;
	}
	
	/**
	 * @return The number of elements in the relation.
	 */
	public int getSize()
	{
		return dataSize() ;
	}
	
	private Type getTypeMeta()
	{
		return getMetaInfo().getType() ;
	}
	
	/**
	 * Get a relationship of a relation at a position.
	 * @param The position within the relation.
	 * @return The value, or null if none.
	 */
	public Relationship at( int pos )
	//	throws SkitIOException
	{
		SVector data = (SVector)getData( pos ) ;
		if ( data == null )
			return null ;
		else
		{
			try
			{
				return new BasicRelationship( this, getType(), pos, (SVector)data.shallowCopy() ) ;
			}
			catch ( Exception ex )
			{
				skit.log.Logger.warn( "fetching of relship failed, returning empty one", ex ) ;
				return newFilledRelationship() ;
			}
		}
	}
	
	/**
	 * @return The type of the relation.
	 */
	public Type getType()
	{
		return getTypeMeta() ;
	}
	
	/**
	 * Check if relation can be updated.
	 */
	public boolean isUpdateable()
	{
		return true ;
	}
	
	/**
	 * Add a relationship.
	 * Even if the relationship is already part of a relation,
	 * a copy will be added.
	 * Type checking will be done as indicated by checkType.
	 * @return	The copy of the added relationship.
	 */
	public synchronized Relationship add( Relationship rs, boolean checkType )
		throws SkitIOException
	{
		//if ( rs.getRelation() != null ) // ???? done always to ensure the appropriate data stored
		BasicRelationship newRS = (BasicRelationship)newEmptyRelationship() ;
		newRS.updateWith( rs, checkType ) ;

		int pos = allocDataSlot( BasicSValue.empty() ) ;
		newRS.setPosition( pos ) ;
		putData( pos, newRS.getData() ) ;

		updateIndices( null, newRS, pos ) ;
		sync() ;
		notifyDataAsAdd( newRS ) ;
		
		return newRS ;
	}
	
	/**
	 * Remove a relationship at a position in the relation.
	 */
	/*
	private synchronized void removeAt( int pos )
		throws SkitIOException
	{
		Relationship rs = at( pos ) ;
		if ( rs != null )
		{
			updateIndices( rs, null, pos ) ;
			deAllocDataSlot( pos ) ;
			sync() ;
			notifyDataAsRemove( rs ) ;
		}
	}
	*/
	
	/**
	 * Remove a relationship.
	 * If the relationship is not part of the relation,
	 * it will not be removed.
	 */
	public synchronized void remove( Relationship rs )
		throws SkitIOException
	{
		if ( rs.getRelation() == this )
		{
			int pos = rs.getPosition() ;
			updateIndices( rs, null, pos ) ;
			deAllocDataSlot( pos ) ;
			sync() ;
			notifyDataAsRemove( rs ) ;
		}
	}
	
	/**
	 * Remove relationships from the query.
	 * @see skit.data.value.SRelation
	 */
	public void remove( Query remQuery )
		throws SkitIOException
	{
		RelationFunctionality.remove( remQuery ) ;
	}
	
	/**
	 * Update a relationship with values from a new one.
	 * Check if types match if indicated so.
	 * @see skit.data.relation.SRelation
	 */
	/*
	private synchronized void updateAt( int pos, Relationship newRS, boolean checkType )
		throws SkitIOException
	{
		SVector data = (SVector)getData( pos ) ;
		Relationship oldRS = new BasicRelationship( null, null, 0, BasicSValue.newVector( data ) ) ;
		updateIndices( data, newRS, pos ) ;
		data.refillWith( newRS.elements() ) ;
		putData( pos, data ) ;
		sync() ;
		notifyDataAsUpdate( oldRS, newRS ) ;
	}
	*/
	
	/**
	 * Update a relationship of a relation with values from a new one.
	 * Check if types match if indicated so.
	 * @see skit.data.relation.SRelation
	 */
	public synchronized void update( Relationship oldRS, Relationship newRS, boolean checkType )
		throws SkitIOException
	{
		if ( oldRS.getRelation() == this )
		{
			int pos = oldRS.getPosition() ;
			SVector newData = BasicSValue.newVector( newRS.elements() ) ;
			updateIndices( oldRS, newData, pos ) ;
			putData( pos, newData ) ;
			sync() ;
			notifyDataAsUpdate( oldRS, newRS ) ;
		}
	}
	
	/*
	class IsRelationshipPredicate implements Predicate
	{
		public IsRelationshipPredicate()
		{
		}
		
		public boolean predicate( Object o )
		{
			return o instanceof Relationship ;
		}
	}
	*/
	
	class PosToRelshipTransformer implements Transformer
	{
		public PosToRelshipTransformer()
		{
		}
		
		public Object transform( Object o )
		{
			Object res = at( ((SInt)o).intValue() ) ;
			//System.out.println( "QUERY POS TRF " + o + "->" + res ) ;
			return res ;
		}
	}
	
	class Rship2DataTransformer implements Transformer
	{
		public Rship2DataTransformer()
		{
		}
		
		public Object transform( Object o )
		{
			return ((BasicRelationship)o).getData() ;
		}
	}
	
	/**
	 * Get all the relationships in its basic dataform.
	 * I.e. a query giving all of it.
	 *
	 */
	public Enumeration elements()
	{
		return RelationFunctionality.elements( this ) ;
	}
	
	
	/**
	 * Query a relation.
	 * @return A query on the relation.
	 */
	public Query query( QuerySpec spec )
		throws SkitIOException
	{
		Enumeration basicEnum ;
		
		if ( getRelshipSize() != spec.getSize() )
		{
			basicEnum = new EmptyEnumeration() ;
		}
		else
		{
			SSequence positions = null ;
			for ( int i = 0 ; i < relshipSize ; i++ )
			{
				SKeyValue index = getIndex( i ) ;
				SValue val = spec.at( i ) ;
				//System.out.println( "QUERY INX & VAL " + index + "/" + val ) ;
				if ( index != null && spec.isIndexable( val ) )
				{
					//positions = getPositions( index, spec.at( i ) ).intersect( positions ) ;
					positions = getPositions( index, val ) ;
					break ;
				}
			}
			basicEnum = new EnumerationTransformer
								( ( positions == null ? dataPositions() : positions.elements() )
								, new PosToRelshipTransformer()
								) ;
		}
		
		return new BasicSequentialQuery
					( this, spec
					, basicEnum
					) ;
	}
	
	/**
	 * Get all the fixed svalues to be put on the writer.
	 * Meant to be overridden/implemented in subclass.
	 */
	/*
	private Enumeration getWriterFixedSValues( )
	{
		Array a = new Array() ;
		a.pushBack( SValue.newInt( firstFree ) ) ;
		a.pushBack( SValue.newInt( sizeFree ) ) ;
		return a.elements() ;
	}
	*/
	
	/**
	 * Write the info for the content on an appropriate writer.
	 */
	/*
	public void writeSpecialInfo( SWritableWriter out )
		throws SkitIOException, IOException
	{
		//out.writeSWritables( getWriterFixedSValues() ) ;
		super.writeSpecialInfo( out ) ;
		//out.writeSWritables( getWriterFixedSValues( ) ) ;
	}
	*/
	
	/**
	 * Fill already instantiated object with values from SReadableReader.
	 * In this case no extra info has to be retrieved, except setting the size.
	 * @return the filled readable or a suitable replacement for it.
	 */
	/*
	public void fillContentWithSReadables( Enumeration in )
		throws IOException, SkitIOException
	{
		super.fillContentWithSReadables( in ) ;
		setRelshipSize( getMetaInfo().getFieldNames().getSize() ) ;
		//return this ;
	}
	*/
	
	/*
	public String toString()
	{
		StringBuffer buf = new StringBuffer() ;

		skit.util.Misc.enumerationToString( buf, dataElements(), "<< ", ", ", " >>" ) ;
		
		return buf.toString() ;
	}
	*/
	

	/**
	 * Update with values from other one.
	 * This method is not yet correctly implemented.
	 */
	public void updateWith( SRelation other )
	{
		// ????
	}
		
	/**
	 * Update with values from other one.
	 * This method is not yet correctly implemented.
	 */
	public void updateWith( SValue other )
	{
		updateWith( (SRelation)other ) ;
	}
		
	/**
	 * Make a nice string representation.
	 * Append it on the StringBuffer
	 */
	/*
	public void appendStringRepr( StringBuffer buf )
	{
		SSequenceFunctionality.appendStringRepr( buf, elements() ) ;
		//SKeyValueFunctionality.toStringBuffer( buf, this ) ;
		//PrintableFunctionality.appendStringRepr( buf, this, PrintableFunctionality.BRACKET_DEFAULT ) ;
	}
	*/

	/**
	 * Meant to be overridden.
	 */
	/*
	public void toStringBuffer( StringBuffer buf )
	{
	}
	*/
	
	
}