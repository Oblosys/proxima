package skit.data.relation ;

import com.objectspace.jgl.*;
import java.util.* ;
import skit.id.* ;
import skit.util.* ;
import skit.data.store.* ;
//import skit.value.type.* ;
//import skit.value.* ;
import skit.* ;
import skit.data.value.* ;

/**
 * A BasicRelationship is a container for set of field values.
 *
 * @see skit.data.value.SRelation
 * @see skit.data.relation.Relationship
 */
public class BasicRelationship extends ObjectFunctionality
	implements Relationship
{
	private SRelation relation ;
	private int posInRelation ;
	private Type type ;
	private SVector data ;
	private int[] projectionPositions ;
	
	public BasicRelationship( SRelation rel, Type tp, int pos, SVector v )
	{
		data = v ;
		setRelationInfo( rel, pos ) ;
		type = tp ;
	}
	
	public BasicRelationship( SRelation rel, Type tp, int pos, Enumeration e )
	{
		this( rel, tp, pos, BasicSValue.newVector( e ) ) ;
	}
	
	public BasicRelationship( SRelation rel, Type tp, int pos, int size )
	{
		this( rel, tp, pos, BasicSValue.newVector( size ) ) ;
	}
	
	public BasicRelationship( int size )
	{
		this( null, null, 0, BasicSValue.newVector( size ) ) ;
	}
	
	protected void setRelationInfo( SRelation rel, int pos )
	{
		relation = rel ;
		posInRelation = pos ;
	}
	
	/**
	 * @return The relation to which the relationship belongs.
	 */
	public SRelation getRelation()
	{
		return relation ;
	}
	
	/**
	 * @return The raw data behind the relationship.
	 */
	public SVector getData()
	{
		return data ;
	}
	
	/**
	 * @return The type of the relationship.
	 */
	public Type getType()
	{
		return type ;
	}
	
	/**
	 * Get the position in the relation.
	 */
	public int getPosition( )
	{
		return posInRelation ;
	}
	
	/**
	 * Set the position in the relation.
	 */
	protected void setPosition( int p )
	{
		posInRelation = p ;
	}
	
	/**
	 * Check if Relationship can be updated.
	 * This is the case if it belongs to no relation or the
	 * relation itself is updateable.
	 */
	public boolean isUpdateable()
	{
		return relation == null || relation.isUpdateable() ;
	}
	
	/**
	 * Update relationship with values from new one.
	 * Perform typechecking if indicated so.
	 */
	public synchronized void updateWith( Relationship newRS, boolean checkType )
	{
		// ???? type checking
		data.refillWith( newRS.elements() ) ;
	}
	
	/**
	 * @return The number of fields
	 */
	public synchronized int getSize()
	{
		return data.getSize() ;
	}
	
	/**
	 * @return true if empty.
	 */
	public boolean isEmpty()
	{
		return getSize() == 0 ;
	}
	
	/**
	 * Get the values of the fields.
	 */
	public Enumeration elements()
	{
		return data.elements() ;
	}
	
	/**
	 * @see skit.data.value.SVector
	 */
	public synchronized SValue at( int pos )
	{
		return data.at( pos ) ;
	}
	
	/**
	 * @see skit.data.value.SVector
	 */
	public synchronized void updateAt( int pos, SValue v )
	{
		data.updateAt( pos, v ) ;
	}
	
	/**
	 * @see skit.data.value.SVector
	 */
	public synchronized void updateAppend( SValue v )
	{
		data.updateAppend( v ) ;
	}

	/**
	 * @see skit.data.value.SVector
	 */
	public synchronized void remove( SValue v )
	{
		data.remove( v ) ;
	}
	
	/**
	 * Get a copy of a relationship.
	 * The new relationship does not belong to any relation.
	 * @return The copy.
	 */
	/*
	public Relationship copy()
		throws SkitException
	{
		// ???? todo: deeper
		return shallowCopy() ; 
	}
	*/
	
	/**
	 * @see skit.ObjectFunctionality.
	 */
	protected void postShallowCopy()
		throws SkitException
	{
		super.postShallowCopy() ;
		disconnectFromRelation() ;
		data = (SVector)data.shallowCopy() ;
	}
	
	/**
	 * Disconnect the relationship from the relation.
	 * This method should not be used, is meant for internal use only.
	 * @see skit.data.relation.StoredRelation
	 */
	protected void disconnectFromRelation()
	{
		relation = null ;
	}
	
	/**
	 * Get the id.
	 */
	/*
	public Id getId()
	{
		return new RelationshipId( this ) ;
	}
	*/
	
	/**
	 * Set the id.
	 * Does not do anything here.
	 */
	/*
	public void setId( Id id )
	{
	}
	*/
	
	/**
	 * Make a nice string representation.
	 * Append it on the StringBuffer
	 */
	public void appendStringRepr( StringBuffer buf )
	{
		PrintableFunctionality.appendStringRepr( buf, elements(), PrintableFunctionality.BRACKET_RSHIP ) ;
	}

	/**
	 * Make a string representation, to be used by appendStringRepr.
	 */
	/*
	public void toStringBuffer( StringBuffer buf )
	{
		skit.log.Logger.log( "basic rel: should not be here!!!" ) ;
	}
	*/

	/**
	 * Make sure the value is available
	 */
	/*
	public void use()
		throws skit.SkitIOException
	{
	}
	*/
	
	/* // later ????
	public boolean equals( Object o )
	{
		if ( ! ( o instanceof Relationship ) )
			return false ;
		Relationship otherRS = (Relationship)o ;
		SRelation myRel = getRelation() ;
		SRelation otherRel = otherRS.getRelation() ;
		if ( ! ( getRelation
	}
	*/
	
	public String toString()
	{
		return PrintableFunctionality.toString( this ) ;
	}
	
}