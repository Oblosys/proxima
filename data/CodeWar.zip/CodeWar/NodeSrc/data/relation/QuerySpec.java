package skit.data.relation ;

import skit.* ;
import skit.util.* ;
//import skit.value.* ;
//import skit.value.type.* ;
import skit.data.value.* ;

/**
 * A QuerySpec describes a query on a relation.
 * Currently this is equivalent to the type mechanism used.
 * @see skit.value.type.Type
 * @see skit.data.value.SType
 */
public class QuerySpec
	implements Printable
{
	private SType spec ;
	
	public QuerySpec( SType t )
	{
		spec = t ;
	}
	
	protected QuerySpec( int size, SValue defaultVal, SValue kind )
	{
		SVector vec = BasicSValue.newVector( ( kind == null ? size : size + 1 ), defaultVal ) ;
		if ( kind != null )
			vec.updateAt( 0, kind ) ;
		spec = new SType( vec ) ;
	}
	
	public static QuerySpec newSeqSpec( int size, SValue defaultVal )
	{
		QuerySpec res = new QuerySpec( size, defaultVal, SType.TP_SEQ ) ; 
		return res ;
	}
	
	public static QuerySpec newAllSpec( int size )
	{
		QuerySpec res = newSeqSpec( size, SType.TP_ANYTHING ) ;
		return res ;
	}
	
	/**
	 * Make a new QuerySpec by parsing/reading a string.
	 */
	public static QuerySpec from( String str )
		throws SkitTypeException
	{
		return new QuerySpec( SType.from( "(seq " + str + ")" ) ) ;
	}
	
	/**
	 * Check if a value satisfies a spec.
	 */
	public boolean satisfies( SValue val )
	{
		return spec.satisfies( val ) ;
	}
	
	/**
	 * Make a nice string representation.
	 * Append it on the StringBuffer
	 */
	public void appendStringRepr( StringBuffer buf )
	{
		buf.append( spec.toString() ) ;
	}

	public String toString()
	{
		return PrintableFunctionality.toString( this ) ;
	}
	
	/**
	 * Get the size, the number of values to check.
	 */
	public int getSize(  )
	{
		return spec.getSize() ;
	}
	
	/**
	 * Get a value of a spec at a position.
	 */
	public SValue at( int pos )
	{
		return spec.at( pos ) ;
	}
	
	/**
	 * Update a value of a spec at a position.
	 */
	public void updateAt( int pos, SValue v )
	{
		spec.updateAt( pos, v ) ;
	}
	
	/**
	 * Get a value of a spec at a position.
	 */
	public boolean isIndexable( SValue val )
	{
		return SType.isIndexable( val ) ;
	}
	
}