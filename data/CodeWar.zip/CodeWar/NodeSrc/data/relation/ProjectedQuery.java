package skit.data.relation ;

import java.util.* ;
import skit.util.* ;
import skit.data.value.* ;

/**
 * Adapting a given query by projection.
 */
public class ProjectedQuery
	implements Query
{
	private Query query ;
	private int[] projectionPositions ;
	private QuerySpec querySpec ;
	private ProjectedRelation relation ;
	
	public ProjectedQuery( ProjectedRelation rel, Query q, QuerySpec sp, int[] proj )
	{
		query = q ;
		projectionPositions = proj ;
		querySpec = sp ;
		relation = rel ;
	}
	
	/**
	 * @return The relation to which the query belongs.
	 */
	/*
	public Relation getRelation()
	{
		return relation ;
	}
	*/
	
	/**
	 * @return The spec of the query.
	 */
	/*
	public QuerySpec getQuerySpec()
	{
		return querySpec ;
	}
	*/
	
	/**
	 * @see java.util.Enumeration
	 */
	public boolean hasMoreElements()
	{
		return query.hasMoreElements() ;
	}
	
	/**
	 * @see java.util.Enumeration
	 */
	public Object nextElement()
	{
		if ( hasMoreElements() )
			return new ProjectedRelationship( relation, (Relationship)query.nextElement(), projectionPositions ) ;
		else
			return null ;
	}
	
	/**
	 * @see skit.data.relation.Query
	 */
	public Relationship nextRelationship()
	{
		return (Relationship)nextElement() ;
	}
	
	/**
	 * @return The current value in the iteration through the query.
	 */
	/*
	public Relationship getCurrent()
	{
		return current ;
	}
	*/
	
	/**
	 * Step to next value in the query.
	 * @return The current value in the iteration through the query, null if beyond the last one.
	 */
	/*
	public Relationship stepNext()
	{
		return current ;
	}
	*/
	
	/**
	 * Check if gone beyond last value in the query.
	 * @return true if beyond the last value in the query.
	 */
	/*
	public boolean isAtEnd()
	{
		return current == null ;
	}
	*/
	
	
}