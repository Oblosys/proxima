package skit.data.relation ;

import java.util.* ;
import skit.* ;
import skit.data.* ;
//import skit.util.* ;
//import skit.* ;
import skit.data.value.* ;
import skit.data.store.* ;
//import com.objectspace.jgl.*;
//import java.io.* ;

/**
 * Skit value.
 * Relation which is storable.
 */
public interface StorableRelation extends SRelation, SComposite, Storable
{
		
}



