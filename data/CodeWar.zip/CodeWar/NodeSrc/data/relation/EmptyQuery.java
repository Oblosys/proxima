package skit.data.relation ;

import skit.data.value.* ;
import skit.util.* ;

public class EmptyQuery extends EmptyEnumeration
	implements Query
{
	/**
	 * Get the next Relationship, or null if none available.
	 */
	public Relationship nextRelationship()
	{
		return (Relationship)nextElement() ;
	}
	
	
}