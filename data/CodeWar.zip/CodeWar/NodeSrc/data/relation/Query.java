package skit.data.relation ;

import skit.data.value.* ;

public interface Query extends java.util.Enumeration
{
	/**
	 * @return The relation to which the query belongs.
	 */
	//public Relation getRelation() ;
	
	/**
	 * @return The spec of the query.
	 */
	//public QuerySpec getQuerySpec() ;
	
	/**
	 * @return The current value in the iteration through the query.
	 */
	//public Relationship getCurrent() ;
	
	/**
	 * Get the next Relationship, or null if none available.
	 */
	public Relationship nextRelationship() ;
	
	/**
	 * Check if gone beyond last value in the query.
	 * @return true if beyond the last value in the query.
	 */
	//public boolean isAtEnd() ;
	
	
}