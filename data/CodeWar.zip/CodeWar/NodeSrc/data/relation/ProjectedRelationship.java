package skit.data.relation ;

import com.objectspace.jgl.*;
import java.util.* ;
import skit.id.* ;
import skit.util.* ;
import skit.data.store.* ;
//import skit.value.type.* ;
//import skit.value.* ;
import skit.* ;
import skit.data.value.* ;

/**
 * A ProjectedRelationship remaps positions of another Relationship
 *
 * @see skit.data.relation.Relation
 * @see skit.data.relation.Relationship
 */
public class ProjectedRelationship extends ObjectFunctionality
	implements Relationship
{
	private Relationship relship ;
	private int[] projectionPositions ;
	private ProjectedRelation relation ;
	
	public ProjectedRelationship( ProjectedRelation rel, Relationship rs, int[] proj )
	{
		relship = rs ;
		relation = rel ;
		projectionPositions = proj ;
		if ( projectionPositions == null )
		{
			projectionPositions = new int[ rs.getSize() ] ;
			for ( int i = 0 ; i < projectionPositions.length ; i++ )
				projectionPositions[ i ] = i ;
		}
	}
	
	/**
	 * @return The original relationship.
	 */
	public Relationship getRelationship()
	{
		return relship ;
	}
	
	/**
	 * @return The relation to which the relationship belongs.
	 */
	public SRelation getRelation()
	{
		return relation ;
	}
	
	/**
	 * @return The type of the relationship.
	 */
	public Type getType()
	{
		if ( relation != null )
			return relation.getType() ;
		else
			return relship.getType() ; // ????
	}
	
	/**
	 * Get the position in the relation.
	 */
	public int getPosition( )
	{
		return relship.getPosition() ;
	}
	
	/**
	 * Check if Relationship can be updated.
	 */
	public boolean isUpdateable()
	{
		return relship.isUpdateable() ;
	}
	
	/**
	 * Update relationship with values from new one.
	 * Perform typechecking if indicated so.
	 */
	public void updateWith( Relationship newRS, boolean checkType )
	{
		// ???? type checking
		int size = Math.min( newRS.getSize(), getSize() ) ;
		for ( int i = 0 ; i < size ; i++ )
		{
			updateAt( i, newRS.at( i ) ) ;
		}
	}
	
	/**
	 * @return The number of fields
	 */
	public int getSize()
	{
		return projectionPositions.length ;
	}
	
	/**
	 * @return true if empty.
	 */
	public boolean isEmpty()
	{
		return getSize() == 0 ;
	}
	
	class ProjectedEnum implements Enumeration
	{
		private int counter ;
		
		public ProjectedEnum()
		{
			counter = 0 ;
		}
		
		public boolean hasMoreElements()
		{
			return counter < projectionPositions.length ;
		}
		
		public Object nextElement()
		{
			if ( hasMoreElements() )
				return at( counter++ ) ;
			else
				return null ;
		}
	}
	
	/**
	 * Get the values of the fields.
	 */
	public Enumeration elements()
	{
		return new ProjectedEnum() ;
	}
	
	/**
	 * @see skit.data.value.SVector
	 */
	public SValue at( int pos )
	{
		return relship.at( projectionPositions[ pos ] ) ;
	}
	
	/**
	 * @see skit.data.value.SVector
	 */
	public void updateAt( int pos, SValue v )
	{
		relship.updateAt( projectionPositions[ pos ], v ) ;
	}
	
	/**
	 * @see skit.data.value.SVector
	 */
	public void updateAppend( SValue v )
	{
		relship.updateAppend( v ) ; // ????
	}

	/**
	 * @see skit.data.value.SVector
	 */
	public void remove( SValue v )
	{
		// relship.remove( v ) ; // ????
	}
	
	/**
	 * Get a copy of a relationship.
	 * The new relationship does not belong to any relation.
	 * @return The copy.
	 */
	/*
	public Relationship copy()
		throws SkitException
	{
		ProjectedRelationship res = new ProjectedRelationship( null, relship.copy(), projectionPositions ) ;
		return res ; 
	}
	*/

	/**
	 * @see skit.ObjectFunctionality.
	 */
	protected void postShallowCopy()
		throws SkitException
	{
		super.postShallowCopy() ;
		//disconnectFromRelation() ;
		relship = (Relationship)relship.shallowCopy() ;
	}
	

	
	/**
	 * Get a copy of a relationship, do not copy the underlying values.
	 * The new relationship does not belong to any relation.
	 * @return The copy.
	 */
	/*
	public Relationship shallowCopy()
		throws SkitException
	{
		ProjectedRelationship res = new ProjectedRelationship( null, relship.shallowCopy(), projectionPositions ) ;
		return res ; 
	}
	*/
	
	/**
	 * Get the id.
	 */
	/*
	public Id getId()
	{
		return relship.getId() ;
	}
	*/
	
	/**
	 * Set the id.
	 * Does not do anything here.
	 */
	/*
	public void setId( Id id )
	{
	}
	*/
	
	/**
	 * Make a nice string representation.
	 * Append it on the StringBuffer
	 */
	public void appendStringRepr( StringBuffer buf )
	{
		PrintableFunctionality.appendStringRepr( buf, elements(), PrintableFunctionality.BRACKET_RSHIP ) ;
	}

	/**
	 * Make a string representation, to be used by appendStringRepr.
	 */
	/*
	public void toStringBuffer( StringBuffer buf )
	{
		skit.log.Logger.log( "proj rel: should not be here!!!" ) ;
	}
	*/

	/**
	 * Make sure the value is available
	 */
	/*
	public void use()
		throws skit.SkitIOException
	{
	}
	*/
	
	public String toString()
	{
		return PrintableFunctionality.toString( this ) ;
	}
	
}