package skit.data.relation ;

import skit.id.* ;

/**
 * An identification for a Relationship
 */
public class RelationshipId extends Id
{
	private Id parentId ;
	private int posInRelation ;
	
	public RelationshipId( Relationship rs )
	{
		parentId = (Id)(rs.getRelation().getId()) ;
		posInRelation = rs.getPosition() ;
	}
	
	/**
	 * The representation as a string of the part administered here.
	 * Meant to be overridden.
	 * 
	 */
	protected String myStringRepr()
	{
		return Integer.toString( posInRelation ) ;
	}
	
	
	/**
	 * The hashcode of the part administered here.
	 * Meant to be overridden.
	 * 
	 */
	protected int myHashCode()
	{
		return posInRelation ;
	}
	
	/**
	 * @return the parent id, or null if no parent.
	 */
	public Id parentId()
	{
		return parentId ;
	}
	
	/**
	 * The equals test of the part administered here.
	 * Meant to be overridden.
	 * 
	 */
	protected boolean myEquals( Id id )
	{
		return ( id instanceof RelationshipId )
			&& ( ((RelationshipId)id).posInRelation == posInRelation )
			;
	}
	
}