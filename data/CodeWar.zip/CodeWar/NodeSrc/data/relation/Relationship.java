package skit.data.relation ;

import java.util.* ;
import skit.* ;
import skit.id.* ;
import skit.util.* ;
import skit.data.value.* ;
//import skit.value.* ;
//import skit.value.type.* ;


/**
 * A Relationship is a set of field values.
 * Each field can be indexed with an integer, the position.
 * A field can only contain Node's or SValues.
 *
 * @see skit.data.node.Node
 * @see skit.data.value.SValue
 */
public interface Relationship extends SequenceBehavior, Printable, ObjectBehavior //, Idable
{
	/**
	 * @return The relation to which the relationship belongs.
	 */
	public SRelation getRelation() ;
	
	/**
	 * @return The type of the relationship.
	 */
	public Type getType() ;
	
	/**
	 * Get the position in the relation.
	 */
	public int getPosition( ) ;
	
	/**
	 * Update relationship with values from new one.
	 * Perform typechecking if indicated so.
	 */
	public void updateWith( Relationship newRS, boolean checkType ) ;
	
	/**
	 * Get a copy.
	 */
	//public Relationship copy()
	//	throws SkitException ;
	
	/**
	 * Get a copy, but only the top level of an object structure.
	 */
	//public Relationship shallowCopy()
	//	throws SkitException ;
	
}