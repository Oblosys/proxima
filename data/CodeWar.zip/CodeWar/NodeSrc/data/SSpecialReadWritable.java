package skit.data ;

import java.io.* ;
import java.util.* ;
import skit.* ;
import skit.data.* ;
import skit.data.value.* ;

/**
 *
 * @see skit.data.value.SWritableWriter
 * @see skit.data.value.SReadableReader
 */
public interface SSpecialReadWritable extends SReadWritable, SSpecialWritable, SSpecialReadable
{
}