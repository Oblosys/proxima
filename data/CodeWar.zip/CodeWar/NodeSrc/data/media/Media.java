package skit.data.media ;

import skit.* ;

/**
 * A Media stores (i.e. reads/writes) binary data.
 */
public interface Media
{
	/**
	 * Read data from the current position.
	 * @param buf	The buffer to put the data in.
	 * @param bufPos	The position in the buffer to put the data in.
	 * @param amount	How much to read.
	 * @return Amount read.
	 */
	public long readBytes( byte[] buf, long bufPos, long amount )
		throws SkitIOException ;
	
	/**
	 * Write data to the current position.
	 * @param buf	The buffer to get the data from.
	 * @param bufPos	The position in the buffer to get the data from.
	 * @param amount	How much to write.
	 * @return Amount written.
	 */
	public long writeBytes( byte[] buf, long bufPos, long amount )
		throws SkitIOException ;
	
	/**
	 * Get the name of the media.
	 */
	public String getName() ;
	
}