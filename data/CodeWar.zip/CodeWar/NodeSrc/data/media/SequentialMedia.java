package skit.data.media ;

import skit.* ;

/**
 * The sequential variant of Media.
 * @see skit.data.media.Media
 */
public interface SequentialMedia extends Media
{
}