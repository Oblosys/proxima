package skit.data.media ;

import skit.* ;

/**
 * The randomaccess  variant of Media.
 * A RandomAccessMedia stores (i.e. reads/writes) binary data at certain positions.
 * A RandomAccessMedia maintains a writing position.
 */
public interface RandomAccessMedia extends Media
{
	/**
	 * Set the position.
	 */
	public void setPosition( long pos )
		throws SkitIOException ;
	
	/**
	 * Get the position.
	 */
	public long getPosition()
		throws SkitIOException ;
	
}