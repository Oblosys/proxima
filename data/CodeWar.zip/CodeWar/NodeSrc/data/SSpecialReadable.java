package skit.data ;

import skit.* ;
import skit.data.* ;
import skit.data.value.* ;
import java.io.* ;
import java.util.* ;

/**
 * Something which can be read as a SReadable's (and later be read as such),
 * using SReadableReader.
 * A SSpecialReadable reads itself from an Enumeration of SReadables, assuming that
 * already the correct instances of classes have been made, according to some mime typing.
 * @see skit.data.value.SReadableReader
 * @see skit.data.value.SSpecialWritable
 */
public interface SSpecialReadable extends SReadable
{
	/**
	 * Fill already instantiated object with values from SReadableReader
	 * @return the filled readable or a suitable replacement for it.
	 */
	public SSpecialReadable fillWithSReadables( Enumeration in )
		throws IOException, SkitIOException ;
	
}