package skit.data ;

import skit.* ;
import skit.data.* ;
import skit.data.value.* ;
import java.io.* ;

/**
 * Something which can be written as a SValue (and later be read as such),
 * using SWritableWriter.
 * A SSpecialWritable writes itself a special value, with some mime typing.
 * @see skit.data.value.SWritableWriter
 * @see skit.data.value.SSpecialReadable
 */
public interface SSpecialWritable extends SWritable
{
	/**
	 * Write the info for the content on an appropriate writer.
	 */
	public void writeSpecialInfo( SWritableWriter out )
		throws SkitIOException, IOException ;

}