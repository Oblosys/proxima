package skit.data.value ;

public class Pair
{
	public SValue head, tail ;
	
	public Pair()
	{
	}

	public Pair( SValue h, SValue t )
	{
		head = h ;
		tail = t ;
	}

	public int hashCode()
	{
		return head.hashCode() ^ tail.hashCode() ;
	}
	
	public boolean equals( Object o )
	{
			return
				o instanceof Pair
			&&	((Pair)o).head == head
			&&	((Pair)o).tail == tail ;
	}
	
}
