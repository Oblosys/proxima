package skit.data.store ;

import skit.util.* ;

/**
 * Showing the progress of the storing on a store.
 */
public class StoreProgress
	implements Progress
{
	private float fractionBreak ;
	private long startTime ;
	
	public StoreProgress()
	{
	}
	
	/**
	 * Start.
	 * @param	total	The amount to be done.
	 */
	public void start( int total, String what )
	{
		System.out.print( what + " (total of " + total + " items)" ) ;
		fractionBreak = getNotificationFraction() ;
		startTime = Timestamp.timestamp() ;
	}

	/**
	 * The fraction of change which causes a progress notification.
	 */
	public float getNotificationFraction(  )
	{
		return 0.1f ;
	}

	/**
	 * Notify the fraction done.
	 */
	public void notify( float fractDone )
	{
		if ( fractDone >= fractionBreak )
		{
			System.out.print( " " + Math.round( fractDone * 100 ) + "%" ) ;
			fractionBreak += getNotificationFraction() ;
		}
	}

	/**
	 * Stop.
	 */
	public void stop()
	{
		long endTime = Timestamp.timestamp() ;
		System.out.println( " done in " + (((float)(endTime-startTime))/1000) + " seconds" ) ;
	}

}
