package skit.data.store ;

import skit.data.value.* ;
import skit.util.* ;
import skit.data.* ;
import skit.id.* ;
import skit.* ;
import java.io.* ;
import java.util.* ;

/**
 * Something which is storable (on a store) and can be retrieved via an id.
 */
public interface Storable extends Idable, SValue, SSpecialReadWritable, Printable
{
	/**
	 * Get the id and make sure its there indeed.
	 */
	//public UniqueId getEnsureId( String storeName )
	//	throws SkitIOException ;
	
	/**
	 * Get the id and make sure its there indeed.
	 * It is assumed that the storeName is known.
	 */
	//public UniqueId getEnsureId()
	//	throws SkitIOException ;
	
	/**
	 * Get the size.
	 */
	public int getSize()
		throws SkitIOException ;
	
	/**
	 * Make sure the value is synchronised with external storage
	 */
	public void sync()
		throws skit.SkitIOException ;
		
	/**
	 * Make sure the value is available
	 */
	public void use()
		throws skit.SkitIOException ;

	
	/**
	 * Check if composite can be updated.
	 */
	public boolean isUpdateable() ;
	
	
	//public String toString() ;
	
	/**
	 * Fill the content of an already instantiated object with values from SReadableReader.
	 */
	//public void fillContentWithSReadables( Enumeration in )
	//	throws IOException, SkitIOException ;
	
	/**
	 * Write the info for the content on an appropriate writer.
	 */
	//public void writeSpecialContentInfo( SWritableWriter out )
	//	throws SkitIOException, IOException ;
	
	/**
	 * Get the storeparts.
	 * A StoreParts is stored by a store and used by the Storable to access data.
	 */
	public StoreParts getStoreParts() ;
	
	
	
}