package skit.data.store ;

import skit.* ;
import skit.data.value.* ;
import skit.data.relation.* ;
import skit.data.node.* ;

/**
 * A StoreInitialiser for stored values.
 */
public class StoredStoreInitialiser
	implements StoreInitialiser
{
	/**
	 * Make the root.
	 */
	public SNode makeRoot( Store store )
		throws skit.SkitException, java.io.IOException
	{
		SNode root = BasicSValue.newStoredNode( store.getName() ) ;
		return root ;
	}

	/**
	 * Make the directory.
	 */
	public StorableRelation makeDirectory( Store store )
		throws skit.SkitException, java.io.IOException
	{
		RelationMetaInfo rmeta =
			new RelationMetaInfo
					( new SType( BasicSValue.nil() ) // ???? later...
					, (SSequence)BasicSValue.from( "#(parent name child)" )
					, (SSequence)BasicSValue.from( "#(0 1)" )
					) ;
		StorableRelation dir = BasicSValue.newStoredRelation( rmeta, store.getName() ) ;
		return dir ;
	}

	/**
	 * Fill the directory.
	 */
	public void fillDirectory( Store store, SRelation dir )
		throws skit.SkitException, java.io.IOException
	{
		Relationship rs ;
		SNode subdir = subdir = BasicSValue.newStoredNode( store.getName() ) ;
		subdir.sync() ;
		System.out.println( "FILL DIR SUB " + subdir ) ;

		rs = dir.newFilledRelationship() ;
		rs.updateAt( 0, store.getRoot() ) ;
		rs.updateAt( 1, BasicSValue.newString( "Relations" ) ) ;
		rs.updateAt( 2, subdir ) ;
		dir.add( rs, false ) ;

		rs = dir.newFilledRelationship() ;
		rs.updateAt( 0, subdir ) ;
		rs.updateAt( 1, BasicSValue.newString( "Directory" ) ) ;
		rs.updateAt( 2, dir ) ;
		dir.add( rs, false ) ;
	}

}