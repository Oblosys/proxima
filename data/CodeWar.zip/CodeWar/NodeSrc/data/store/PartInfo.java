package skit.data.store ;

import com.objectspace.jgl.*;
import java.io.* ;
import java.util.* ;
import skit.util.* ;
import skit.* ;
import skit.data.value.* ;
import skit.data.* ;
//import skit.* ;

/**
 * A PartInfo maintains information about parts of
 * a BasicStorable.
 * This information is used to subdivide a BasicStorable for storage efficiency.
 *
 * @see skit.data.store.BasicStorable
 * @see skit.data.store.Store
 */
public class PartInfo extends BasicSSpecialReadWritable
//	implements Cloneable
//	implements SValueable
{
	private static int ILLEGAL_POS = BasicStorable.ILLEGAL_POS ;
	
	private static DataOfOnePartTransformer dataTrf ;
	private static IsDataPredicate isDataPred ;
	
	static
	{
		dataTrf = new DataOfOnePartTransformer() ;
		isDataPred = new IsDataPredicate() ;
	}
	
	protected Array info = null ;
	
	private int firstFree = ILLEGAL_POS ;
	private int sizeFree = 0 ;
	
	protected PartInfo( int size )
	{
		info = new Array( size ) ;
	}
	
	public PartInfo( )
	{
		this( 0 ) ;
	}
	
	private void setSize( int newS )
	{
		info.setSize( newS ) ;
	}
	
	/**
	 * Get the size.
	 */
	protected int getCapacity()
	{
		return info.size() ;
	}

	/**
	 * Get the size.
	 */
	protected int getSize()
	{
		return getCapacity() - sizeFree ;
	}

	/**
	 * Get the data at a position.
	 */
	protected synchronized SReadWritable atUnWrapped( int pos )
	{
		return (SReadWritable)info.at( pos ) ;
	}

	/**
	 * Get the data at a position.
	 * @return 	null if no data at the position.
	 */
	protected SReadWritable at( int pos )
	{
		Object aPart = atUnWrapped( pos ) ;
		if ( aPart instanceof OnePartInfo )
			return ((OnePartInfo)aPart).getData() ;
		else
			return null ;
	}

	/**
	 * Replace the data.
	 */
	private synchronized void putUnWrapped( int pos, SReadWritable data )
	{
		info.put( pos, data ) ;
	}

	/**
	 * Add the data.
	 * @return	the position where added.
	 */
	private int addLast( SReadWritable data )
	{
		return addLastUnWrapped( new OnePartInfo( data ) ) ;
	}

	/**
	 * Add the data.
	 * @return	the position where added.
	 */
	private synchronized int addLastUnWrapped( SReadWritable data )
	{
		int res = info.size() ;
		info.pushBack( data ) ;
		return res ;
	}

	/**
	 * Replace the data.
	 */
	protected void put( int pos, SReadWritable data )
	{
		putUnWrapped( pos, new OnePartInfo( data ) ) ;
	}

	/**
	 * Get data.
	 */
	protected SReadWritable get( int pos )
	{
		return at( pos ) ;
	}

	/**
	 * Allocate a slot for usage.
	 * @return	The slot number.
	 */
	protected synchronized int allocSlot( SReadWritable defaultValue )
	{
		int pos ;
		if ( firstFree != ILLEGAL_POS )
		{
			pos = firstFree ;
			firstFree = ((SInt)atUnWrapped( firstFree )).intValue() ;
			sizeFree-- ;
			put( pos, defaultValue ) ;
		}
		else
		{
			pos = info.size() ;
			addLast( defaultValue ) ;
		}
		return pos ;
	}
	
	/**
	 * De-Allocate a slot for usage.
	 * Position is assumed to be valid.
	 * @return	The old value found in there.
	 */
	protected synchronized SReadWritable deAllocSlot( int pos )
	{
		SReadWritable oldVal = at( pos ) ;
		putUnWrapped( pos, new SInt( firstFree ) ) ;
		firstFree = pos ;
		sizeFree++ ;
		return oldVal ;
	}
	
	/**
	 * Add data and return the position where it is added.
	 */
	protected int add( SReadWritable data )
	{
		int pos = allocSlot( data ) ;
		//put( pos, data ) ; // ???? adding twice
		return pos ;
	}
	
	/**
	 * Get all the data, as OnePartInfo's.
	 */
	private Enumeration allPartInfos()
	{
		return info.elements() ;
	}

	/**
	 * Get all the data, as SValue's.
	 */
	protected Enumeration elements()
	{
		return new EnumerationFilter
					( allPartInfos()
					, isDataPred
					, dataTrf
					) ;
	}

	/**
	 * Get all the valid positions used, as SInt's.
	 */
	protected Enumeration positions()
	{
		return new EnumerationFilter
					( new RangeEnumeration( 0, getCapacity() - 1 )
					, new IsValidPosPredicate( info, isDataPred )
					) ;
	}

	/**
	 * Write information on SWritableWriter.
	 */
	/*
	public void writeSValues( SWritableWriter out )
		throws IOException, SkitIOException
	{
		int size = getSize() ;
		out.writeSWritable( new SInt( size ) ) ;
		for ( int i = 0 ; i < size ; i++ )
		{
			out.writeSWritable( (SValue)get( i ) ) ;
		}
	}
	*/
		
	/**
	 * Get all the fixed svalues to be put on the writer.
	 * Meant to be overridden/implemented in subclass.
	 */
	/*
	public Enumeration getWriterFixedSValues( )
	{
		return new OneEnumeration( new SInt( getSize() ) ) ;
	}
	*/
	
	/**
	 * Get all the fixed svalues to be put on the writer.
	 * Meant to be overridden/implemented in subclass.
	 */
	/*
	public Enumeration getWriterVariableSValues( )
	{
		return elements() ;
	}
	*/
	
	/**
	 * Get all the fixed svalues to be put on the writer.
	 * Meant to be overridden/implemented in subclass.
	 */
	private Enumeration getWriterFixedSValues( )
	{
		Array a = new Array() ;
		a.pushBack( BasicSValue.newInt( getCapacity() ) ) ;
		a.pushBack( BasicSValue.newInt( firstFree ) ) ;
		a.pushBack( BasicSValue.newInt( sizeFree ) ) ;
		return a.elements() ;
	}
	
	/**
	 * Write the info for the content on an appropriate writer.
	 */
	public void writeSpecialInfo( SWritableWriter out )
		throws SkitIOException, IOException
	{
		out.writeSWritables
			( new EnumerationSequence
				( getWriterFixedSValues()
				, allPartInfos()
				) ) ;
		super.writeSpecialInfo( out ) ;
	}
	
	/**
	 * Fill already instantiated object with values from SReadableReader
	 * @return the filled readable or a suitable replacement for it.
	 */
	public SSpecialReadable fillWithSReadables( Enumeration in )
		throws IOException, SkitIOException
	{
		Object o1 = in.nextElement() ;
		Object o2 = in.nextElement() ;
		Object o3 = in.nextElement() ;
		if ( ! ( o3 instanceof SInt ) )
			throw new SkitIOException( "error in partinfo reading, expected SInt's" ) ;
		SInt sz = (SInt)o1 ;
		SInt ff = (SInt)o2 ;
		SInt sf = (SInt)o3 ;
		int size = sz.intValue() ;
		firstFree = ff.intValue() ;
		sizeFree = sf.intValue() ;
		setSize( size ) ;
		for ( int i = 0 ; i < size ; i++ )
		{
			putUnWrapped( i, (SReadWritable)in.nextElement( ) ) ;
		}
		return super.fillWithSReadables( in ) ;
	}
	

	/**
	 * Get a copy, but only the top level of an object structure.
	 */
	/*
	public PartInfo shallowCopy()
		throws SkitException
	{
		try
		{
			PartInfo newV = (PartInfo)clone() ;
			newV.postShallowCopy() ;
			return newV ;
		}
		catch ( CloneNotSupportedException e )
		{
			skit.log.Logger.log( "error in copy PartInfo", e ) ;
			throw new SkitException( "failed to shallow copy PartInfo" ) ;
		}
	}
	*/

	/**
	 * Get a copy.
	 */
	/*
	public PartInfo copy()
		throws SkitException
	{
		try
		{
			PartInfo newV = (PartInfo)clone() ;
			newV.postCopy() ;
			return newV ;
		}
		catch ( CloneNotSupportedException e )
		{
			skit.log.Logger.log( "error in copy PartInfo", e ) ;
			throw new SkitException( "failed to copy PartInfo" ) ;
		}
	}
	*/

	/**
	 * Do extra work after cloning.
	 * Meant to be overridden.
	 * Make sure super.postCopy() is invoked first.
	 */
	protected void postShallowCopy()
		throws SkitException
	{
		info = (Array)info.clone() ;
	}
	
	/**
	 * Do extra work after cloning.
	 * Meant to be overridden.
	 * Make sure super.postCopy() is invoked first.
	 */
	/*
	protected void postCopy()
		throws SkitException
	{
		postShallowCopy() ;
	}
	*/
	
	
}

public class OnePartInfo extends BasicSSpecialReadWritable
{
	private SReadWritable data ;
	private long modTime ;
	
	public OnePartInfo()
	{
	}
	
	public OnePartInfo( SReadWritable o )
	{
		setData( o ) ;
	}
	
	public void stampTime()
	{
		modTime = skit.util.Timestamp.timestamp() ;
	}
	
	public long getModTime()
	{
		return modTime ;
	}

	public SReadWritable getData()
	{
		return data ;
	}

	public void setData( SReadWritable o )
	{
		data = o ;
		stampTime() ;
	}

	/**
	 * Write the info for the content on an appropriate writer.
	 */
	public void writeSpecialInfo( SWritableWriter out )
		throws SkitIOException, IOException
	{
		out.writeSWritable( BasicSValue.newInt( modTime ) ) ;
		out.writeSWritable( data ) ;
		//super.writeSpecialInfo( out ) ;
	}
	
	/**
	 * Fill already instantiated object with values from SReadableReader
	 * @return the filled readable or a suitable replacement for it.
	 */
	public SSpecialReadable fillWithSReadables( Enumeration in )
		throws IOException, SkitIOException
	{
		Object o1 = in.nextElement() ;
		SInt tm = (SInt)o1 ;
		modTime = tm.longValue() ;
		data = (SReadWritable)in.nextElement() ;
		return this ;
		//super.fillWithSReadables( in ) ;
	}
	
}

class DataOfOnePartTransformer
	implements Transformer
{
	public DataOfOnePartTransformer()
	{
	}
	
	public Object transform( Object o )
	{
		return ((OnePartInfo)o).getData() ;
	}
}

class IsDataPredicate
	implements Predicate
{
	public IsDataPredicate()
	{
	}
	
	public boolean predicate( Object o )
	{
		return o instanceof OnePartInfo ;
	}
}

class IsValidPosPredicate
	implements Predicate
{
	private IsDataPredicate dataPred ;
	private Array partInfo ;
	
	public IsValidPosPredicate( Array info, IsDataPredicate pred )
	{
		dataPred = pred ;
		partInfo = info ;
	}
	
	public boolean predicate( Object o )
	{
		SInt i = (SInt)o ;
		return dataPred.predicate( partInfo.at( i.intValue() ) ) ;
	}
}

class RangeEnumeration
	implements Enumeration
{
	private int first, last ;
	private int counter ;
	
	public RangeEnumeration( int f, int l )
	{
		first = counter = f ;
		last = l ;
	}
	
	public boolean hasMoreElements()
	{
		return counter <= last ;
	}
	
	public Object nextElement()
	{
		return new SInt( counter++ ) ;
	}
}
