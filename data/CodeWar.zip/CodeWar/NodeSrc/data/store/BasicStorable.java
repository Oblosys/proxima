package skit.data.store ;

// PATCHED By Martijn, 17-9-1998
// equals( Object o )

import skit.* ;
import skit.id.* ;
import skit.change.* ;
import skit.util.* ;
import java.util.* ;
import skit.data.* ;
import skit.data.value.* ;
import java.io.* ;
import com.objectspace.jgl.* ;
import com.objectspace.jgl.adapters.* ;

/**
 * Something which is storable (on a store) and can be retrieved via an id.
 * The data maintained is split in meta and real data.
 * Meta data has a more descriptive nature and is considered the minimum necessary
 * to do anything with the BasicStorable.
 * The data itself is considered content.
 * Meta data is always loaded and available, the actual data not.
 */
public abstract class BasicStorable extends BasicSSpecialReadWritable
	implements Storable, SValue
{
	protected final static int ILLEGAL_POS = -1 ;
	
	private StoreInfo storeInfo = null ;
	private StoreParts storeParts = null ;
	
	public BasicStorable()
	{
	}
	
	protected BasicStorable( String storeName )
	{
		ensureStoreInfo( storeName.intern() ) ;
		//ensureStoreParts() ;
	}
	
	protected BasicStorable( String storeName, UniqueId id )
	{
		this( storeName ) ;
		setId( id ) ;
	}
	
	/**
	 * Get the minimal number of meta parts.
	 * Meant to be implemented in subclass.
	 */
	protected abstract int minNrOfMetaParts() ;
	
	/**
	 * Get the minimal number of meta parts.
	 * Meant to be implemented in subclass.
	 */
	protected abstract int minNrOfDataParts() ;
	
	/**
	 * Check if composite can be updated.
	 */
	public boolean isUpdateable()
	{
		return true ; // ????
	}
	
	/**
	 * Check if nil.
	 */
	public boolean equalsNil()
	{
		return false ;
	}
	
	/**
	 * Check if eof.
	 */
	public boolean equalsEof()
	{
		return false ;
	}
	
	/**
	 * @return true if empty.
	 */
	public boolean isEmpty()
	{
		return dataSize() == 0 ;
	}
	
	/**
	 * @see skit.value.Value
	 */
	public boolean satisfies( Type tp )
	{
		return tp.satisfies( this ) ;
	}
	
	/**
	 * Make sure the storeInfo is there.
	 */
	private void ensureStoreInfo()
	{
		if ( storeInfo == null )
			storeInfo = new StoreInfo() ;
	}
	
	/**
	 * Make sure the storeInfo is there.
	 */
	private void ensureStoreInfo( String storeName )
	{
		ensureStoreInfo() ;
		storeInfo.storeName = storeName ;
	}
	
	/**
	 * Make sure the storeParts is there.
	 */
	private void ensureStoreParts()
	{
		if ( storeParts == null )
			storeParts = skit.Globals.getStorage().makeStoreParts
								( (UniqueId)getId(), getStoreName()
								, minNrOfMetaParts(), minNrOfDataParts()
								) ;
	}
	
	/**
	 * Make sure the id is there.
	 */
	private void ensureId()
	{
		ensureStoreInfo() ;
		if ( storeInfo.id == null )
			storeInfo.id = skit.Globals.getStorage().makeId( this ) ;
	}
	
	/**
	 * Make sure the name of the store is there.
	 */
	private void ensureStoreName()
	{
		ensureStoreInfo() ;
		if ( storeInfo.storeName == null )
		{
			storeInfo.storeName =
				skit.Globals.getStorage().makeStoreName
						( (UniqueId)getId()
						, null
						) ;
		}
	}
	
	/**
	 * Make sure the storeParts is there.
	 */
	public StoreParts getStoreParts()
	{
		ensureStoreParts() ;
		return storeParts ;
	}
	
	/**
	 * Reset the store info, but keep the storename.
	 */
	private void resetStoreInfo()
	{
		String storeName = storeInfo.storeName ;
		storeInfo = null ;
		ensureStoreInfo( storeName ) ;
	}
	
	/**
	 * Get the id.
	 * @see skit.id.IdValue
	 */
	public Id getId()
	{
		ensureId() ;
		return storeInfo.id ;
	}
	
	/**
	 * Get the id and make sure its there indeed.
	 */
	/*
	public UniqueId getEnsureId( String storeName )
		throws SkitIOException
	{
		ensureId( storeName ) ;
		return storeInfo.id ;
	}
	*/
	
	/**
	 * Get the id and make sure its there indeed.
	 * It is assumed that the storeName is known.
	 */
	/*
	public UniqueId getEnsureId()
		throws SkitIOException
	{
		return getEnsureId( storeInfo.storeName ) ;
	}
	*/
	
	/**
	 * Set the id of the storable.
	 */
	public void setId( Id id )
	{
		setId( (UniqueId)id ) ;
	}
	
	/**
	 * Set the id of the storable.
	 */
	public void setId( UniqueId id )
	{
		if ( id != null )
		{
			ensureStoreInfo() ;
			storeInfo.id = id ;
		}
	}
	
	/**
	 * Set the storename of the storable.
	 */
	public void setStoreName( String storeName )
	{
		ensureStoreInfo( storeName ) ;
	}
	
	/**
	 * Get the storename of the storable.
	 */
	public String getStoreName()
	{
		ensureStoreInfo() ;
		return storeInfo.storeName ;
	}
	
	/**
	 * Make sure the BasicStorable is indeed synchronised with a store.
	 */
	private void ensureSynced( String storeName )
		throws SkitIOException
		// ???? transactional problems?
		// ???? is all of this the right place here?
	{
		ensureId() ;
		storeInfo.storeName = 
			skit.Globals.getStorage().makePersistent
										( storeInfo.id, storeName, getStoreParts() ) ;
		
		/*
		ensureStoreInfo() ;
		if ( storeInfo.id == null || ( ! storeInfo.isPersistent() ) )
		{
			if ( storeInfo.storeName != null )
				storeName = storeInfo.storeName ;
			try
			{
				skit.Globals.getStorage().newIdFor( this ) ;
				skit.Globals.getStorage().declarePersistent( this, storeName ) ;
				storeInfo.setPersistent() ;
			}
			catch ( SkitException e )
			{
				skit.log.Logger.log( "error in id creation", e ) ;
				throw new SkitIOException( "failed to ensure persistency" ) ;
			}
		}
		*/
	}
	
	/**
	 * Make sure the BasicStorable is indeed synchronised with a store.
	 */
	private void ensureSynced()
		throws SkitIOException
		// ???? transactional problems?
		// ???? is all of this the right place here?
	{
		ensureStoreName() ;
		ensureSynced( storeInfo.storeName ) ;
	}
	
	/**
	 * Make sure the value is synchronised with external storage
	 * @see skit.data.store.Storable
	 */
	public void sync()
		throws skit.SkitIOException
	{
		ensureSynced() ;
	}
	
	/**
	 * Make sure the value is available
	 * @see skit.id.IdValue
	 */
	public void use()
		throws skit.SkitIOException
	{
	}
	
	/**
	 * Put something in the meta data
	 */
	protected void putMeta( int pos, SReadWritable o )
	{
		getStoreParts().putMeta( pos, o ) ;
	}
	
	/**
	 * Put something in the data data
	 */
	protected void putData( int pos, SReadWritable o )
	{
		getStoreParts().putData( pos, o ) ;
	}
	
	/**
	 * Put something in the data data.
	 * It is an update, causing the appropriate update notification.
	 */
	protected void notifyDataAsUpdate( SequenceBehavior oldData, SequenceBehavior o )
	{
		skit.Globals.getChangeManager().changedUpdate( this, oldData, o ) ;
	}
	
	/**
	 * Put something in the data data.
	 * It is an add, causing the appropriate update notification.
	 */
	protected void notifyDataAsAdd( SequenceBehavior o )
	{
		skit.Globals.getChangeManager().changedAdd( this, o ) ;
	}
	
	/**
	 * Put something in the data data.
	 * It is an add, causing the appropriate update notification.
	 */
	protected void notifyDataAsRemove( SequenceBehavior o )
	{
		skit.Globals.getChangeManager().changedRemove( this, o ) ;
	}
	
	/**
	 * Get something out the meta data
	 */
	protected SReadWritable getMeta( int pos )
	{
		return getStoreParts().getMeta( pos ) ;
	}
	
	/**
	 * Get something out the data data
	 */
	protected SReadWritable getData( int pos )
	{
		return getStoreParts().getData( pos ) ;
	}
	
	/**
	 * Allocate slot for data.
	 * @return The allocated position.
	 */
	protected int allocDataSlot( SReadWritable defaultValue )
	{
		return getStoreParts().allocDataSlot( defaultValue ) ;
	}
	
	/**
	 * De-Allocate slot for data.
	 * @see skit.data.store.PartInfo
	 * @return The old value.
	 */
	protected Object deAllocDataSlot( int pos )
	{
		return getStoreParts().deAllocDataSlot( pos ) ;
	}
	
	/**
	 * Add something to the data data.
	 * @return The position where added.
	 */
	protected int addData( SReadWritable o )
	{
		return getStoreParts().addData( o ) ;
	}
	
	/**
	 * Get the size of the data part
	 */
	protected int dataSize(  )
	{
		return getStoreParts().dataSize( ) ;
	}
	
	/**
	 * Get the elements of the data part
	 */
	protected Enumeration dataElements(  )
	{
		return getStoreParts().dataElements( ) ;
	}
	
	/**
	 * Get the valid data positions of the data part
	 */
	protected Enumeration dataPositions(  )
	{
		return getStoreParts().dataPositions( ) ;
	}
	
	/**
	 * Get all the fixed svalues to be put on the writer.
	 * Meant to be overridden/implemented in subclass.
	 */
	/*
	private Enumeration getWriterFixedSValues( )
	{
		//ensurePersistency( "klad" ) ; // ????
		Array a = new Array() ;
		a.pushBack( storeInfo ) ;
		a.pushBack( parts[ DATA_PART ] ) ;
		return a.elements() ;
	}
	*/
	
	/**
	 * Get all the fixed svalues to be put on the writer.
	 * Meant to be overridden/implemented in subclass.
	 */
	/*
	public Enumeration getWriterVariableSValues( )
	{
		return new EmptyEnumeration() ;
	}
	*/
	
	/**
	 * Write the reference on an appropriate writer.
	 */
	public void writeSpecialInfo( SWritableWriter out )
		throws SkitIOException, IOException
	{
		super.writeSpecialInfo( out ) ;
		out.writeSWritable( getId() ) ;
		out.writeSWritable( BasicSValue.newString( getStoreName() ) ) ;
	}
	
	/**
	 * Write the info for the content on an appropriate writer.
	 */
	/*
	public void writeSpecialContentInfo( SWritableWriter out )
		throws SkitIOException, IOException
	{
		// ???? hack
		ensurePersistency( "root" ) ;
		out.writeSWritable( storeInfo ) ;
		out.writeSWritable( getStoreParts() ) ;
	}
	*/
	
	/**
	 * Fill already instantiated object with values from SReadableReader
	 */
	public SSpecialReadable fillWithSReadables( Enumeration in )
		throws IOException, SkitIOException
	{
		//SSpecialReadable res ;
		UniqueId id = (UniqueId)in.nextElement() ;
		SString st = (SString)in.nextElement() ;
		ensureStoreInfo() ;
		storeInfo.id = id ;
		storeInfo.storeName = skit.Globals.getStorage().makeStoreName( id, st.strValue().intern() ) ;
		//res = skit.Globals.getStorage().getStorableByIdAndStore( id, st.strValue() ) ;
		return this ;
	}
	
	/**
	 * Fill the content of an already instantiated object with values from SReadableReader.
	 */
	/*
	public void fillContentWithSReadables( Enumeration in )
		throws IOException, SkitIOException
	{
		storeInfo = (StoreInfo)in.nextElement() ;
		storeParts = (StoreParts)in.nextElement() ;
	}
	*/
	
	/**
	 * Get a copy.
	 */
	/*
	public SValue copy()
		throws SkitException
	{
		try
		{
			BasicStorable newV = (BasicStorable)clone() ;
			newV.postCopy() ;
			return newV ;
		}
		catch ( CloneNotSupportedException e )
		{
			skit.log.Logger.log( "error in copy storable", e ) ;
			throw new SkitException( "failed to copy storable" ) ;
		}
	}
	*/

	/**
	 * @see skit.ObjectFunctionality.
	 */
	/*
	protected void postCopy()
		throws SkitException
	{
		resetStoreInfo() ;
		storeParts = storeParts.copy() ;
	}
	*/
	
	/**
	 * @see skit.ObjectFunctionality.
	 */
	protected void postShallowCopy()
		throws SkitException
	{
		super.postShallowCopy() ;
		resetStoreInfo() ;
		storeParts = (StoreParts)storeParts.shallowCopy() ;
	}
	
	/**
	 * Test on equality.
	// PATCHED By Martijn, 17-9-1998
	// check if o == null, because microsoft VM does not allow
	// isInstance(null)
	
	 */
	public boolean equals( Object o )
	{
		if ( o != null)		
			return getClass().isInstance( o ) && equalsRest( (BasicStorable)o ) ;
		else
			return false;
	}

	/*	
	public String toString()
	{
		StringWriter sw = new StringWriter( ) ;
		try
		{
			BasicSWritableWriter bsw = new BasicSWritableWriter( sw, true, "" ) ;
			//TextOutput to = new TextOutput( sw ) ;
			bsw.writeSWritable( this ) ;
			//this.print( to, 0, true ) ;
			bsw.close() ;
		}
		catch( Exception e )
		{
			skit.log.Logger.log( "error in svalue toString()", e ) ;
			return e.toString() ;
		}
		return sw.toString() ;
	}
	*/
	
	protected boolean equalsRest( BasicStorable o )
	{
		return ((UniqueId)getId()).equals( ((UniqueId)o.getId()) ) ;
	}
	
	public int hashCode()
	{
		return ((UniqueId)getId()).hashCode() ;
	}

	/**
	 * Make a nice string representation.
	 * Append it on the StringBuffer
	 */
	public void appendStringRepr( StringBuffer buf )
	{
		//buf.append( getClass().toString() + ";" ) ;
		PrintableFunctionality.appendStringRepr
			( buf
			, BasicSValue.newString( getStoreName() )
			, getId()
			, PrintableFunctionality.BRACKET_STOREID
			) ;
		//getId().appendStringRepr( buf ) ;
		//PrintableFunctionality.appendStringRepr( buf, this, PrintableFunctionality.BRACKET_DEFAULT ) ;
	}

	/**
	 * Meant to be overridden.
	 */
	/*
	public void toStringBuffer( StringBuffer buf )
	{
		buf.append( BasicSWritableWriter.toString( this ) ) ; // ????
	}
	*/
	
	/*
	public String toString()
	{
		return PrintableFunctionality.toString( this ) ;
	}
	*/
	
}