package skit.data.store ;

import skit.data.node.* ;
import skit.data.relation.* ;
import skit.data.value.* ;

/**
 * A StoreInitialiser initialises a store when still unfilled.
 */
public interface StoreInitialiser
{
	/**
	 * Make the root.
	 */
	public SNode makeRoot( Store store )
		throws skit.SkitException, java.io.IOException ;

	/**
	 * Make the directory.
	 */
	public StorableRelation makeDirectory( Store store )
		throws skit.SkitException, java.io.IOException ;

	/**
	 * Fill the directory.
	 */
	public void fillDirectory( Store store, SRelation dir )
		throws skit.SkitException, java.io.IOException ;

}