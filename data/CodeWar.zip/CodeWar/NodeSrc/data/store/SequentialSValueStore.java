package skit.data.store ;

import com.objectspace.jgl.* ;
import skit.* ;
import skit.id.* ;
import java.io.* ;
import java.util.* ;
import skit.util.* ;
import skit.id.* ;
import skit.data.* ;
import skit.data.value.* ;
import skit.data.store.* ;
import skit.data.node.* ;
import skit.data.relation.* ;

/**
 * Sequentially stored Storables,
 * using textual representation of SValue's as storage encoding.
 */
public class SequentialSValueStore
	implements Store
{
	private String name ;
	private File inFile ;
	private File outFile ;
	private File changesFile ;
	//private Map storables ;
	private Map storableStoreParts ;
	private UniqueId rootId = null ;
	private UniqueId directoryId = null ;
	private SNode root = null ;
	private StorableRelation directory = null ;
	private Progress progress ;
	
	public SequentialSValueStore( String f, Progress p )
	{
		this( new File( f ), p ) ;
		name = f.intern() ;
	}

	public SequentialSValueStore( File f, Progress p )
	{
		inFile = f ;
		name = f.toString().intern() ;
		outFile = new File( inFile.getPath() + "-$$" ) ;
		changesFile = new File( inFile.getPath() + "-chng" ) ;
		//storables = new HashMap() ;
		storableStoreParts = new HashMap() ;
		progress = p ;
	}

	/**
	 * Get the Storable for a UniqueId.
	 * The contents are not necessarily available, i.e. minimal info may be read in only.
	 */
	/*
	private Storable getMinimalForId( UniqueId id )
		throws SkitIOException
	{
		Object n = storables.get( id ) ;
		if ( n != null )
		{
			return (Storable)n ;
		}
		else
		{
			throw new SkitIOException( "nothing stored for " + id ) ;
		}
	}
	*/

	/**
	 * Get the Storable belonging to an Id.
	 */
	/*
	public Storable getStorableById( UniqueId id )
		throws SkitIOException
	{
		return getMinimalForId( id ) ;
	}
	*/
	
	/**
	 * Get the StoreParts belonging to an Id.
	 */
	public StoreParts getStorePartsById( UniqueId id )
		throws SkitIOException
	{
		return (StoreParts)storableStoreParts.get( id ) ;
	}
	
	/**
	 * Make sure the Storable is persistent.
	 * Not necessarily stored, but at least known by its identifier on the given store.
	 * It is assumed the Storable already has an id
	 * @see skit.data.store.Storage
	 * @see skit.data.store.Storable
	 */
	/*
	public void declarePersistent( Storable storable )
		throws SkitIOException
	{
		storables.put( storable.getId(), storable ) ;
	}
	*/
	
	/**
	 * Make sure the StoreParts of a Storable is persistent on a store.
	 * An advised store name is passed.
	 * @return the name of the store on which it is made persistent.
	 */
	public void makePersistent( UniqueId id, StoreParts storeParts )
		throws SkitIOException
	{
		storableStoreParts.put( id, storeParts ) ;
	}
	
	/**
	 * Get the name of the store.
	 */
	public String getName()
	{
		return name ;
	}
	
	/**
	 * Make sure the Storable is persistent.
	 * Not necessarily stored, but at least known by its identifier on the given store.
	 * It is assumed the Storable already has an id
	 * @see skit.data.store.Storage
	 * @see skit.data.store.Storable
	 */
	/*
	public void declarePersistent( Storable storable )
		throws SkitIOException
	{
		// ???? no addition if already stored
		UniqueId id = new UniqueId( UniqueId.getMachine() ) ;
		storables.put( id, storable ) ;
		storable.setId( id ) ;
	}
	*/
	
	/**
	 * Get the root.
	 */
	public SNode getRoot()
		throws SkitIOException
	{
		if ( root == null )
		{
			root = new StorableSNode( getName(), rootId ) ;
		}
		//System.out.println( "ST INIT GET ROOT " + rootId + ";" + root ) ;
		return root ;
	}

	/**
	 * Set the root.
	 */
	public void setRoot( SNode node )
		throws SkitIOException
	{
		rootId = (UniqueId)node.getId( /*getName()*/ ) ;
		root = node ;
		//System.out.println( "ST INIT SET ROOT " + rootId + ";" + root ) ;
		//root.sync() ;
	}

	/**
	 * Get the directory.
	 */
	public StorableRelation getDirectory()
		throws SkitIOException
	{
		if ( directory == null )
		{
			directory = new StorableSRelation( getName(), directoryId ) ;
		}
		//System.out.println( "ST INIT GET DIR " + directoryId + ";" + directory ) ;
		return directory ;
	}

	/**
	 * Set the directory.
	 */
	public void setDirectory( StorableRelation rel )
		throws SkitIOException
	{
		directoryId = (UniqueId)rel.getId( /*getName()*/ ) ;
		directory = rel ;
		//System.out.println( "ST INIT SET DIR " + directoryId + ";" + directory ) ;
		//directory.sync() ;
	}

	/**
	 * Start it.
	 */
	public void open( StoreInitialiser storeInit )
		throws SkitIOException, IOException
	{
		try
		{
			FileReader fos = new FileReader( inFile ) ;
			BufferedReader bos = new BufferedReader( fos ) ;
			BasicSReadableReader bsw = new BasicSReadableReader( bos ) ;
			SValue fileCounter = BasicSValue.newInt(-1) ;
			
			try
			{
				SInt tot = (SInt)bsw.readSReadable() ;
				int total = tot.intValue() ;
				int counter = 0 ;
				rootId = (UniqueId)bsw.readSReadable() ;
				directoryId = (UniqueId)bsw.readSReadable() ;
				
				progress.start( total, "Reading from " + inFile ) ;
				for ( fileCounter = (SValue)bsw.readSReadable()
					; ! fileCounter.equalsEof()
					; fileCounter = (SValue)bsw.readSReadable()
					)
				{
					//System.out.println( "ST OPEN " + fileCounter ) ;
					//SReadable id = bsw.readSReadable() ;
					UniqueId id = (UniqueId)bsw.readSReadable() ;
					StoreParts stp = (StoreParts)bsw.readSReadable() ;
					storableStoreParts.put( id, stp ) ;
					progress.notify( ((float)(counter++) / total ) ) ;
				}
			}
			catch( Exception ex )
			{
				skit.log.Logger.log( "open store error", ex ) ;
				throw new SkitIOException( "open store error around item " + fileCounter + ": " + ex ) ;
			}
			
			bsw.close() ;
			
			progress.stop() ;
		}
		catch ( IOException ex )
		{
			skit.log.Logger.log( "no file for store " + inFile + ", will be created" ) ;
			try
			{
				setup( storeInit ) ;
			}
			catch( Exception exx )
			{
				skit.log.Logger.fatal( "failed to setup store " + inFile, exx ) ;
			}
		}
		
	}
	
	private void setup( StoreInitialiser storeInit )
		throws SkitException, IOException
	{
		StorableRelation dir ;
		setRoot( storeInit.makeRoot( this ) ) ;
		setDirectory( dir = storeInit.makeDirectory( this ) ) ;
		storeInit.fillDirectory( this, dir ) ;
	}
	
	/**
	 * Flush data, but do not close.
	 */
	public void flush()
		throws IOException, SkitIOException
	{
		//System.out.println( "FLUSH F " + outFile ) ;
		//System.out.println( "FLUSH P " + outFile.getPath() ) ;
		//System.out.println( "FLUSH AP " + outFile.getAbsolutePath() ) ;
		//System.out.println( "FLUSH CP " + inFile.getCanonicalPath() ) ;
		FileWriter fos = new FileWriter( outFile ) ;
		BufferedWriter bos = new BufferedWriter( fos ) ;
		BasicSWritableWriter bsw = new BasicSWritableWriter( bos, true, "\n" ) ;
		int counter = 0 ;
		int total ;
		
		bsw.writeSWritable( BasicSValue.newInt( total = storableStoreParts.size() ) ) ;
		progress.start( total, "Writing to " + inFile ) ;
		bsw.writeSWritable( rootId ) ;
		bsw.writeSWritable( directoryId ) ;
		
		for ( Enumeration e = storableStoreParts.keys()
			; e.hasMoreElements()
			; counter++
			)
		{
			Object o = e.nextElement() ;
			UniqueId id = (UniqueId)o ;
			//SReadWritable id = (SReadWritable)o ;
			//o = storables.get( id ) ;
			StoreParts stp = (StoreParts)storableStoreParts.get( id ) ;
			bsw.writeSWritable( new SInt( counter ) ) ;
			//System.out.println( "ST FLUSH " + counter + "/" + id ) ;
			//bsw.writeSWritable( id ) ; // ????
			bsw.writeSWritable( id ) ; // ????
			bsw.writeSWritable( stp ) ; // ????
			progress.notify( ((float)(counter) / total ) ) ;
		}
		
		bsw.close() ;
		File tmpFile = new File( outFile.getPath() + "-$$" ) ;
		if ( tmpFile.exists() && ( ! tmpFile.delete() ) )
			throw new SkitIOException( "error in deletion of " + tmpFile ) ;
		if ( inFile.exists() && ( ! inFile.renameTo( tmpFile ) ) )
			throw new SkitIOException( "error in rename of " + inFile + " to " + tmpFile ) ;
		if ( ! outFile.renameTo( inFile ) )
			throw new SkitIOException( "error in rename of " + outFile + " to " + inFile ) ;
		if ( tmpFile.exists() && ( ! tmpFile.delete() ) )
			throw new SkitIOException( "error in deletion of " + tmpFile ) ;
		progress.stop() ;
	}
	
	/**
	 * Flush data and close.
	 */
	public void close()
		throws IOException, SkitIOException
	{
		flush() ;
	}
	
}

public class SeqSValStoreChange extends BasicSSpecialReadWritable
{
	public SeqSValStoreChange()
	{
	}

	public SeqSValStoreChange( Storable st )
	{
	}

}