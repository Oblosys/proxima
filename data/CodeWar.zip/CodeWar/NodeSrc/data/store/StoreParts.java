package skit.data.store ;

import com.objectspace.jgl.*;
import com.objectspace.jgl.adapters.*;
import java.io.* ;
import java.util.* ;
import skit.util.* ;
import skit.* ;
import skit.data.value.* ;
import skit.data.* ;
//import skit.* ;

/**
 * A StoreParts maintains information about parts of
 * a BasicStorable.
 * This information is used to subdivide a BasicStorable for storage efficiency.
 *
 * @see skit.data.store.BasicStorable
 * @see skit.data.store.Store
 * @see skit.data.store.PartInfo
 */
public class StoreParts extends BasicSSpecialReadWritable
//	implements Cloneable
//	implements SValueable
{
	protected static final int META_PART = 0 ;
	protected static final int DATA_PART = 1 ;
	protected static final int NR_OF_PARTS = 2 ;
	
	private PartInfo[] parts = null ;
	
	public StoreParts()
	{
	}
	
	public StoreParts( int minNrOfMetaParts, int minNrOfDataParts )
	{
		parts = new PartInfo[ NR_OF_PARTS ] ;
		parts[ DATA_PART ] = new PartInfo( minNrOfDataParts ) ;
		parts[ META_PART ] = new PartInfo( minNrOfMetaParts ) ;
	}
	
	/**
	 * Put something in the meta data
	 */
	protected void putMeta( int pos, SReadWritable o )
	{
		parts[ META_PART ].put( pos, o ) ;
	}
	
	/**
	 * Put something in the data data
	 */
	protected void putData( int pos, SReadWritable o )
	{
		parts[ DATA_PART ].put( pos, o ) ;
	}
	
	/**
	 * Get something out the meta data
	 */
	protected SReadWritable getMeta( int pos )
	{
		return (SReadWritable)parts[ META_PART ].at( pos ) ;
	}
	
	/**
	 * Get something out the data data
	 */
	protected SReadWritable getData( int pos )
	{
		return (SReadWritable)parts[ DATA_PART ].at( pos ) ;
	}
	
	/**
	 * Allocate slot for data.
	 * @return The allocated position.
	 */
	protected int allocDataSlot( SReadWritable defaultValue )
	{
		return parts[ DATA_PART ].allocSlot( defaultValue ) ;
	}
	
	/**
	 * De-Allocate slot for data.
	 * @see skit.data.store.PartInfo
	 * @return The old value.
	 */
	protected Object deAllocDataSlot( int pos )
	{
		return parts[ DATA_PART ].deAllocSlot( pos ) ;
	}
	
	/**
	 * Add something to the data data.
	 * @return The position where added.
	 */
	protected int addData( SReadWritable o )
	{
		return parts[ DATA_PART ].add( o ) ;
	}
	
	/**
	 * Get the size of the data part
	 */
	protected int dataSize(  )
	{
		return parts[ DATA_PART ].getSize( ) ;
	}
	
	/**
	 * Get the elements of the data part
	 */
	protected Enumeration dataElements(  )
	{
		return parts[ DATA_PART ].elements( ) ;
	}
	
	/**
	 * Get the valid data positions of the data part
	 */
	protected Enumeration dataPositions(  )
	{
		return parts[ DATA_PART ].positions( ) ;
	}
	
	/**
	 * Write the info for the content on an appropriate writer.
	 */
	public void writeSpecialInfo( SWritableWriter out )
		throws SkitIOException, IOException
	{
		out.writeSWritable( BasicSValue.newInt( parts.length ) ) ;
		out.writeSWritables( new ObjectArray( parts ).elements( ) ) ;
		super.writeSpecialInfo( out ) ;
	}
	
	/**
	 * Fill already instantiated object with values from SReadableReader
	 * @return the filled readable or a suitable replacement for it.
	 */
	public SSpecialReadable fillWithSReadables( Enumeration in )
		throws IOException, SkitIOException
	{
		Object o = in.nextElement() ;
		SInt sz = (SInt)o ;
		int size ;
		parts = new PartInfo[ size = sz.intValue() ] ;
		for ( int i = 0 ; i < size ; i++ )
		{
			parts[ i ] = (PartInfo)in.nextElement() ;
		}
		
		// sanity check
		if ( parts[ DATA_PART ] == null )
			throw new SkitIOException( "error in storeparts reading" ) ;
		return super.fillWithSReadables( in ) ;
	}
	

	/**
	 * Get a copy, but only the top level of an object structure.
	 */
	/*
	public StoreParts shallowCopy()
		throws SkitException
	{
		try
		{
			StoreParts newV = (StoreParts)clone() ;
			newV.postShallowCopy() ;
			return newV ;
		}
		catch ( CloneNotSupportedException e )
		{
			skit.log.Logger.log( "error in copy StoreParts", e ) ;
			throw new SkitException( "failed to copy StoreParts" ) ;
		}
	}
	*/

	/**
	 * Get a copy.
	 */
	/*
	public StoreParts copy()
		throws SkitException
	{
		try
		{
			StoreParts newV = (StoreParts)clone() ;
			newV.postCopy() ;
			return newV ;
		}
		catch ( CloneNotSupportedException e )
		{
			skit.log.Logger.log( "error in copy StoreParts", e ) ;
			throw new SkitException( "failed to copy StoreParts" ) ;
		}
	}
	*/

	/**
	 * Do extra work after cloning.
	 * Meant to be overridden.
	 * Make sure super.postCopy() is invoked first.
	 */
	/*
	protected void postCopy()
		throws SkitException
	{
		PartInfo[] newParts = new PartInfo[ parts.length ] ;
		for ( int i = 0 ; i < newParts.length ; i++ )
			newParts[ i ] = parts[ i ].copy() ;
		parts = newParts ;
	}
	*/
	
	/**
	 * Do extra work after cloning.
	 * Meant to be overridden.
	 * Make sure super.postShallowCopy() is invoked first.
	 */
	protected void postShallowCopy()
		throws SkitException
	{
		PartInfo[] newParts = new PartInfo[ parts.length ] ;
		for ( int i = 0 ; i < newParts.length ; i++ )
			newParts[ i ] = (PartInfo)parts[ i ].shallowCopy() ;
		parts = newParts ;
	}
	
	
}
