package skit.data.store ;

import skit.data.* ;
import skit.data.value.* ;
import java.io.* ;
import java.util.* ;
import skit.util.* ;
import skit.* ;
import skit.id.* ;

/**
 * A StoreInfo maintains enough information to be able to retrieve
 * a BasicStorable.
 * This information is never meant to be stored itself.
 * @see skit.data.store.BasicStorable
 * @see skit.data.store.Store
 */
public class StoreInfo extends BasicSSpecialReadWritable
//	implements SValueable
{
	/**
	 * Indicating that the object has changed.
	 * The object has to be stored since it is out of sync with the stored counterpart.
	 */
	private static final int FLAG_IS_CHANGED = 0x01 ;

	/**
	 * Indicating that the object has been read.
	 */
	private static final int FLAG_IS_READ = 0x02 ;

	/**
	 * Indicating that the object has a stored counterpart, i.e. is persistent.
	 */
	private static final int FLAG_IS_PERSISTENT = 0x04 ;

	/**
	 * Indicating that the object temporary, i.e. not persistent.
	 */
	private static final int FLAG_IS_TEMP = 0x08 ;

	/**
	 * Indicating that the object once has been written to its stored counterpart.
	 */
	private static final int FLAG_IS_WRITTEN = 0x10 ;

	/**
	 * The persistent identifier.
	 */
	protected UniqueId id = null ;

	/**
	 * The store on which the BasicStorable is to be found.
	 */
	protected String storeName = null ;

	/**
	 * The flags describing the state.
	 * Combination of FLAG_IS_XXX's
	 */
	protected int flags = 0 ;
	
	public StoreInfo()
	{
	}

	protected StoreInfo( UniqueId i, String s )
	{
		id = i ;
		storeName = s ;
	}

	protected void setPersistent()
	{
		flags |= FLAG_IS_PERSISTENT ;
	}

	protected boolean isPersistent()
	{
		return ( ( flags & FLAG_IS_PERSISTENT ) != 0 ) ;
	}

	/**
	 * Get all the fixed svalues to be put on the writer.
	 * Meant to be overridden/implemented in subclass.
	 */
	/*
	public Enumeration getWriterFixedSValues( )
	{
		return new OneEnumeration( id ) ;
	}
	*/
	
	/**
	 * Get all the fixed svalues to be put on the writer.
	 * Meant to be overridden/implemented in subclass.
	 */
	/*
	public Enumeration getWriterVariableSValues( )
	{
		return new EmptyEnumeration() ;
	}
	*/
	
	/**
	 * Write the info for the content on an appropriate writer.
	 */
	public void writeSpecialInfo( SWritableWriter out )
		throws SkitIOException, IOException
	{
		out.writeSWritable( id ) ;
		super.writeSpecialInfo( out ) ;
	}
	
	/**
	 * Fill already instantiated object with values from SReadableReader
	 * @return the filled readable or a suitable replacement for it.
	 */
	public SSpecialReadable fillWithSReadables( Enumeration in )
		throws IOException, SkitIOException
	{
		id = (UniqueId)in.nextElement() ;
		return super.fillWithSReadables( in ) ;
	}
	
}