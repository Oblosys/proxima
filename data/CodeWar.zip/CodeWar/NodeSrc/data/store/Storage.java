package skit.data.store ;

import java.io.* ;
import java.util.* ;
import skit.util.* ;
import skit.* ;
import skit.id.* ;
import com.objectspace.jgl.* ;

/**
 * A Storage is a repository/registry for Store's.
 * This class is a singleton.
 * A current store is also maintained, used if other policies for
 * specifying where a Storable should be stored, fail.
 * Normally this is the default store.
 * The default store is used if for some reason a specified store
 * does not exist (or whatever).
 *
 * @see skit.Registry
 */
public class Storage
	implements IOBehavior
{
	private Registry stores ;
	
	//private Map storableCache ;
	private Map storePartsCache ;
	private Map storeNameCache ;
	
	private static Storage theStorage = null ;
	
	private Store currentStore = null ;
	
	private Storage()
	{
		stores = new FlatRegistry( "stores", true, false ) ;
		//storableCache = new HashMap() ;
		storePartsCache = new HashMap() ;
		storeNameCache = new HashMap() ;
	}
	
	/**
	 * Create a singleton Storage.
	 */
	public synchronized static Storage newStorage()
	{
		if ( theStorage == null )
			theStorage = new Storage() ;
		return theStorage ;
	}
	
	/**
	 * Get the current store.
	 */
	public Store getCurrentStore()
	{
		return currentStore ;
	}
	
	/**
	 * Get the name of the current store.
	 */
	public String getCurrentStoreName()
	{
		return getCurrentStore().getName() ;
	}
	
	/**
	 * set the current store.
	 */
	public void setCurrentStore( Store st )
	{
		currentStore = st ;
	}
	
	/**
	 * Register the store.
	 */
	public void registerStore( Store st )
	{
		stores.register( st.getName(), st ) ;
	}
	
	/**
	 * Register the store as default.
	 */
	public synchronized void registerAsDefaultStore( Store st )
	{
		stores.registerAsDefault( null, st ) ;
		if ( currentStore == null )
			setCurrentStore( st ) ;
	}
	
	/**
	 * Find a store.
	 * @return The store, or null if none available.
	 */
	public Store find( String nm )
	{
		return (Store)stores.resolve( nm ) ;
	}
	
	/**
	 * Get the default store.
	 * @return The store, or null if none available.
	 */
	public Store getDefaultStore()
	{
		return find( stores.getDefaultKey() ) ;
	}
	
	/**
	 * @return An Enumeration of all available store names.
	 */
	public Enumeration storeNames()
	{
		return stores.resourceKeys() ;
	}
	
	/**
	 * @return An Enumeration of all available stores.
	 */
	public Enumeration stores()
	{
		return stores.resources() ;
	}
	
	/**
	 * Make a new id for a Storable.
	 * Administer the value also in the Storable.
	 */
	/*
	private UniqueId newIdFor( Storable storable )
		throws SkitIOException
	{
		UniqueId id = (UniqueId)storable.getId() ;
		if ( id == null )
		{
			id = makeId() ;
			storable.setId( id ) ;
		}
		return id ;
	}
	*/
	
	/**
	 * Get the Storable belonging to an Id.
	 * A specific store is used.
	 */
	/*
	public Storable getStorableByIdAndStore( UniqueId id, String storeName )
		throws SkitIOException
	{
		Storable res = (Storable)storableCache.get( id ) ;
		if ( res == null )
		{
			res = find( storeName ).getStorableById( id ) ;
			storableCache.put( res.getId(), res ) ;
		}
		return res ;
	}
	*/
	
	/**
	 * Get the Storable belonging to an Id.
	 * The current store is used.
	 */
	/*
	public Storable getStorableById( UniqueId id )
		throws SkitIOException
	{
		Storable res = getCurrentStore().getStorableById( id ) ;
		storableCache.put( res.getId(), res ) ;
		return res ;
	}
	*/
	
	/**
	 * Make sure the Storable is persistent.
	 * Not necessarily stored, but at least known by its identifier on the given store.
	 */
	/*
	public void declarePersistent( Storable storable, String storeName )
		throws SkitIOException
	{
		find( storeName ).declarePersistent( storable ) ;
		storableCache.put( storable.getId(), storable ) ;
	}
	*/
	
	/**
	 * Make sure the StoreParts of a Storable is persistent on a store.
	 * An advised store name is passed.
	 * @return the name of the store on which it is made persistent.
	 */
	public synchronized String makePersistent( UniqueId id, String adviseStoreName, StoreParts storeParts )
		throws SkitIOException
	{
		String storeName = makeStoreName( id, adviseStoreName ) ;
		String realStoreName ;
		Store store ;
		(store = find( storeName )).makePersistent( id, storeParts ) ;
		storePartsCache.put( id, storeParts ) ;
		if ( ! storeName.equals( realStoreName = store.getName() ) )
		{
			storeNameCache.put( id, storeName = realStoreName ) ;
		}
		return storeName ;
	}
	
	/**
	 * Make a new id for a Storable.
	 * Administer the value also in the Storable.
	 */
	public UniqueId makeId( Storable storable )
	{
		return new UniqueId( UniqueId.getMachine() ) ; ;
	}
	
	/**
	 * Make/get the storename for an id.
	 * An advise is given.
	 */
	public synchronized String makeStoreName( UniqueId id, String adviseStoreName )
	//	throws SkitIOException
	{
		String storeName = (String)storeNameCache.get( id ) ;
		if ( storeName == null )
		{
			storeName = adviseStoreName ;
			if ( storeName == null )
			{
				storeName = getCurrentStoreName() ;
			}
			storeNameCache.put( id, storeName ) ;
		}
		return storeName ;
	}
	
	/**
	 * Make either a new StoreParts or find out if one is already there.
	 */
	protected StoreParts makeStoreParts( UniqueId id, String storeName, int minMeta, int minData )
	//	throws SkitIOException
	{
		StoreParts res = (StoreParts)storePartsCache.get( id ) ;
		Store store ;
		if ( res == null )
		{
			try
			{
				storeName = makeStoreName( id, storeName ) ;
				res = (store = find( storeName )).getStorePartsById( id ) ;
			}
			catch ( Exception ex )
			{
				skit.log.Logger.warn( "error in getting storeparts from store " + storeName + ", making an empty one", ex ) ;
			}
			if ( res == null )
			{
				res = new StoreParts( minMeta, minData ) ;
			}
			storePartsCache.put( id, res ) ;
		}
		return res ;
	}
	
	/**
	 * Flush data, but do not close.
	 */
	public void flush()
		throws IOException, SkitIOException
	{
		for ( Enumeration e = stores() ; e.hasMoreElements() ; )
		{
			Store s = (Store)e.nextElement() ;
			try
			{
				s.flush() ;
			}
			catch ( Exception ex )
			{
				skit.log.Logger.warn( "error in storage flush", ex ) ;
			}
		}
	}
	
	/**
	 * Flush data and close.
	 */
	public void close()
		throws IOException, SkitIOException
	{
		for ( Enumeration e = stores() ; e.hasMoreElements() ; )
		{
			Store s = (Store)e.nextElement() ;
			try
			{
				s.close() ;
			}
			catch ( Exception ex )
			{
				skit.log.Logger.warn( "error in storage close", ex ) ;
			}
		}
		storePartsCache.clear() ;
		storeNameCache.clear() ;
	}
	
}