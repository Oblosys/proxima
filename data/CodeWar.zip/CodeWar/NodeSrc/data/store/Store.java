package skit.data.store ;

import skit.util.* ;
//import skit.data.node.* ;
import skit.data.relation.* ;
import skit.data.value.* ;
import skit.* ;
import skit.id.* ;
import java.io.* ;

/**
 * A Store stores values under an id.
 */
public interface Store extends IOBehavior
{
	/**
	 * Get the Storable for a UniqueId.
	 * The contents are not necessary available, i.e. minimal info may be read in only.
	 */
	//public Storable getMinimalForId( UniqueId id )
	//	throws SkitIOException ;
	
	/**
	 * Get the name of the store.
	 */
	public String getName() ;
	
	/**
	 * Make sure the Storable is persistent.
	 * Not necessarily stored, but at least known by its identifier on the given store.
	 * 
	 * @see skit.data.store.Storage
	 * @see skit.data.store.Storable
	 */
	//public void declarePersistent( Storable storable )
	//	throws SkitIOException ;
	
	/**
	 * Make sure the StoreParts of a Storable is persistent on a store.
	 * An advised store name is passed.
	 * @return the name of the store on which it is made persistent.
	 */
	public void makePersistent( UniqueId id, StoreParts storeParts )
		throws SkitIOException ;
	
	/**
	 * Get the StoreParts belonging to an Id.
	 */
	public StoreParts getStorePartsById( UniqueId id )
		throws SkitIOException ;
	
	/**
	 * Get the Storable belonging to an Id.
	 */
	//public Storable getStorableById( UniqueId id )
	//	throws SkitIOException ;
	
	/**
	 * Get the root.
	 */
	public SNode getRoot()
		throws SkitIOException ;

	/**
	 * Set the root.
	 */
	public void setRoot( SNode node )
		throws SkitIOException ;

	/**
	 * Get the directory.
	 */
	public StorableRelation getDirectory()
		throws SkitIOException ;

	/**
	 * Set the directory.
	 */
	public void setDirectory( StorableRelation rel )
		throws SkitIOException ;

	/**
	 * Start it.
	 */
	public void open( StoreInitialiser storeInit )
		throws SkitIOException, IOException ;

}