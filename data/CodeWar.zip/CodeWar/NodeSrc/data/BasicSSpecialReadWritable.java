package skit.data ;

import skit.* ;
import skit.data.* ;
import skit.util.* ;
import skit.data.value.* ;
import java.util.* ;
import java.io.* ;

/**
 * A basic implementation for SSpecialReadWritable
 * The idea is to provide a template methode for writeInfo,
 * in which the actual data writing is surrounded by mime-type stuff as
 * offered by the SWritableWriter.
 */
public abstract class BasicSSpecialReadWritable extends ObjectFunctionality
	implements SSpecialReadWritable, Printable
{
	/**
	 * Write the info for the content on an appropriate writer.
	 */
	public void writeInfo( SWritableWriter out )
		throws SkitIOException, IOException
	{
		out.writeSSpecialWritable( this, null ) ;
	}

	/**
	 * Write the info for the content on an appropriate writer.
	 */
	public void writeSpecialInfo( SWritableWriter out )
		throws SkitIOException, IOException
	{
	}

	/**
	 * Fill already instantiated object with values from SReadableReader.
	 * @return the filled readable or a suitable replacement for it.
	 */
	public SSpecialReadable fillWithSReadables( Enumeration in )
		throws IOException, SkitIOException
	{
		return this ;
	}
	
	public void appendStringRepr( StringBuffer buf )
	{
		buf.append( BasicSWritableWriter.toString( this ) ) ; // ????
	}
	
	public String toString()
	{
		return PrintableFunctionality.toString( this ) ;
		//return BasicSWritableWriter.toString( this ) ; // ????
	}
	
}