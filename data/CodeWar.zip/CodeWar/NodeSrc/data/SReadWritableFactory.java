package skit.data ;

import skit.factory.* ;
import skit.* ;

/**
 * A factory for SWritable's
 */
public class SReadWritableFactory
	implements Factory
{
	private final static String paramDescr = "mime alike specification" ;
	
	public SReadWritableFactory()
	{
	}
	
	/**
	 * @see skit.factory.Factory
	 */
	public String getParamDescr()
	{
		return paramDescr ;
	}
	
	/**
	 * @see skit.factory.Factory
	 */
	public Object makeIt( Object param )
		throws skit.SkitException
	{
		try
		{
			//System.out.println( "MAKE IT " + param ) ;
			Class contCl = (Class)skit.Globals.getSWritableMimeRegistry().resolve( (String)param ) ;
			return contCl.newInstance() ;
		}
		catch( Exception ex )
		{
			skit.log.Logger.log( "factory error", ex ) ;
			throw new SkitException( "swritable factory could not create for " + param + ": " + ex ) ;
		}
	}
	
}