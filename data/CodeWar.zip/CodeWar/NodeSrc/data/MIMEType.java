package skit.data ;

import skit.* ;
import java.io.* ;

/**
 * MIMEType describes a mime type.
 * Type & subtype.
 * Mapping to internal SKIT.
 * This descriptor is used for MIME types as well as other textual descriptions
 * of types, needing a mapping to an internal SKIT class.
 */
public class MIMEType
{
	public static final String mimeSep = "/" ;

	private String mainType ;
	private String subType ;
	private Class typeClass ;
	
	public MIMEType( String tp, String subTp, Class tcl )
	{
		mainType = tp ;
		subType = subTp ;
		typeClass = tcl ;
	}
	
	/**
	 * Get the main type.
	 */
	public String getMainType()
	{
		return mainType ;
	}
	
	/**
	 * Get the subtype.
	 */
	public String getSubType()
	{
		return subType ;
	}
	
	/**
	 * Get the content class used to map this mime type to.
	 */
	public Class getTypeClass()
	{
		return typeClass ;
	}
	
	/**
	 * Get the full type.
	 */
	public String getType()
	{
		return getMainType() + mimeSep + getSubType() ;	
	}
	
	public String toString()
	{
		return "mime " + getType() + "->" + getTypeClass().getName() ;
	}
	
	public int hashCode()
	{
		return mainType.hashCode() ^ subType.hashCode() ;
	}
	
	public boolean equals( Object o )
	{
		if ( o instanceof Class )
			return typeClass.equals( (Class)o ) ;
		else if ( o instanceof MIMEType )
		{
			MIMEType mt = (MIMEType)o ;
			return mt.mainType.equals( mainType ) && mt.subType.equals( subType ) ;
		}
		return false ;
	}
}