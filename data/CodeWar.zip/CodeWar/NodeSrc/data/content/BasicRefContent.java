package skit.data.content ;

import skit.* ;
import skit.data.* ;
import skit.data.value.* ;
import skit.util.* ;
import java.io.* ;
import java.util.* ;

/**
 * The simplest implementation basis for RefContent.
 */
public abstract class BasicRefContent extends BasicContent
	implements Cloneable, RefContent
{
	protected SReadWritable theRef ;
	
	protected BasicRefContent()
	{
		this( null ) ;
	}
	
	protected BasicRefContent( SReadWritable o )
	{
		super() ;
		setRef( o ) ;
	}
	
	/**
	 * Get the ref.
	 */
	public SReadWritable getRef()
	{
		return theRef ;
	}

	/**
	 * Set the ref.
	 */
	public void setRef( SReadWritable o )
	{
		theRef = o ;
	}

	/**
	 * Get it.
	 */
	public Object get()
		throws SkitIOException, IOException
	{
		preGet() ;
		return super.get() ;
	}
	
	/**
	 * Do what is necessary before getting the value, in general
	 * making sure the data is available.
	 * To be implemented in subclass.
	 */
	protected abstract void preGet()
		throws SkitIOException, IOException ;
	
	/**
	 * Set it.
	 */
	public void set( Object o )
		throws SkitIOException, IOException
	{
		super.set( o ) ;
		postSet() ;
	}
	
	/**
	 * Do what is necessary after setting the value, in general
	 * making sure the data is made persistent.
	 * To be implemented in subclass.
	 */
	protected abstract void postSet()
		throws SkitIOException, IOException ;
	
	/**
	 * Get it.
	 */
	public Object getKeyed( Object k )
		throws SkitIOException, IOException
	{
		preGetKeyed( k ) ;
		return getRefKeyed( k ) ;
	}
	
	/**
	 * Do what is necessary before getting the value, in general
	 * making sure the data is available.
	 * To be implemented in subclass.
	 */
	protected abstract void preGetKeyed( Object k )
		throws SkitIOException, IOException ;
	
	/**
	 * Get the keyed value.
	 * To be implemented in subclass.
	 */
	protected Object getRefKeyed( Object k )
		throws SkitIOException, IOException
	{
		return null ;
	}
	
	/**
	 * Set it.
	 */
	public void setKeyed( Object k, Object o )
		throws SkitIOException, IOException
	{
		setRefKeyed( k, o ) ;
		postSetKeyed() ;
	}
	
	/**
	 * Do what is necessary after setting the value, in general
	 * making sure the data is made persistent.
	 * To be implemented in subclass.
	 */
	protected abstract void postSetKeyed()
		throws SkitIOException, IOException ;
	
	/**
	 * Set the keyed value.
	 * To be implemented in subclass.
	 */
	protected void setRefKeyed( Object k, Object o )
		throws SkitIOException, IOException
	{
	}
	
	/**
	 * Fill already instantiated object with values from SReadableReader
	 * @return the filled readable or a suitable replacement for it.
	 */
	public SSpecialReadable fillWithSReadables( Enumeration in )
		throws IOException, SkitIOException
	{
		if ( ! in.hasMoreElements() )
			throw new SkitIOException( "expected ref for BasicRefContent" ) ;
		
		setRef( (SValue)in.nextElement() ) ;
		return this ;
		//super.fillWithSReadables( in ) ;
	}
	
	/**
	 * Write the info for the content on an appropriate writer.
	 */
	public void writeSpecialInfo( SWritableWriter out )
		throws SkitIOException, IOException
	{
		out.writeSWritable( getRef() ) ;
		//super.writeSpecialInfo( out ) ;
	}

	/**
	 * Get all the svalues to be put on the writer.
	 */
	/*
	public Enumeration getWriterSValues( )
	{
		return new OneEnumeration( getRef() ) ;
	}
	*/
	
	/**
	 * To be overridden in subclasses.
	 */
	/*
	public void postCopy()
	{
		super.postCopy() ;
	}
	*/

	/**
	 * Test on equality.
	 */
	public boolean equals( Object c )
	{
		//System.out.println( "CONT EQLS " + this + " and " + c ) ;
		try
		{
			return getRef().equals( ((BasicRefContent)c).getRef() ) ;
		}
		catch( Exception ex )
		{
			skit.log.Logger.warn( "error in refcontent equals: ", ex ) ;
			return false ;
		}
	}
	
	/**
	 * Write the info for the content on an appropriate writer.
	 */
	public void writeInfo( SWritableWriter out, SWritable origVal )
		throws SkitIOException, IOException
	{
		out.writeSSpecialWritable( this, origVal ) ;
	}

	public int hashCode()
	{
		return getRef().hashCode() ;
	}
	
	public String toString()
	{
		return getRef().toString() ;
	}

}
