package skit.data.content ;

import skit.* ;
import skit.data.* ;
import java.io.* ;

/**
 * Content which its value in itself.
 */
public interface DataContent extends Content
{
}
