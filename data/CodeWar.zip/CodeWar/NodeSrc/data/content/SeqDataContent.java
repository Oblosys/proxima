package skit.data.content ;

import com.objectspace.jgl.* ;
import skit.* ;
import skit.data.* ;
import skit.data.value.* ;
import java.io.* ;

/**
 * Sequence content.
 */
public class SeqDataContent extends BasicDataContent
{
	public SeqDataContent()
	{
	}
	
	public SeqDataContent( Sequence o )
	{
		super( o ) ;
	}
	
	/**
	 * Get the seq value.
	 */
	public Sequence seqValue()
	{
		return ((Sequence)caughtGet()) ;
	}
	
	/**
	 * Write the info for the content on an appropriate writer.
	 */
	public void writeInfo( SWritableWriter out, SWritable origVal )
		throws SkitIOException, IOException
	{
		out.beginSWritableGroup( this, false, "#", null ) ;
		out.writeSWritables( seqValue().elements() ) ;
		out.endSWritableGroup() ;
	}

}