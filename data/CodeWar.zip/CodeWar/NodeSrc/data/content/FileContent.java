package skit.data.content ;

import skit.* ;
import skit.util.* ;
import skit.data.* ;
import skit.data.value.* ;
import java.io.* ;
import java.util.* ;

/**
 * Content which retrieves its values via a file reference.
 */
public class FileContent extends BasicRefContent
{
	//protected MIMEType mimeType ;
	protected String mimeType ;
	
	public FileContent()
	{
		
	}
	
	public FileContent( SString fn )
	{
		super( fn ) ;
	}
	
	public FileContent( String fn )
	{
		this( BasicSValue.newString( fn ) ) ;
	}
	
	protected void setMimeType( String tp )
	{
		mimeType = tp ;
	}
	
	protected String getFileName()
	{
		return ((SString)getRef()).strValue() ;
	}
	
	protected File getFile()
	{
		return new File( getFileName() ) ;
	}
	
	/**
	 * @see skit.data.BasicRefContent
	 */
	protected void preGet()
		throws SkitIOException, IOException
	{
		if ( theData == null )
		{
			File f = getFile() ;
		}
	}
	
	/**
	 * @see skit.data.BasicRefContent
	 */
	protected void postSet()
		throws SkitIOException, IOException
	{
	}
	
	/**
	 * @see skit.data.BasicRefContent
	 */
	protected void preGetKeyed( Object k )
		throws SkitIOException, IOException
	{
	}
	
	/**
	 * @see skit.data.BasicRefContent
	 */
	protected void postSetKeyed()
		throws SkitIOException, IOException
	{
	}
	
	/**
	 * Fill already instantiated object with values from SReadableReader
	 */
	/*
	public SSpecialReadable fillWithSReadables( Enumeration in )
		throws IOException, SkitIOException
	{
		super.fillWithSReadables( in ) ;
		
		//if ( ! in.hasMoreElements() )
		//	throw new SkitIOException( "expected mime type for FileContent" ) ;
		
		//setMimeType( ((SString)in.nextElement()).strValue() ) ;
	}
	*/
	
	/**
	 * Get all the svalues to be put on the writer.
	 */
	/*
	public Enumeration getWriterSValues( )
	{
		String mimeContent = skit.Globals.getSWritableMimeRegistry().reverseResolve( getClass() ) ;
		if ( mimeContent == null )
			mimeContent = "??/??" ;
		Enumeration infoEnum = new OneEnumeration( BasicSValue.newSymbol( mimeContent ) ) ;
		return new EnumerationSequence
					( super.getWriterSValues()
					//, new OneEnumeration( BasicSValue.newString( mimeType ) )
					, infoEnum
					) ;
	}
	*/
	
}
