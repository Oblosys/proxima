package skit.data.content ;

import skit.* ;
import skit.data.* ;
import skit.data.value.* ;
import java.io.* ;

/**
 * Nil content.
 */
public class NilDataContent extends BasicDataContent
{
	public NilDataContent()
	{
	}
	
	/**
	 * Write the info for the content on an appropriate writer.
	 */
	public void writeInfo( SWritableWriter out, SWritable origVal )
		throws SkitIOException, IOException
	{
		out.printNil() ;
	}

}