package skit.data.content ;

import skit.* ;
import skit.data.* ;
import skit.data.value.* ;
import java.io.* ;

/**
 * Content (for SValues).
 * A Content contains the actual data for a SValue and functions as a bridge/binding
 * between user usable values and the underlying storage.
 * It is the responsibility of a Content to get/set it and remember the
 * (java)class of the data.
 * A Content can read and write itself either in terms of basic values or in terms
 * of SValue's. See subinterfaces.
 * @see skit.data.DataContent
 * @see skit.data.RefContent
 */
public interface Content extends SContentReadWritable, ObjectBehavior
{
	/**
	 * Get it.
	 */
	public Object get()
		throws SkitIOException, IOException ;
	
	/**
	 * Get it, but handle the exceptions which may occur in the getting.
	 */
	public Object caughtGet() ;
	
	/**
	 * Set it.
	 */
	public void set( Object o )
		throws SkitIOException, IOException ;

	/**
	 * Set it, but handle the exceptions which may occur in the setting.
	 */
	public void caughtSet( Object o ) ;
	
	/**
	 * Get part via a key object.
	 */
	public Object getKeyed( Object k )
		throws SkitIOException, IOException;
	
	/**
	 * Set part via key object.
	 */
	public void setKeyed( Object k, Object o )
		throws SkitIOException, IOException ;

	/**
	 * Get a copy.
	 */
	//public Content copy()
	//	throws SkitIOException ;
		
	/**
	 * Test on equality.
	 */
	//public boolean equals( Content c ) ;

	/**
	 * Check if composite can be updated.
	 */
	public boolean isUpdateable() ;
	
}
