package skit.data.content ;

import skit.* ;
import skit.data.* ;
import java.io.* ;

/**
 * The simplest implementation basis for DataContent.
 */
public abstract class BasicDataContent extends BasicContent
	implements Cloneable, DataContent
{
	protected BasicDataContent()
	{
		
	}
	
	protected BasicDataContent( Object o )
	{
		super( o ) ;
	}
	
}