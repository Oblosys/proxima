package skit.data.content ;

import skit.* ;
import skit.data.* ;
import skit.data.value.* ;
import java.io.* ;

/**
 * String content.
 */
public class StringDataContent extends BasicDataContent
{
	public StringDataContent()
	{
	}
	
	public StringDataContent( String o )
	{
		super( o ) ;
	}
	
	/**
	 * Get the string value.
	 */
	public String strValue()
	{
		return ((String)caughtGet()) ;
	}
	
	/**
	 * Write the info for the content on an appropriate writer.
	 */
	public void writeInfo( SWritableWriter out, SWritable origVal )
		throws SkitIOException, IOException
	{
		out.print( strValue() ) ;
	}

}