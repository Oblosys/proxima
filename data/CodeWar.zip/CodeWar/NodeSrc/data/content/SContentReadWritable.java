package skit.data.content ;

import skit.* ;
import skit.data.* ;
import skit.data.value.* ;
import java.io.* ;

/**
 * Something which can be written as a SValue (and later be read as such),
 * using SWritableWriter.
 * The SContentReadWritable belongs (as a Content) to a SValue and has to be
 * able to encode essential info for reconstructing the SValue.
 * @see skit.data.value.SWritableWriter
 */
public interface SContentReadWritable extends SWritable, SSpecialReadable
{
	/**
	 * Write the info for the content on an appropriate writer.
	 */
	public void writeInfo( SWritableWriter out, SWritable origVal )
		throws SkitIOException, IOException ;

}