package skit.data.content ;

import skit.* ;
import skit.data.* ;
import skit.data.value.* ;
import java.io.* ;

/**
 * Symbol content.
 */
public class SymbolDataContent extends StringDataContent
{
	public SymbolDataContent()
	{
	}
	
	public SymbolDataContent( String o )
	{
		super( o ) ;
	}
	
	/**
	 * Write the info for the content on an appropriate writer.
	 */
	public void writeInfo( SWritableWriter out, SWritable origVal )
		throws SkitIOException, IOException
	{
		out.printSymbol( strValue() ) ;
	}

}