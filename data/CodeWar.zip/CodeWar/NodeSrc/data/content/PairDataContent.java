package skit.data.content ;

import skit.* ;
import skit.data.* ;
import skit.data.value.* ;
import java.io.* ;
import java.util.* ;

/**
 * Pair content.
 */
public class PairDataContent extends BasicDataContent
{
	public PairDataContent( SValue h, SValue t )
	{
		this( new Pair( h, t ) ) ;
	}
	
	public PairDataContent( Pair o )
	{
		super( o ) ;
	}
	
	/**
	 * Get the pair of values.
	 */
	public Pair pairValue()
	{
		return ((Pair)caughtGet()) ;
	}
	
	/**
	 * Write the info for the content on an appropriate writer.
	 */
	public void writeInfo( SWritableWriter out, SWritable origVal )
		throws SkitIOException, IOException
	{
		out.beginSWritableGroup( this, false, null, origVal ) ;
		out.writeSWritables( new SPairEnumeration( pairValue() ) ) ;
		out.endSWritableGroup() ;
	}

}