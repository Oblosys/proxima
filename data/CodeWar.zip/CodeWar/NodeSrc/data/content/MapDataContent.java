package skit.data.content ;

import com.objectspace.jgl.* ;
import skit.* ;
import skit.util.* ;
import skit.data.* ;
import skit.data.value.* ;
import java.io.* ;
import java.util.* ;

/**
 * Map content.
 */
public class MapDataContent extends BasicDataContent
{
	public MapDataContent()
	{
	}
	
	public MapDataContent( Map o )
	{
		super( o ) ;
	}
	
	/**
	 * Get the seq value.
	 */
	public Map mapValue()
	{
		return ((Map)caughtGet()) ;
	}
	
	// too ad hoc ????
	/**
	 * Fill already instantiated object with values from SReadableReader
	 */
	public void fillWithSReadables( Enumeration in )
		throws IOException, SkitIOException
	{
		Map m = new HashMap() ;
		for ( ; in.hasMoreElements() ; )
		{
			SSequence s = (SSequence)in.nextElement() ;
			m.put( s.at( 0 ), s.at( 1 ) ) ;
		}
		
		set( m ) ;
	}
	
	/**
	 * Write the info for the content on an appropriate writer.
	 */
	public void writeInfo( SWritableWriter out, SWritable origVal )
		throws SkitIOException, IOException
	{
		/*
		Map m = mapValue() ;
		out.beginSWritableGroup( this, false, "#!", null ) ;
		out.writeSWritables( new EnumerationTransformer( m.keys(), new MapPairTransformer( m ) ) ) ;
		out.endSWritableGroup() ;
		*/
		
		
		out.beginSWritableGroup( this, true, null, origVal ) ;
		Map m = mapValue() ;
		//System.out.println( "MAP WRINFO " + m ) ;
		out.writeSWritables( new EnumerationTransformer( m.keys(), new MapPairTransformer( m ) ) ) ;
		out.endSWritableGroup() ;
		
	}

}