package skit.data.content ;

import skit.* ;
import java.io.* ;
import skit.data.value.* ;
import skit.data.* ;

/**
 * Content which retrieves its values via a reference via something.
 */
public interface RefContent extends Content, SSpecialWritable
{
}
