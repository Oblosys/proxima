package skit.data.content ;

import skit.* ;
import skit.data.* ;
import skit.data.value.* ;
import java.io.* ;
import java.util.* ;

/**
 * The simplest implementation basis for Content.
 */
public abstract class BasicContent extends ObjectFunctionality
	implements Content, Cloneable
{
	/**
	 * Just maintains data as an Object, if the data is null, no data is available
	 * and some action should/could be taken to retrieve it.
	 * This depends on the specific subclass.
	 */
	protected Object theData = null ;
	
	protected BasicContent()
	{
		
	}
	
	protected BasicContent( Object o )
	{
		theData = o ;
	}
	
	/**
	 * Get it.
	 */
	public Object get()
		throws SkitIOException, IOException
	{
		return theData ;
	}

	/**
	 * Get it, but handle the exceptions which may occur in the getting.
	 */
	public Object caughtGet()
	{
		try
		{
			return get() ;
		}
		catch ( Exception ex )
		{
			return handleGetError( ex ) ;
		}
	}
	
	/**
	 * Handle the get error.
	 * To be overridden in a subclass.
	 */
	protected Object handleGetError( Exception ex )
	{
		skit.log.Logger.warn( "error in getting content", ex ) ;
		return null ;
	}
	
	/**
	 * Set it.
	 */
	public void set( Object o )
		throws SkitIOException, IOException
	{
		theData = o ;
	}

	/**
	 * Set it, but handle the exceptions which may occur in the setting.
	 */
	public void caughtSet( Object o )
	{
		try
		{
			set( o ) ;
		}
		catch ( Exception ex )
		{
			handleSetError( ex, o ) ;
		}
	}
	
	/**
	 * Handle the set error.
	 * To be overridden in a subclass.
	 */
	protected void handleSetError( Exception ex, Object o )
	{
		skit.log.Logger.warn( "error in setting content", ex ) ;
	}
	
	/**
	 * Get part via a key object.
	 */
	public Object getKeyed( Object k )
		throws SkitIOException, IOException
	{
		return null ;
	}
	
	/**
	 * Set part via key object.
	 */
	public void setKeyed( Object k, Object o )
		throws SkitIOException, IOException
	{
	}

	/**
	 * Check if composite can be updated.
	 */
	public boolean isUpdateable()
	{
		return true ;
	}
	
	/**
	 * Get a copy.
	 */
	/*
	public Content copy()
		throws SkitIOException
	{
		try
		{
			BasicContent newV = (BasicContent)clone() ;
			newV.postCopy() ;
			return newV ;
		}
		catch ( CloneNotSupportedException e )
		{
			skit.log.Logger.log( "failed to copy BasicContent", e ) ;
			throw new SkitIOException( "failed to copy BasicContent" ) ;
		}
	}
	*/
	
	/**
	 * To be overridden in subclasses.
	 * Always has to invoke super.postCopy() first.
	 */
	/*
	public void postCopy()
	{
		//theData = theData.clone() ; // ???? TBD
	}
	*/

	/**
	 * Test on equality.
	 */
	public boolean equals( Object c )
	{
		//System.out.println( "CONT EQLS " + this + " and " + c ) ;
		try
		{
			return get().equals( ((Content)c).get() ) ;
		}
		catch( Exception ex )
		{
			skit.log.Logger.warn( "error in equals: ", ex ) ;
			return false ;
		}
	}
	
	/**
	 * Write the info for the content on an appropriate writer.
	 */
	public void writeInfo( SWritableWriter out )
		throws SkitIOException, IOException
	{
		writeInfo( out, null ) ;
	}

	/**
	 * Fill already instantiated object with values from SReadableReader
	 * @return the filled readable or a suitable replacement for it.
	 */
	public SSpecialReadable fillWithSReadables( Enumeration in )
		throws IOException, SkitIOException
	{
		if ( ! in.hasMoreElements() )
			throw new SkitIOException( "expected data for BasicContent" ) ;
		
		set( in.nextElement() ) ;
		return this ;
		//super.fillWithSReadables( in ) ;
	}
	
	public int hashCode()
	{
		return theData.hashCode() ;
	}
	
	public String toString()
	{
		return theData.toString() ;
	}

}
