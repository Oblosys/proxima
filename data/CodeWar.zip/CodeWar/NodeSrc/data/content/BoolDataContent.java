package skit.data.content ;

import skit.* ;
import skit.data.* ;
import skit.data.value.* ;
import java.io.* ;

/**
 * Boolean content.
 */
public class BoolDataContent extends BasicDataContent
{
	public BoolDataContent()
	{
	}
	
	public BoolDataContent( boolean o )
	{
		this( new Boolean( o ) ) ;
	}
	
	public BoolDataContent( Boolean o )
	{
		super( o ) ;
	}
	
	/**
	 * Get the bool value.
	 */
	public boolean boolValue()
	{
		return ((Boolean)caughtGet()).booleanValue() ;
	}
	
	/**
	 * Write the info for the content on an appropriate writer.
	 */
	public void writeInfo( SWritableWriter out, SWritable origVal )
		throws SkitIOException, IOException
	{
		out.print( boolValue() ) ;
	}

}
