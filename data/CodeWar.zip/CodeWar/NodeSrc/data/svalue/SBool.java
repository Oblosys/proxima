package skit.data.value ;

import skit.textio.* ;
import skit.* ;
import skit.data.* ;
import skit.data.content.* ;
import java.io.* ;

/**
 * Skit value.
 * Boolean.
 */
public class SBool extends SContentValue
{
	public SBool()
	{
	}
	
	public SBool( boolean v )
	{
		super( new BoolDataContent( new Boolean( v ) ) ) ;
	}
	
	public boolean boolValue()
	{
		return ((Boolean)getContentData()).booleanValue() ;
	}
	
}