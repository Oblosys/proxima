package skit.data.value ;

import java.util.* ;
import skit.data.* ;
//import skit.util.* ;
//import skit.* ;
//import skit.data.* ;
//import com.objectspace.jgl.*;
//import java.io.* ;

/**
 * Skit value.
 * key/value pairs.
 */
public interface SKeyValue extends SComposite, SSpecialReadWritable
{
	/**
	 * Get all the keys and values in SSequence's of size 2.
	 */
	public Enumeration keysAndValues() ;
	
	/**
	 * Get all the keys.
	 */
	public Enumeration keys() ;
	
	/**
	 * Get a value at a key.
	 */
	public SValue at( String key ) ;
	
	/**
	 * Get a value at a key.
	 */
	public SValue at( SValue key ) ;
	
	/**
	 * Update value at a key with value from new one.
	 * Allowed only when updateable.
	 */
	public void updateAt( String key, SValue v ) ;
	
	/**
	 * Remove value at a key.
	 * Allowed only when updateable.
	 */
	public void removeAt( SValue key ) ;
	
	/**
	 * Remove value at a key.
	 * Allowed only when updateable.
	 */
	public void removeAt( String key ) ;
	
	/**
	 * Check for existence of key.
	 */
	public boolean hasAt( SValue key ) ;
	
	/**
	 * Check for existence of key.
	 */
	public boolean hasAt( String key ) ;
	
	/**
	 * Update value at a key with value from new one.
	 * Allowed only when updateable.
	 */
	public void updateAt( SValue key, SValue v ) ;
	
	/**
	 * Update with values from other one.
	 */
	public void updateWith( SKeyValue other ) ;
		
}



