package skit.data.value ;

import skit.* ;
import java.io.* ;

/**
 * Something which can be written as a SValue (and later be read as such),
 * using SWritableWriter.
 * @see skit.data.value.SWritableWriter
 */
public interface SWritable
{
	/**
	 * Write the info for the content on an appropriate writer.
	 */
	public void writeInfo( SWritableWriter out )
		throws SkitIOException, IOException ;

}