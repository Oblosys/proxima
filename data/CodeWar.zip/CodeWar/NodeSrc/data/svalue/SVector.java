package skit.data.value ;

import skit.* ;
import skit.data.* ;
import skit.data.content.* ;
//import skit.value.* ;
//import skit.value.type.* ;
import java.util.* ;
import com.objectspace.jgl.*;
import java.io.* ;

/**
 * Skit value.
 * Vector of values.
 */
public class SVector extends BasicSValue
	implements SSequence
{
	public SVector()
	{
		this( 0 ) ;
	}
	
	public SVector( int size )
	{
		this( size, BasicSValue.nil() ) ;
	}
	
	public SVector( int size, SValue defValue )
	{
		super( new Array( size, defValue ) ) ;
	}
	
	public SVector( Enumeration elts )
	{
		this() ;
		fillWith( elts ) ;
	}
	
	private Sequence seqValue()
	{
		return ((Sequence)getData()) ;
	}
	
	/**
	 * Refill the sequence with new values.
	 */
	public void refillWith( Enumeration elts )
	{
		fillWith( elts, true ) ;
	}
	
	public void fillWith( Enumeration elts )
	{
		fillWith( elts, false ) ;
	}
	
	private void fillWith( Enumeration elts, boolean doClear )
	{
		Sequence values = seqValue() ;
		if ( doClear )
			values.clear() ;
		for ( ; elts.hasMoreElements() ; )
			values.pushBack( elts.nextElement() ) ;
		setData( values ) ;
	}
	
	public Enumeration elements()
	{
		return seqValue().elements() ;
	}
	
	public int getSize()
	{
		return seqValue().size() ;
	}
	
	/**
	 * @return true if empty.
	 */
	public boolean isEmpty()
	{
		return getSize() == 0 ;
	}
	
	/**
	 * Get a value of a sequence at a position.
	 * @param The position within the sequence.
	 * @return The value, or null if none.
	 */
	public SValue at( int pos )
	{
		return (SValue)seqValue().at( pos ) ; // ???? check on size
	}
	
	/**
	 * Check if the value matches a type.
	 */
	/*
	public boolean satisfies( CompositeType tp )
	{
		return true ; // ???? for now
	}
	*/

	/**
	 * Check if composite can be updated.
	 */
	public boolean isUpdateable()
	{
		return true ;
	}
	
	/**
	 * Update value at a position with value from new one.
	 * Allowed only when updateable.
	 */
	public void updateAt( int pos, SValue v )
	{
		Sequence values = seqValue() ;
		values.put( pos, v ) ;
		setData( values ) ;
	}
	
	/**
	 * Remove value at a position.
	 * Allowed only when updateable.
	 */
	/*
	public void removeAt( int pos )
	{
		Sequence values = seqValue() ;
		values.remove( pos ) ;
		setData( values ) ;
	}
	*/
	
	/**
	 * Remove value.
	 * Allowed only when updateable.
	 */
	public void remove( SValue v )
	{
		Sequence values = seqValue() ;
		values.remove( v ) ;
		setData( values ) ;
	}
	
	/**
	 * Append value at at end.
	 * Allowed only when updateable.
	 */
	public void updateAppend( SValue v )
	{
		Sequence values = seqValue() ;
		values.pushBack( v ) ;
		setData( values ) ;
	}
	
	/**
	 * @see skit.ObjectFunctionality.
	 */
	protected void postShallowCopy()
		throws SkitException
	{
		super.postShallowCopy() ;
		setData( (Sequence)seqValue().clone() ) ;
	}
	
	/**
	 * @see skit.data.value.SValue#postCopy()
	 */
	/*
	protected void postCopy()
		throws SkitException
	{
		super.postCopy() ;
		setData( (Sequence)seqValue().clone() ) ;
	}
	*/
	
	/**
	 * Write the info for the content on an appropriate writer.
	 */
	public void writeInfo( SWritableWriter out )
		throws SkitIOException, IOException
	{
		out.beginSWritableGroup( this, false, "#", null ) ;
		out.writeSWritables( elements() ) ;
		out.endSWritableGroup() ;
	}

}


