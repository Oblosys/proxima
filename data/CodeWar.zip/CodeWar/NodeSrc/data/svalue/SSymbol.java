package skit.data.value ;

import com.objectspace.jgl.* ;
//import skit.textio.* ;
import skit.data.* ;
import skit.data.content.* ;
import skit.* ;
import java.io.* ;

/**
 * Scheme language.
 * Symbol.
 */
public class SSymbol extends SString
{
	public static final String SPECIAL_PREFIX = "#!" ;
	
	public static final SSymbol quote ;
	
	private static Map symbols ;
	
	static
	{
		symbols = new HashMap() ;
		quote = newSymbol( "quote" ) ;
	}
	
	public SSymbol() // ????
	{
	}
	
	private SSymbol( String s )
	{
		super( new SymbolDataContent( s ) ) ;
		symbols.put( s, this ) ;
	}
	
	/**
	 * Make a new symbol of a string.
	 */
	public static SSymbol newSymbol( String str )
	{
		str = str.intern() ;
		SSymbol sym = (SSymbol)symbols.get( str ) ;
		if ( sym == null )
		{
			sym = new SSymbol( str ) ;
		}
		return sym ;
	}

	/**
	 * Make a new symbol of a string.
	 */
	public static SSymbol newSpecialSymbol( String str )
	{
		return newSymbol( SPECIAL_PREFIX + str ) ;
	}

}