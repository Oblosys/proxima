package skit.data.value ;

import skit.textio.* ;
import skit.data.* ;
import java.util.* ;
import java.io.* ;
import skit.* ;
import skit.util.* ;

/**
 * A SWritableWriter writes a SValue, or datum.
 */
public interface SWritableWriter extends IOBehavior
{
	/**
	 * Write a SWritable.
	 */
	public void writeSWritable( SWritable sval )
		throws SkitIOException, IOException ;
	
	/**
	 * Write a SWritable's.
	 */
	public void writeSWritables( Enumeration svals )
		throws SkitIOException, IOException ;
	
	/**
	 * Write a SValueable. ???? soon to be obsolete.
	 */
	//public void writeSValueable( SValueable sval, SValue origVal )
	//	throws SkitIOException, IOException ;
	
	/**
	 * Write a SSpecialWritable.
	 */
	public void writeSSpecialWritable( SSpecialWritable sval, SWritable origVal )
		throws SkitIOException, IOException ;
	
	/**
	 * Begin a group of SValue's
	 */
	public void beginSWritableGroup( SWritable val, boolean special, String specialName, SWritable forVal )
		throws SkitIOException, IOException ;

	/**
	 * End a group of SValue's
	 */
	public void endSWritableGroup()
		throws SkitIOException, IOException ;

	/**
	 * Print a nil value.
	 */
	public void printNil()
		throws SkitIOException, IOException ;

	/**
	 * Print a value: a boolean
	 */
	public void print( boolean v )
		throws SkitIOException, IOException ;

	/**
	 * Print a value: a char
	 */
	public void print( char v )
		throws SkitIOException, IOException ;

	/**
	 * Print a value: a long
	 */
	public void print( long v )
		throws SkitIOException, IOException ;

	/**
	 * Print a value: a String
	 */
	public void print( String v )
		throws SkitIOException, IOException ;

	/**
	 * Print a String as symbol
	 */
	public void printSymbol( String v )
		throws SkitIOException, IOException ;

}
