package skit.data.value ;

//import skit.textio.* ;
//import skit.value.* ;
//import skit.value.type.* ;
import java.io.* ;
import java.util.* ;
import skit.util.* ;
import skit.data.* ;
import skit.data.value.* ;
import skit.* ;

/**
 * Skit value.
 * A skit encoding of a type.
 */
public class SType extends BasicSSpecialReadWritable
	implements Type
{
	public static final SValue TP_ANYTHING ;
	public static final SValue TP_ALT ;
	public static final SValue TP_SEQ ;
	
	static
	{
		TP_ANYTHING = BasicSValue.newSymbol( "?" ) ;
		TP_ALT = BasicSValue.newSymbol( "alt" ) ;
		TP_SEQ = BasicSValue.newSymbol( "seq" ) ;
	}
	
	private SValue type ;
	
	public SType()
	{
	}
	
	public SType( SValue v )
	{
		type = v ;
	}
	
	/**
	 * Get the nr of subtypes.
	 * This is 1 if just a value, or the actual subtypes in case of a composite.
	 */
	public int getSize(  )
	{
		return isComposite() ? ( ((SSequence)type).getSize() - 1 ) : 1 ;
	}
	
	/**
	 * Get a value of a spec at a position.
	 */
	public SValue at( int pos )
	{
		if ( isComposite() )
		{
			return ((SSequence)type).at( pos + 1 ) ;
		}
		else
		{
			return pos > 0 ? null : type ;
		}
	}
	
	/**
	 * Update a value of a spec at a position.
	 */
	public void updateAt( int pos, SValue v )
	{
		if ( isComposite() )
		{
			((SSequence)type).updateAt( pos + 1, v ) ;
		}
		else if ( pos == 0 )
		{
			type = v ;
		}
	}
	
	/**
	 * Get the subtypes, if the type is a composite, otherwise crash
	 */
	private Enumeration getSubTypes()
	{
		return ((SSequence)type).elements() ;
	}
	
	/**
	 * Make a new SType by parsing/reading a string.
	 */
	public static SType from( String str )
		throws SkitTypeException
	{
		try
		{
			return new SType( (SValue)BasicSValue.from( str ) ) ;
		}
		catch( Exception ex )
		{
			throw new SkitTypeException( "not a type descr: " + str ) ;
		}
	}
	
	/**
	 * Check if a value satisfies a typevalue.
	 */
	/*
	public boolean satisfies( Value val )
	{
		return val instanceof SValue && satisfies( (SValue)val ) ;
	}
	*/
	
	/**
	 * Check if a value satisfies a typevalue.
	 */
	public boolean satisfies( SValue val )
	{
		if ( ! ( type instanceof SSequence ) )
		{
			if ( type == TP_ANYTHING )
			{
				return true ;
			}
			else
			{
				return type.equals( val ) ;
			}
		}
		else
		{
			return satisfiesComposite( getSubTypes(), val ) ;
		}
	}
	
	/**
	 * Check if a value satisfies a composite typevalue.
	 */
	private boolean satisfiesComposite( Enumeration types, SValue val )
	{
		if ( ( ! types.hasMoreElements() ) && val.equalsNil() )
		{
			return true ;
		}
		else
		{
			SValue first = (SValue)types.nextElement() ;
			Enumeration rest = new EnumerationTransformer
									( types
									, new SValueTypeTransformer()
									) ;
			if ( first == TP_ALT )
			{
				return satisfiesAlternatives( rest, val ) ;
			}
			else if ( first == TP_SEQ )
			{
				return satisfiesSequence( rest, val ) ;
			}
			else
				return false ;
		}
	}
	
	/**
	 * Check if a value satisfies a alternatives typevalue.
	 */
	private boolean satisfiesAlternatives( Enumeration types, SValue val )
	{
		for ( ; types.hasMoreElements() ; )
		{
			Type tp = (Type)types.nextElement() ;
			if ( tp.satisfies( val ) )
				return true ;
		}
		return false ;
	}
	
	/**
	 * Check if a value satisfies a sequence typevalue.
	 */
	private boolean satisfiesSequence( Enumeration types, SValue val )
	{
		if ( ! ( val instanceof SSequence ) )
			return false ;
		SSequence seq = (SSequence)val ;
		Enumeration values ;
		for ( values = seq.elements() ; types.hasMoreElements() && values.hasMoreElements() ; )
		{
			Type tp = (Type)types.nextElement() ;
			SValue v = (SValue)values.nextElement() ;
			if ( ! tp.satisfies( v ) )
				return false ;
		}
		return ! ( types.hasMoreElements() || values.hasMoreElements() ) ;
	}
	
	/**
	 * Check if type is a composite.
	 */
	public boolean isComposite()
	{
		if ( ! ( type instanceof SSequence ) )
			return false ;
		Enumeration e = getSubTypes() ;
		if ( e.hasMoreElements() )
		{
			SValue v = (SValue)e.nextElement() ;
			return v == TP_SEQ || v == TP_ALT ;
		}
		return false ;
	}
	
	// here ????
	/**
	 * 
	 */
	public static boolean isIndexable( SValue val )
	{
		return 
			!
				(	( val instanceof SSequence )
				||	( val instanceof SMap )
				||	( val == TP_ANYTHING )
				) ;
	}
	
	/**
	 * Get the position/value pairs which are indexable.
	 */
	/*
	public SSequence indexables()
	{
		Enumeration types = getSubTypes() ;
		SSequence inxs = SValue.newVector() ;
		
		if ( types.hasMoreElements() )
		{
			SValue first = (SValue)types.nextElement() ;
			if ( first == TP_SEQ )
			{
				for ( int pos = 0 ; types.hasMoreElements() ; pos++ )
				{
					SValue v = (SValue)types.nextElement() ;
					if ( isIndexable( v ) )
					{
						inxs.updateAppend( BasicSValue.newPair( BasicSValue.newInt( pos ), v ) ) ;
					}
				}
			}
		}
		return inxs ;
	}
	*/
	
	public SValue typeValue()
	{
		return (SValue)type ;
	}
	
	/**
	 * Write the info for the content on an appropriate writer.
	 */
	public void writeSpecialInfo( SWritableWriter out )
		throws SkitIOException, IOException
	{
		out.writeSWritable( type ) ;
		super.writeSpecialInfo( out ) ;
	}
	
	/**
	 * Get all the fixed svalues to be put on the writer.
	 * Meant to be overridden/implemented in subclass.
	 */
	/*
	public Enumeration getWriterFixedSValues( )
	{
		return new OneEnumeration( typeValue() ) ;
	}
	*/
	
	/**
	 * Get all the fixed svalues to be put on the writer.
	 * Meant to be overridden/implemented in subclass.
	 */
	/*
	public Enumeration getWriterVariableSValues( )
	{
		return new EmptyEnumeration() ;
	}
	*/
	
	/**
	 * Fill already instantiated object with values from SReadableReader
	 * @return the filled readable or a suitable replacement for it.
	 */
	public SSpecialReadable fillWithSReadables( Enumeration in )
		throws IOException, SkitIOException
	{
		type = (SValue)in.nextElement() ;
		return super.fillWithSReadables( in ) ;
	}
	

	
	public int hashCode()
	{
		return type.hashCode() ;
	}
	
	public boolean equals( Object o )
	{
		return type.equals( o ) ;
	}
	
}

class SValueTypeTransformer implements Transformer
{
	public SValueTypeTransformer(  )
	{
	}
	
	public Object transform( Object sval )
	{
		return new SType( (SValue)sval ) ;
	}
}
