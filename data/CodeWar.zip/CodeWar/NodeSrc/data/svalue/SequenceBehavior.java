package skit.data.value ;

//import skit.value.* ;
import java.util.* ;

/**
 * Just behavior.
 * Sequence.
 */
public interface SequenceBehavior extends CompositeBehavior
{
	/**
	 * Get a value of a Sequence at a position.
	 * @param The position within the composite.
	 * @return The value, or null if none.
	 */
	public SValue at( int pos ) ;
	
	/**
	 * Update value at a position with value from new one.
	 * Allowed only when updateable.
	 */
	public void updateAt( int pos, SValue v ) ;
	
	/**
	 * Append value at at end.
	 * Allowed only when updateable.
	 */
	public void updateAppend( SValue v ) ;
	
	/**
	 * Remove value at a position.
	 * Allowed only when updateable.
	 */
	//public void removeAt( int pos ) ;
	
	/**
	 * Remove value.
	 * Allowed only when updateable.
	 */
	public void remove( SValue v ) ;
	
	/**
	 * Calculate the intersection.
	 * The original value is left unchanged.
	 */
	//public SSequence intersect( SSequence v ) ;
	
	/**
	 * Refill the sequence with new values.
	 */
	//public void refillWith( Enumeration elts ) ;

}