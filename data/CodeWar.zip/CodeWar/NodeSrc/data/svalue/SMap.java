package skit.data.value ;

//import skit.textio.* ;
//import skit.value.* ;
//import skit.value.type.* ;
import java.util.* ;
import skit.util.* ;
import skit.* ;
import skit.data.* ;
import skit.data.content.* ;
import com.objectspace.jgl.*;
import java.io.* ;

/**
 * Skit value.
 * Map of value pairs.
 */
public class SMap extends BasicSKeyValue
{
	public SMap()
	{
		super( new HashMap() ) ;
	}
	
	public SMap( Enumeration elts )
	{
		this() ;
		fillWith( elts ) ;
	}
	
	private Map mapValue()
	{
		return ((Map)getData()) ;
	}
	
	public void refillWith( Enumeration elts )
	{
		fillWith( elts, true ) ;
	}
	
	public void fillWith( Enumeration elts )
	{
		fillWith( elts, false ) ;
	}
	
	private void fillWith( Enumeration elts, boolean doClear )
	{
		Map values = mapValue() ;
		if ( doClear )
			values.clear() ;
		for ( ; elts.hasMoreElements() ; )
		{
			Object o = elts.nextElement() ;
			if ( o instanceof SSequence )
			{
				SSequence s = (SSequence)o ;
				values.put( s.at( 0 ), s.at( 1 ) ) ;
			}
		}
		setData( values ) ;
	}
	
	/**
	 * Get all the values.
	 */
	public Enumeration elements()
	{
		return mapValue().elements() ;
	}
	
	/**
	 * Get all the keys and values in sequences.
	 */
	public Enumeration keysAndValues()
	{
		return SKeyValueFunctionality.keysAndValues( this ) ;
		/*
		Map m = mapValue() ;
		return 
			( new EnumerationTransformer
					( m.keys()
					, new MapPairTransformer( m )
					)
			) ;
		*/
	}
	
	/**
	 * Get all the keys.
	 */
	public Enumeration keys()
	{
		return mapValue().keys() ;
	}
	
	/**
	 * Get the size.
	 */
	public int getSize()
	{
		return mapValue().size() ;
	}
	
	/**
	 * Get a value of map at a key.
	 */
	public SValue at( SValue key )
	{
		return (SValue)mapValue().get( key ) ;
	}
	
	/**
	 * Check if composite can be updated.
	 */
	public boolean isUpdateable()
	{
		return true ;
	}
	
	/**
	 * Update value at a key with value from new one.
	 * Allowed only when updateable.
	 */
	public void updateAt( SValue key, SValue v )
	{
		mapValue().put( key, v ) ;
	}
	
	/**
	 * Remove value at a key.
	 * Allowed only when updateable.
	 */
	public void removeAt( SValue key )
	{
		mapValue().remove( key ) ;
	}
	
	/**
	 * Check for existence of key.
	 */
	public boolean hasAt( SValue key )
	{
		return at( key ) != null ;
	}
	
	/**
	 * Fill already instantiated object with values from SReadableReader
	 * @return the filled readable or a suitable replacement for it.
	 */
	public SSpecialReadable fillWithSReadables( Enumeration in )
		throws IOException, SkitIOException
	{
		Map m = new HashMap() ;
		for ( ; in.hasMoreElements() ; )
		{
			SSequence s = (SSequence)in.nextElement() ;
			m.put( s.at( 0 ), s.at( 1 ) ) ;
		}
		
		setData( m ) ;
		
		return this ;
	}
	
	/**
	 * Write the info for the content on an appropriate writer.
	 */
	public void writeSpecialInfo( SWritableWriter out )
		throws SkitIOException, IOException
	{
		out.writeSWritables( keysAndValues() ) ;
		//super.writeSpecialInfo( out ) ;
	}
	
	/**
	 * @see skit.ObjectFunctionality.
	 */
	protected void postShallowCopy()
		throws SkitException
	{
		super.postShallowCopy() ;
		setData( (Map)mapValue().clone() ) ;
	}
	
	/**
	 * @see skit.data.value.SValue#postCopy()
	 */
	/*
	protected void postCopy()
		throws SkitException
	{
		super.postCopy() ;
		setData( (Map)mapValue().clone() ) ;
	}
	*/

	/**
	 * Meant to be overridden.
	 */
	public void appendStringRepr( StringBuffer buf )
	{
		SKeyValueFunctionality.appendStringRepr( buf, this ) ;
	}
	

}


