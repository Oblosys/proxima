package skit.data.value ;

//import skit.textio.* ;
import skit.* ;
import skit.data.* ;
import skit.data.content.* ;
import java.util.* ;
import java.io.* ;
//import skit.value.* ;
//import skit.value.type.* ;

/**
 * Skit value.
 * Pair of values.
 */
public class SPair extends BasicSValue
	implements SSequence
{
	public SPair() // ????
	{
	}
	
	public SPair( SValue head, SValue tail )
	{
		this( new Pair( head, tail ) ) ;
	}
	
	public SPair( Pair p )
	{
		super( p ) ;
	}
	
	private Pair pairValue()
	{
		return ((Pair)getData()) ;
	}
	
	public SValue getHead(  )
	{
		return pairValue().head ;
	}

	public void setHead( SValue h )
	{
		Pair p = pairValue() ;
		p.head = h ;
		setData( p ) ;
	}

	public SValue getTail(  )
	{
		return pairValue().tail ;
	}

	public void setTail( SValue t )
	{
		Pair p = pairValue() ;
		p.tail = t ;
		setData( p ) ;
	}

	public Enumeration elements()
	{
		return new SPairEnumeration( this ) ;
	}
	
	public int getSize()
	{
		int count ;
		SValue p = this ;
		for ( count = 0 ; p instanceof SPair ; count++, p = ((SPair)p).getTail() )
		{
		}
		return count ;
	}
	
	/**
	 * @return true if empty.
	 */
	public boolean isEmpty()
	{
		return false ;
	}
	
	/**
	 * Get a value of a sequence at a position.
	 * Replace with new value if it is not null.
	 * @param The position within the sequence.
	 * @return The value, or null if none.
	 */
	private SValue atAndPut( int pos, SValue newV )
	{
		SValue p = this ;
		for ( 
			; p instanceof SPair && pos > 0
			; pos--, p = ((SPair)p).getTail()
			)
		{
		}
		SValue oldV = ( p instanceof SPair ) ? ((SPair)p).getHead() : null ;
		if ( oldV != null && newV instanceof SValue )
			((SPair)p).setHead( newV ) ; 
		return oldV ;
	}
	
	/**
	 * Replace the tail at the end, only if not null.
	 * @return The old tail value.
	 */
	private SValue updateTailAtEnd( SValue newV )
	{
		SPair p = this ;
		SValue tail ;
		for ( 
			; (tail = p.getTail()) instanceof SPair
			; p = (SPair)tail
			)
		{
		}
		SValue oldV = tail ;
		if ( newV != null )
			p.setTail( newV ) ;
		return oldV ;
	}
	
	/**
	 * Get a value of a sequence at a position.
	 * @param The position within the sequence.
	 * @return The value, or null if none.
	 */
	public SValue at( int pos )
	{
		return atAndPut( pos, null ) ;
	}
	
	/**
	 * Check if composite can be updated.
	 */
	public boolean isUpdateable()
	{
		return true ;
	}
	
	/**
	 * Update value at a position with value from new one.
	 * Allowed only when updateable.
	 */
	public void updateAt( int pos, SValue v )
	{
		atAndPut( pos, (SValue)v ) ;
	}
	
	/**
	 * Remove value at a position.
	 * Allowed only when updateable.
	 */
	public void removeAt( int pos )
	{
		// ???? TBD
	}
	
	/**
	 * Remove value.
	 * Allowed only when updateable.
	 */
	public void remove( SValue v )
	{
		// ???? TBD
	}
	
	/**
	 * Append value at at end.
	 * Allowed only when updateable.
	 */
	public void updateAppend( SValue v )
	{
		updateTailAtEnd( BasicSValue.newPair( (SValue)v, BasicSValue.empty() ) ) ;
	}
	
	/**
	 * Print as list on output with indent.
	 * @see	print
	 */
	/*
	private void printAsList( SWritableWriter out )
		throws SkitIOException, IOException
	{
		SValue list = this ;
		out.print( '(' ) ;
		out.writeSWritable( ((SPair)list).getHead() ) ;
		//((SPair)list).getHead().print( out ) ;
		for ( list = ((SPair)list).getTail() ; list instanceof SPair ; list = ((SPair)list).getTail() )
		{
			out.print( ' ' ) ;
			out.writeSWritable( ((SPair)list).getHead() ) ;
			//((SPair)list).getHead().print( out ) ;
		}
		if ( ! list.equalsNil() )
		{
			out.print( " . " ) ;
			out.writeSWritable( list ) ;
			//list.print( out ) ;
		}
		out.print( ')' ) ;
	}
	*/
	
	/**
	 * Print on output with indent.
	 * @see	skit.textio.TextOutputable
	 */
	/*
	public void print( SWritableWriter out )
		throws SkitIOException, IOException
	{
		SValue v ;
		if ( (v = (SValue)at( 0 )) != null && v == SSymbol.quote )
		{
			out.print( '\'' ) ;
			out.writeSWritable( (SValue)at( 1 ) ) ;
			//((SValue)at( 1 )).print( out ) ;
		}
		else
			printAsList( out ) ;
	}
	*/
	
	protected boolean equalsRest( SValue o )
	{
		SValue p = this ;
		for (
			; p instanceof SPair && o instanceof SPair
			; p = ((SPair)p).getTail(), o = ((SPair)o).getTail()
			)
		{
			if ( ! ((SPair)p).getHead().equals( ((SPair)o).getHead() ) )
				return false ;
		}
		return ((SPair)p).getTail().equals( ((SPair)o).getTail() ) ;
	}
	
	/**
	 * Write the info for the content on an appropriate writer.
	 */
	public void writeInfo( SWritableWriter out )
		throws SkitIOException, IOException
	{
		out.beginSWritableGroup( this, false, null, null ) ;
		out.writeSWritables( elements() ) ;
		out.endSWritableGroup() ;
	}

}
