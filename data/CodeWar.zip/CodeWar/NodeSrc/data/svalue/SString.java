package skit.data.value ;

import skit.textio.* ;
import skit.* ;
import skit.data.* ;
import skit.data.content.* ;
import java.io.* ;

/**
 * Skit value.
 * String.
 */
public class SString extends SContentValue
{
	public SString()
	{
	}
	
	public SString( String s )
	{
		this( new StringDataContent( s ) ) ;
		//str = new char[ s.length() ] ;
		//s.getChars( 0, str.length, str, 0 ) ;
	}
	
	public SString( Content c )
	{
		super( c ) ;
	}
	
	/**
	 *
	 */
	public String strValue()
	{
		return ((String)getContentData()) ;
	}
	
}