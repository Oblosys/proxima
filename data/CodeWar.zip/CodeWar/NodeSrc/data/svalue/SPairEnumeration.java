package skit.data.value ;

import skit.* ;
import skit.data.* ;
import skit.data.value.* ;
import java.util.* ;

/**
 * Enumeration of pairs
 */
public class SPairEnumeration implements Enumeration
{
	private SValue pair ;
	
	public SPairEnumeration( SPair p )
	{
		pair = p ;
	}
	
	public SPairEnumeration( Pair p )
	{
		this( BasicSValue.newPair( p ) ) ;
	}
	
	public boolean hasMoreElements()
	{
		return pair instanceof SPair ;
	}
	
	public Object nextElement()
	{
		Object res = null ;
		if ( hasMoreElements() )
		{
			res = ((SPair)pair).getHead() ;
			pair = ((SPair)pair).getTail() ;
		}
		return res ;
	}
}