package skit.data.value ;

//import skit.value.* ;
import java.util.* ;

/**
 * Skit value.
 * Sequence.
 */
public interface SSequence extends SComposite, SequenceBehavior
{
}