package skit.data.value ;

import skit.textio.* ;
import skit.* ;
import skit.data.* ;
import skit.data.content.* ;
import java.io.* ;

/**
 * Skit value.
 * String.
 */
public class SInt extends BasicSValue
{
	public SInt()
	{
	}
	
	public SInt( long v )
	{
		super( new Long( v ) ) ;
	}
	
	public int intValue()
	{
		return ((Long)getData()).intValue() ;
	}
	
	public long longValue()
	{
		return ((Long)getData()).longValue() ;
	}
	
	/**
	 * Write the info for the content on an appropriate writer.
	 */
	public void writeInfo( SWritableWriter out )
		throws SkitIOException, IOException
	{
		out.print( longValue() ) ;
	}

}