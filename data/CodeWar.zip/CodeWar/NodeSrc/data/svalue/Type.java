package skit.data.value ;

//import skit.value.* ;

/**
 * A Type describes the type of a value.
 */
public interface Type
{
	/**
	 * Check if a value satisfies a typevalue.
	 */
	public abstract boolean satisfies( SValue val ) ;
	
	/**
	 * Get the position/value pairs which are indexable.
	 */
	//public SSequence indexables(  ) ;
	
	/**
	 * Get the nr of subtypes.
	 * This is 1 if just a value, or the actual subtypes in case of a composite.
	 */
	public int getSize() ;
	
	/**
	 * Get a value of a spec at a position.
	 */
	public SValue at( int pos ) ;
	
}