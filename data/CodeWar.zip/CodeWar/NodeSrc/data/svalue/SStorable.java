package skit.data.value ;

//import skit.textio.* ;
//import skit.value.* ;
//import skit.value.type.* ;
import java.util.* ;
import skit.util.* ;
import skit.id.* ;
import skit.* ;
import skit.data.* ;
//import skit.data.content.* ;
import skit.data.store.* ;
//import com.objectspace.jgl.*;
import java.io.* ;

/**
 * Skit value.
 * Storable.
 */
public abstract class SStorable extends BasicSValue
	implements SSpecialReadWritable
//	implements Storable
{
	public SStorable()
	{
		// this( "stored" ) ;
	}
	
	protected static Storable newStorable( String storableKind, String storeName )
	{
		Storable n = null ;
		UniqueId id = null ;
		try
		{
					// ????: "node/" as global var, see Setup, ....
			n = (Storable)skit.Globals.getSReadWritableFactory().makeIt( storableKind ) ;
			id = n.getEnsureId( storeName ) ;
		}
		catch( SkitException ex )
		{
			skit.log.Logger.fatal( "failure in creation of storable " + storableKind, ex ) ;
		}
		return n ;
	}
	
	protected static Storable newStorable( String storableKind )
	{
		return newStorable( storableKind, skit.Globals.getStorage().getCurrentStoreName() ) ;
	}
	
	protected static Storable newStorable( UniqueId id )
	{
		Storable n = null ;
		try
		{
			n = skit.Globals.getStorage().getStorableById( id ) ;
		}
		catch( SkitException ex )
		{
			skit.log.Logger.fatal( "failure in retrieval of storable " + id, ex ) ;
		}
		return n ;
	}
	
	public SStorable( Storable st )
	{ 
		super( st ) ;
	}
	
	public SStorable( String storableKind )
	{ 
		this( newStorable( storableKind ) ) ;
	}
	
	private Storable storableValue()
	{
		return ((Storable)getData()) ;
	}
	
	/**
	 * Get the size.
	 */
	public int getSize()
	{
		try
		{
			return storableValue().getSize() ;
		}
		catch ( SkitIOException ex )
		{
			skit.log.Logger.warn( "error in getting storable size", ex ) ;
			return 0 ;
		}
	}
	
	/**
	 * Check if composite can be updated.
	 */
	public boolean isUpdateable()
	{
		return storableValue().isUpdateable() ;
	}
	
	/**
	 * Fill already instantiated object with values from SReadableReader
	 * @return the filled readable or a suitable replacement for it.
	 */
	public SSpecialReadable fillWithSReadables( Enumeration in )
		throws IOException, SkitIOException
	{
		if ( ! in.hasMoreElements() )
			throw new SkitIOException( "expected id for SStorable" ) ;
		
		setData( SStorable.newStorable( (UniqueId)in.nextElement() ) ) ;
		
		return this ;
		//super.fillWithSReadables( in ) ;
	}
	
	/**
	 * Write the info for the content on an appropriate writer.
	 */
	public void writeSpecialInfo( SWritableWriter out )
		throws SkitIOException, IOException
	{
		out.writeSWritable( storableValue().getId() ) ;
		//super.writeSpecialInfo( out ) ;
	}

	
}


