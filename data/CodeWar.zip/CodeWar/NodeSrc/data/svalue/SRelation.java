package skit.data.value ;

import java.util.* ;
//import skit.data.store.* ;
//import skit.value.type.* ;
import skit.* ;
import skit.data.relation.* ;

/**
 * The behavior exposed by a relation.
 */
public interface SRelation extends CompositeBehavior, SValue
{
	/**
	 * Set the meta info of a relation.
	 * This may influence the actual behavior and performance.
	 */
	public void setMetaInfo( RelationMetaInfo info ) ;

	/**
	 * Make a prototypical empty relationship for this relation
	 */
	public Relationship newEmptyRelationship() ;

	/**
	 * Make a prototypical relationship for this relation, though filled with default values
	 * and having the right size.
	 */
	public Relationship newFilledRelationship() ;

	/**
	 * Make a query spec for the relation which will match any relationship.
	 * Meant to be adapted afterwards to match more precise criteria as used in a query.
	 */
	public QuerySpec newQuerySpec() ;

	/**
	 * Get a relationship of a relation at a position.
	 * @param The position within the relation.
	 * @return The value, or null if none.
	 */
	//public Relationship at( int pos )
	
	/**
	 * @return The type of the relation.
	 */
	public Type getType() ;
	
	/**
	 * @return The size of relationships.
	 */
	public int getRelshipSize() ;
	
	/**
	 * Add a relationship.
	 * Even if the relationship is already part of a relation,
	 * a copy will be added.
	 * Type checking will be done as indicated by checkType.
	 * @return	The added relationship or copy.
	 */
	public Relationship add( Relationship rs, boolean checkType )
		throws SkitIOException ;
	
	/**
	 * Remove a relationship.
	 * If the relationship is not part of the relation,
	 * it will not be removed.
	 */
	public void remove( Relationship rs )
		throws SkitIOException ;
	
	/**
	 * Remove a relationship at a position in the relation.
	 * This method preferably should not be used,
	 * but is necessary for implementation reasons.
	 * May become obsolete in the future.
	 */
	//public void removeAt( int pos )
	//	throws SkitIOException ;
	
	/**
	 * Remove relationships via the query.
	 */
	public void remove( Query remQuery )
		throws SkitIOException ;
	
	/**
	 * Update a relationship of a relation with values from a new one.
	 * Check if types match if indicated so.
	 * @see skit.data.relation.SRelation
	 */
	public void update( Relationship oldNR, Relationship newNR, boolean checkType )
		throws SkitIOException ;
	
	/**
	 * Update a relationship with values from a new one.
	 * This method preferably should not be used,
	 * but is necessary for implementation reasons.
	 * May become obsolete in the future.
	 * Check if types match if indicated so.
	 * @see skit.data.relation.SRelation
	 */
	//public void updateAt( int pos, Relationship newNR, boolean checkType )
	//	throws SkitIOException ;
	
	/**
	 * Query a relation.
	 * @return A query on the relation.
	 */
	public Query query( QuerySpec spec )
		throws SkitIOException ;
	
		
}