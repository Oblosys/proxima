package skit.data.value ;

import skit.lang.* ;
import skit.util.* ;
import skit.data.* ;
import skit.data.content.* ;
import skit.data.store.* ;
import java.util.* ;
import java.io.* ;
import skit.* ;
import skit.textio.* ;
import java.io.* ;

/**
 * A BasicSWritableWriter writes SValue's.
 * @see skit.data.value.SWritableWriter
 * @see skit.data.value.SValueable
 */
public class BasicSWritableWriter
	implements SWritableWriter
{
	private Writer out ;
	private TextOutput textOut ;
	private boolean inputable ;
	private String terminator ;
	private int indent ;		// not used yet
	
	public BasicSWritableWriter( Writer out, boolean inpable, String term )
	{
		this.out = out ;
		textOut = new TextOutput( out ) ;
		inputable = inpable ;
		terminator = term ;
		indent = 0 ;
	}
	
	private void error( String msg )
		throws SkitIOException
	{
		throw new SkitIOException( msg ) ;
	}
	
	
	/**
	 * Begin a group of SValue's
	 */
	public void beginSWritableGroup( SWritable val, boolean special, String specialName, SWritable forVal )
		throws SkitIOException, IOException
	{
		if ( specialName != null )
			textOut.print( specialName ) ;
		
		//if ( specialName != null )
		//	textOut.print( specialName ) ;
		
		if ( special )
		{
			String mimeSValue ;
			if ( forVal != null )
			{
				mimeSValue = skit.Globals.getSValueMimeRegistry().reverseResolve( forVal.getClass() ) ;
				if ( mimeSValue == null )
					mimeSValue = "??/??" ;
			}
			else
			{
				mimeSValue = "" ;
			}
			String mimeContent = skit.Globals.getSWritableMimeRegistry().reverseResolve( val.getClass() ) ;
			if ( mimeContent == null )
				mimeContent = "??/??" ;
			String txt ;
			textOut.print( txt = '#' + mimeSValue + '#' + mimeContent ) ;
			//System.out.println( "WRITE GROUP (" + txt + ") " + val.getClass() ) ;
		}
		
		textOut.print( '(' ) ;
	}

	/**
	 * End a group of SValue's
	 */
	public void endSWritableGroup()
		throws SkitIOException, IOException
	{
		textOut.print( ") " ) ;
		//System.out.println( "END GROUP" ) ;
	}

	/**
	 * Write a SWritable's.
	 */
	public void writeSWritables( Enumeration vals )
		throws SkitIOException, IOException
	{
		if ( vals.hasMoreElements() )
		{
			Object val = vals.nextElement() ;
			//System.out.println( "WRITE SW's " + val ) ;
			//writeSWritable( (SValue)vals.nextElement() ) ;
			((SWritable)val).writeInfo( this ) ;
		}
		for ( ; vals.hasMoreElements() ; )
		{
			textOut.print( ' ' ) ;
			//out.writeSWritable( (SValue)vals.nextElement() ) ;
			((SWritable)vals.nextElement()).writeInfo( this ) ;
			//((SValue)vals.nextElement()).print( out ) ;
		}
	}

	/**
	 * Print a nil value.
	 */
	public void printNil()
		throws SkitIOException, IOException
	{
		textOut.print( "()" ) ;
	}

	/**
	 * Print a value: a boolean
	 */
	public void print( boolean v )
		throws SkitIOException, IOException
	{
		textOut.print( "#" + ( v ? 't' : 'f' ) ) ;
	}

	/**
	 * Print a value: a char
	 */
	public void print( char v )
		throws SkitIOException, IOException
	{
		textOut.print( v ) ;
	}

	/**
	 * Print a value: a long
	 */
	public void print( long v )
		throws SkitIOException, IOException
	{
		textOut.print( v ) ;
	}

	/**
	 * Print a String as symbol
	 */
	public void printSymbol( String v )
		throws SkitIOException, IOException
	{
		textOut.print( v ) ;
	}

	/**
	 * Print a value: a String
	 */
	public void print( String v )
		throws SkitIOException, IOException
	{
		if ( inputable )
			textOut.print( '"' ) ;
		textOut.print( v ) ;		// ????  handling of special chars
		if ( inputable )
			textOut.print( '"' ) ;
	}

	public void writeSWritable( SWritable sval )
		throws SkitIOException, IOException
	{
		//System.out.println( "WRITE " + sval.getClass() ) ;
		writeSWritable( sval, true ) ;
	}
	
	/*
	public void writeStorableContent( Storable sval )
		throws SkitIOException, IOException
	{
		beginSWritableGroup( sval, true, null, null ) ;
		sval.writeSpecialContentInfo( this ) ;
		endSWritableGroup() ;
		textOut.print( terminator ) ;
	}
	*/
	
	private void writeSWritable( SWritable sval, boolean withTerm )
		throws SkitIOException, IOException
	{
		sval.writeInfo( this ) ;
		//sval.print( this, 0, inputable ) ;
		if ( withTerm )
			textOut.print( terminator ) ;
	}
	
	/**
	 * Write a SValueable.
	 */
	/*
	public void writeSValueable( SValueable sval, SValue origVal )
		throws SkitIOException, IOException
	{
		beginSWritableGroup( this, true, null, origVal ) ;
		//String mimeSValue = skit.Globals.getSValueMimeRegistry().reverseResolve( sval.getClass() ) ;
		//if ( mimeSValue == null )
		//	mimeSValue = "??/??" ;
		//Enumeration infoEnum = new OneEnumeration( SValue.newSymbol( mimeSValue ) ) ;
		//print( new EnumerationSequence( infoEnum, sval.getWriterSValues() ) ) ;
		writeSWritables( sval.getWriterSValues() ) ;
		endSWritableGroup() ;
	}
	*/
	
	/**
	 * Write a SSpecialWritable.
	 */
	public void writeSSpecialWritable( SSpecialWritable sval, SWritable origVal )
		throws SkitIOException, IOException
	{
		beginSWritableGroup( sval, true, null, origVal ) ;
		sval.writeSpecialInfo( this ) ;
		endSWritableGroup() ;
	}
	
	/**
	 * Flush data, but do not close.
	 */
	public void flush()
		throws IOException, SkitIOException
	{
		out.flush() ;
	}
	
	/**
	 * Flush data and close.
	 */
	public void close()
		throws IOException, SkitIOException
	{
		out.close() ;
	}
	
	/**
	 * Write string repr for SValueable's.
	 */
	 
	public static String toString( SWritable sval )
	{
		StringWriter sw = new StringWriter( ) ;
		try
		{
			BasicSWritableWriter bsw = new BasicSWritableWriter( sw, true, " " ) ;
			bsw.writeSWritable( sval ) ; // ????
			bsw.close() ;
		}
		catch( Exception e )
		{
			skit.log.Logger.log( "error in BasicSWritableWriter toString()", e ) ;
			return e.toString() ;
		}
		return sw.toString() ;
	}
	
}