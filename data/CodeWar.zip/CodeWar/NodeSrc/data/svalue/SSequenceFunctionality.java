package skit.data.value ;

import java.util.* ;
import skit.data.* ;
import skit.util.* ;
//import skit.util.* ;
//import skit.* ;
//import skit.data.* ;
//import com.objectspace.jgl.*;
//import java.io.* ;

/**
 * Skit value.
 * sequence functionality.
 * Some actual work is delegated to this class.
 * Later.... ???? more
 */
public class SSequenceFunctionality
{
	public static void appendStringRepr( StringBuffer buf, SSequence seq )
	{
		appendStringRepr( buf, seq.elements() ) ;
	}
	
	public static void appendStringRepr( StringBuffer buf, Enumeration e )
	{
		PrintableFunctionality.appendStringRepr( buf, e, PrintableFunctionality.BRACKET_COMMA ) ;
	}
	
}

