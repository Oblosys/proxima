package skit.data.value ;

import skit.util.* ;

/**
 * Transforming a String to a SString
 * @see skit.util.Transformer
 */
public class StringSValueTransformer
	implements Transformer
{
	public Object transform( Object o )
	{
		return BasicSValue.newString( (String)o ) ;
	}
}
