package skit.data.value ;

//import skit.textio.* ;
//import skit.value.* ;
//import skit.value.type.* ;
import java.io.* ;
import java.util.* ;
import skit.util.* ;
import skit.data.* ;
import skit.data.relation.* ;
import skit.data.value.* ;
import skit.* ;

/**
 * Skit value.
 * A skit encoding of a relationship.
 */
public class SRelship extends BasicSSpecialReadWritable
//	implements Relationship
{
	private SSequence relshipData ;
	
	public SRelship()
	{
	}
	
	public SRelship( SSequence v )
	{
		relshipData = v ;
	}
	
	/**
	 * Write the info for the content on an appropriate writer.
	 */
	public void writeSpecialInfo( SWritableWriter out )
		throws SkitIOException, IOException
	{
		out.writeSWritable( relshipData ) ;
		super.writeSpecialInfo( out ) ;
	}
	
	/**
	 * Fill already instantiated object with values from SReadableReader
	 */
	public SSpecialReadable fillWithSReadables( Enumeration in )
		throws IOException, SkitIOException
	{
		relshipData = (SSequence)in.nextElement() ;
		return super.fillWithSReadables( in ) ;
	}
	

	
	public int hashCode()
	{
		return relshipData.hashCode() ;
	}
	
	public boolean equals( Object o )
	{
		return relshipData.equals( o ) ;
	}
	
}
