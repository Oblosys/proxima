package skit.data.value ;

import skit.lang.* ;
import java.io.* ;
import skit.* ;
import skit.util.* ;

/**
 * A SReadableReader reads a SValue, or datum.
 */
public interface SReadableReader extends IOBehavior
{
	/**
	 * Read a SValue.
	 */
	public SReadable readSReadable()
		throws SkitIOException, IOException ;
	
	/**
	 * Read a SValueable.
	 */
	//public SValueable readSValueable()
	//	throws SkitIOException, IOException ;
	
}
