package skit.data.value ;

import java.io.* ;
import java.util.* ;
import skit.* ;
import skit.data.* ;
import skit.data.value.* ;

/**
 *
 * @see skit.data.value.SWritableWriter
 * @see skit.data.value.SReadableReader
 */
public interface SReadWritable extends SWritable, SReadable
{
}