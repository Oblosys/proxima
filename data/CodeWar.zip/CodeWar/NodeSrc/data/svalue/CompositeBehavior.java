package skit.data.value ;

//import skit.value.* ;
import java.util.* ;

/**
 * Just behavior.
 * Composite.
 */
public interface CompositeBehavior
{
	/**
	 * @return true if empty.
	 */
	public boolean isEmpty() ;
	
	/**
	 * @return The number of elements in the Composite.
	 */
	public int getSize() ;
	
	/**
	 * Check if the value matches a type.
	 */
	//public boolean satisfies( Type tp ) ;
	
	/**
	 * Check if Composite can be updated.
	 */
	public boolean isUpdateable() ;
	
	/**
	 * Get the values of the composite.
	 */
	public Enumeration elements() ;
	
}