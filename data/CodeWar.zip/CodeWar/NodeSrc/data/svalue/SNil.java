package skit.data.value ;

import com.objectspace.jgl.* ;
//import skit.textio.* ;
import skit.* ;
import skit.data.* ;
import skit.data.content.* ;
//import skit.value.type.* ;
import java.util.* ;
import java.io.* ;

/**
 * Scheme language.
 * Null.
 */
public class SNil extends BasicSValue
	implements SSequence
{
	protected SNil()
	{
		//super( new NilDataContent() ) ;
	}
	
	public Enumeration elements()
	{	
		return new skit.util.EmptyEnumeration() ;
	}
	
	public int getSize()
	{
		return 0 ;
	}
	
	/**
	 * @return true if empty.
	 */
	public boolean isEmpty()
	{
		return true ;
	}
	
	/**
	 * Get a value of a sequence at a position.
	 * @param The position within the sequence.
	 * @return The value, or null if none.
	 */
	public SValue at( int pos )
	{
		return null ;
	}
	
	/**
	 * Check if composite can be updated.
	 */
	public boolean isUpdateable()
	{
		return true ;
	}
	
	/**
	 * Update value at a position with value from new one.
	 * Allowed only when updateable.
	 */
	public void updateAt( int pos, SValue v )
	{
		// ????
	}
	
	/**
	 * Remove value at a position.
	 * Allowed only when updateable.
	 * No effect for nil.
	 */
	public void removeAt( int pos )
	{
	}
	
	/**
	 * Remove value.
	 * Allowed only when updateable.
	 * No effect for nil.
	 */
	public void remove( SValue v )
	{
	}
	
	/**
	 * Calculate the intersection.
	 * The original value is left unchanged.
	 */
	public SSequence intersect( SSequence v )
	{
		return this ;
	}
	
	/**
	 * Append value at at end.
	 * Allowed only when updateable.
	 */
	public void updateAppend( SValue v )
	{
		// ???? oops, how to do this
	}
	
	public int hashCode()
	{
		return 0 ;
	}
	
	public boolean equals( Object o )
	{
		return o instanceof SNil ;
	}
	
	/**
	 * Write the info for the content on an appropriate writer.
	 */
	public void writeInfo( SWritableWriter out )
		throws SkitIOException, IOException
	{
		out.printNil() ;
	}

}