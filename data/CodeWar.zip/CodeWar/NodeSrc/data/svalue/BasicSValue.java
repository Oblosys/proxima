package skit.data.value ;

import skit.textio.* ;
import java.io.* ;
import java.util.* ;
//import skit.value.* ;
//import skit.value.type.* ;
import skit.* ;
import skit.util.* ;
import skit.data.* ;
import skit.data.node.* ;
import skit.data.relation.* ;
import skit.data.content.* ;

/**
 * Skit values.
 * Values.
 */
public abstract class BasicSValue extends ObjectFunctionality
	implements SValue
//, TextInputable, TextOutputable
{
	protected static final SNil nil = new SNil() ;
	protected static final SValue empty = nil ;
	protected static final SSymbol eof = SSymbol.newSpecialSymbol( "eof" ) ;
	
	private Object data = null ;
	
	public BasicSValue()
	{
		
	}
	
	protected BasicSValue( Object d )
	{
		setData( d ) ;
	}
	
	public BasicSValue( SValue otherV )
	{
		updateWith( otherV ) ;
	}
	
	/**
	 * Get the data.
	 */
	protected Object getData()
	{
		return data ;
	}
	
	/**
	 * Set the data.
	 */
	protected void setData( Object d )
	{
		data = d ;
	}
	
	/**
	 * Get the null value.
	 */
	public static SSymbol eof()
	{
		return eof ;
	}
	
	/**
	 * Get the null value.
	 */
	public static SNil nil()
	{
		return nil ;
	}
	
	/**
	 * Check if nil.
	 */
	public boolean equalsNil()
	{
		return nil == this ;
	}
	
	/**
	 * Get the empty value.
	 */
	public static SValue empty()
	{
		return empty ;
	}
	
	/**
	 * Check if empty.
	 */
	public boolean isEmpty()
	{
		return empty == this ;
	}
	
	/**
	 * Check if eof.
	 */
	public boolean equalsEof()
	{
		return eof == this ;
	}
	
	/**
	 * Make a new SValue by parsing/reading SReadableReader
	 */
	public static SReadable from( SReadableReader in )
		throws IOException, SkitIOException
	{
		return in.readSReadable() ;
	}
	
	/**
	 * Make a new SValue by parsing/reading a string.
	 */
	public static SReadable from( String str )
		throws IOException, SkitIOException
	{
		return from( new BasicSReadableReader( str ) ) ;
	}
	
	/**
	 * Make a new symbol of a string.
	 */
	public static SSymbol newSymbol( String str )
	{
		return SSymbol.newSymbol( str ) ;
	}
	
	/**
	 * Make a new symbol of a char.
	 */
	public static SSymbol newSymbol( char ch )
	{
		return newSymbol( String.valueOf( ch ) ) ;
	}
	
	/**
	 * Make a new pair of a head and a tail.
	 */
	public static SPair newPair( Pair p )
	{
		return new SPair( p ) ;
	}
	
	/**
	 * Make a new pair of a head and a tail.
	 */
	public static SPair newPair( SValue head, SValue tail )
	{
		return new SPair( head, tail ) ;
	}
	
	/**
	 * Make a new list with one element.
	 */
	public static SPair newList( SValue e1 )
	{
		return newPair( e1, empty() ) ;
	}
	
	/**
	 * Make a new list with 2 elements.
	 */
	public static SPair newList( SValue e1, SValue e2 )
	{
		return newPair( e1, newList( e2 ) ) ;
	}
	
	/**
	 * Make a new string of a string.
	 */
	public static SString newString( String str )
	{
		return new SString( str ) ;
	}
	
	/**
	 * Make a new bool.
	 */
	public static SBool newBool( boolean i )
	{
		return new SBool( i ) ;
	}
	
	/**
	 * Make a new int (long).
	 */
	public static SInt newInt( long i )
	{
		return new SInt( i ) ;
	}
	
	/**
	 * Make a new int (long).
	 */
	public static SInt newInt( Integer i )
	{
		return new SInt( i.intValue() ) ;
	}
	
	/**
	 * Make a new map from a SSequence of SPairs.
	 */
	public static SMap newMap( SSequence list )
	{
		return newMap( list.elements() ) ;
	}
	
	/**
	 * Make a new map from a Enumeration of SPairs.
	 */
	public static SMap newMap( Enumeration list )
	{
		return new SMap( list ) ;
	}
	
	/**
	 * Make a new map.
	 */
	public static SMap newMap()
	{
		return new SMap() ;
	}
	
	/**
	 * Make a new vector from a SSequence.
	 */
	public static SVector newVector( SSequence list )
	{
		return newVector( list.elements() ) ;
	}
	
	/**
	 * Make a new vector from a Enumeration.
	 */
	public static SVector newVector( Enumeration list )
	{
		return new SVector( list ) ;
	}
	
	/**
	 * Make a new vector.
	 */
	public static SVector newVector()
	{
		return new SVector() ;
	}
	
	/**
	 * Make a new vector.
	 */
	public static SVector newVector( int size )
	{
		return new SVector( size ) ;
	}
	
	/**
	 * Make a new vector.
	 */
	public static SVector newVector( int size, SValue defValue )
	{
		return new SVector( size, defValue ) ;
	}
	
	/**
	 * Make a new vector with 1 element.
	 */
	public static SVector newVector( SValue e1 )
	{
		SVector vec = newVector() ;
		vec.updateAppend( e1 ) ;
		return vec ;
	}
	
	/**
	 * Make a new vector with 2 elements.
	 */
	public static SVector newVector( SValue e1, SValue e2 )
	{
		SVector vec = newVector( e1 ) ;
		vec.updateAppend( e2 ) ;
		return vec ;
	}
	
	/**
	 * Make a new node.
	 */
	/*
	public static SNode newNode()
	{
		SNode node = new SNode( ) ;
		return node ;
	}
	*/
	
	/**
	 * Make a new stored node on a store.
	 */
	public static SNode newStoredNode( String storeName )
	{
		SNode node = new StorableSNode( storeName ) ;
		return node ;
	}
	
	/**
	 * Make a new stored node on the current/default store.
	 */
	public static SNode newStoredNode( )
	{
		SNode node = newStoredNode( skit.Globals.getStorage().getCurrentStoreName() ) ;
		return node ;
	}
	
	/**
	 * Make a new stored realtion on a store.
	 */
	public static StorableRelation newStoredRelation( RelationMetaInfo inf, String storeName )
	{
		StorableRelation rel = new StorableSRelation( inf, storeName ) ;
		return rel ;
	}
	
	/**
	 * Make a new SValue by reading from input.
	 */
	/*
	public static SValue read( TextInput inp )
	{
		return nil() ;
	}
	*/
	
	/**
	 * Print enumeration of SValue's on output with indent.
	 * @see	print
	 */
	/*
	public static void printEnumerationAsList( Enumeration vals, SWritableWriter out )
		throws SkitIOException, IOException
	{
		out.print( '(' ) ;
		if ( vals.hasMoreElements() )
		{
			out.writeSWritable( (SValue)vals.nextElement() ) ;
			//((SValue)vals.nextElement()).print( out ) ;
		}
		for ( ; vals.hasMoreElements() ; )
		{
			out.print( ' ' ) ;
			out.writeSWritable( (SValue)vals.nextElement() ) ;
			//((SValue)vals.nextElement()).print( out ) ;
		}
		out.print( ')' ) ;
	}
	*/
	
	/**
	 * Write the info for the content on an appropriate writer.
	 */
	public void writeInfo( SWritableWriter out )
		throws SkitIOException, IOException
	{
		//getContent().writeInfo( out, this ) ;
	}

	/**
	 * @see skit.value.Value
	 */
	public boolean satisfies( Type tp )
	{
		return tp.satisfies( this ) ;
	}
	
	/**
	 * Update with content of another SValue.
	 * Uses updateFieldsWith to do the actual work.
	 * @see updateFieldsWith
	 */
	public void updateWith( SValue otherV )
	{
		//setContentData( otherV.getContentData() ) ;
	}
	
	/**
	 * @see skit.value.SingleValue
	 */
	public Object typeCheckableContent()
		throws SkitIOException
	{
		return null ; //getContentData() ;
	}
	
	/**
	 * Get a copy, but only the top level of an object structure.
	 */
	/*
	public SValue shallowCopy()
		throws SkitException
	{
		try
		{
			BasicSValue newV = (BasicSValue)clone() ;
			newV.postShallowCopy() ;
			return newV ;
		}
		catch ( CloneNotSupportedException e )
		{
			skit.log.Logger.log( "error in shallow copy SValue", e ) ;
			throw new SkitException( "failed to shallow copy SValue" ) ;
		}
	}
	*/

	/**
	 * Get a copy.
	 */
	/*
	public SValue copy()
		throws SkitException
	{
		try
		{
			BasicSValue newV = (BasicSValue)clone() ;
			newV.postCopy() ;
			return newV ;
		}
		catch ( CloneNotSupportedException e )
		{
			skit.log.Logger.log( "error in copy SValue", e ) ;
			throw new SkitException( "failed to copy SValue" ) ;
		}
	}
	*/

	/**
	 * Do extra work after cloning.
	 * Meant to be overridden.
	 * Make sure super.postCopy() is invoked first.
	 */
	/*
	protected void postCopy()
		throws SkitException
	{
		postShallowCopy() ;
	}
	*/
	
	/**
	 * Do extra work after cloning.
	 * Meant to be overridden.
	 * Make sure super.postCopy() is invoked first.
	 */
	/*
	protected void postShallowCopy()
		throws SkitException
	{
		//content = content.copy() ;
	}
	*/
	
	/**
	 * Test on equality.
	 */
	public boolean equals( Object o )
	{
		return getClass().isInstance( o ) && equalsRest( (BasicSValue)o ) ;
	}

	/**
	 * Print on output with indent.
	 * @param	inputable	Write in such a way that it can be read via SReadableReader
	 */
	//public abstract void print( SWritableWriter out )
	//	throws SkitIOException, IOException ;

	
	/**
	 * Make a nice string representation.
	 * Append it on the StringBuffer
	 */
	public void appendStringRepr( StringBuffer buf )
	{
		appendStringRepr( buf, this ) ;
	}

	public static void appendStringRepr( StringBuffer buf, SValue val )
	{
		StringWriter sw = new StringWriter( ) ;
		try
		{
			BasicSWritableWriter bsw = new BasicSWritableWriter( sw, true, "" ) ;
			bsw.writeSWritable( val ) ;
			bsw.close() ;
			buf.append( sw.toString() ) ;
		}
		catch( Exception e )
		{
			skit.log.Logger.log( "error in svalue toString()", e ) ;
			buf.append( "error:" ) ;
			buf.append( e.toString() ) ;
		}
	}
	
	public static String toString( SValue val )
	{
		return PrintableFunctionality.toString( val ) ;
	}
	
	public String toString()
	{
		return toString( this ) ;
	}
	
	/**
	 * Meant to be overridden.
	 */
	/*
	public void toStringBuffer( StringBuffer buf )
	{
		StringWriter sw = new StringWriter( ) ;
		try
		{
			BasicSWritableWriter bsw = new BasicSWritableWriter( sw, true, "" ) ;
			bsw.writeSWritable( this ) ;
			bsw.close() ;
			buf.append( sw.toString() ) ;
		}
		catch( Exception e )
		{
			skit.log.Logger.log( "error in svalue toString()", e ) ;
			buf.append( "error:" ) ;
			buf.append( e.toString() ) ;
		}
	}
	*/
	
	protected boolean equalsRest( BasicSValue o )
	{
		//System.out.println( "EQ REST " + this + " <-> " + o ) ;
		boolean res = data.equals( o.data ) ;
		//System.out.println( "EQ REST " + this + " <-> " + o ) ;
		return res ;
		//return content.equals( ((BasicSValue)o).getContent() ) ;
//		return getClass().isInstance( o ) && equalsSValue( (SValue)o ) ;
	}
	
	//protected abstract boolean equalsSValue( SValue o ) ;
	
	public int hashCode()
	{
		return data.hashCode() ;
	}

}