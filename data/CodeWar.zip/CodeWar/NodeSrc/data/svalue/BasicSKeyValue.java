package skit.data.value ;

import java.io.* ;
import java.util.* ;
import skit.* ;
import skit.data.content.* ;
//import skit.util.* ;
//import skit.* ;
//import skit.data.* ;
//import com.objectspace.jgl.*;
//import java.io.* ;

/**
 * Skit value.
 * key/value pairs base class.
 */
public abstract class BasicSKeyValue extends BasicSValue
	implements SKeyValue
{
	public BasicSKeyValue()
	{
	}
	
	public BasicSKeyValue( Object o )
	{
		super( o ) ;
	}
	
	/**
	 * @return true if empty.
	 */
	public boolean isEmpty()
	{
		return getSize() == 0 ;
	}
	
	/**
	 * Get a value at a key.
	 */
	public SValue at( String key )
	{
		return at( BasicSValue.newString( key ) ) ;
	}
	
	/**
	 * Update value at a key with value from new one.
	 * Allowed only when updateable.
	 */
	public void updateAt( String key, SValue v )
	{
		updateAt( BasicSValue.newString( key ), v ) ;
	}
	
	/**
	 * Remove value at a key.
	 * Allowed only when updateable.
	 */
	public void removeAt( String key )
	{
		removeAt( BasicSValue.newString( key ) ) ;
	}
	
	/**
	 * Check for existence of key.
	 */
	public boolean hasAt( String key )
	{
		return hasAt( BasicSValue.newString( key ) ) ;
	}
	
	/**
	 * Update with values from other one.
	 */
	public void updateWith( SKeyValue other )
	{
		SKeyValueFunctionality.updateWith( this, other ) ;
	}
		
	/**
	 * @see skit.data.value.SValue#postCopy()
	 *
	/*
	protected void postCopy()
		throws SkitException
	{
		super.postCopy() ;
		setData( getData().clone() ) ;
	}
	*/

	/**
	 * Write the info for the content on an appropriate writer.
	 */
	public void writeInfo( SWritableWriter out )
		throws SkitIOException, IOException
	{
		out.writeSSpecialWritable( this, null ) ;
	}

}


