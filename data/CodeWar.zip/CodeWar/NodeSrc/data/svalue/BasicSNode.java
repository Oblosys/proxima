package skit.data.value ;

//import skit.textio.* ;
//import skit.value.* ;
//import skit.value.type.* ;
import java.util.* ;
import skit.util.* ;
import skit.id.* ;
import skit.* ;
import skit.data.* ;
import skit.data.content.* ;
import skit.data.node.* ;
import skit.data.store.* ;
//import com.objectspace.jgl.*;
import java.io.* ;

/**
 * Skit value.
 * Nodes.
 * 
 * @see skit.data.value.SStorable
 */
public class BasicSNode extends Storable
	implements SNode
{
	public BasicSNode()
	{
		//this( "stored" ) ;
	}
	
	/*
	private static UniqueId makeNodeId( String nodeKind )
	{
		Node n = null ;
		UniqueId id = null ;
		try
		{
					// ????: "node/" as global var, see Setup, ....
			n = (Node)skit.Globals.getSReadWritableFactory().makeIt( "node/" + nodeKind ) ;
			id = n.getEnsureId( skit.Globals.getStorage().getCurrentStoreName() ) ;
		}
		catch( SkitException ex )
		{
			skit.log.Logger.fatal( "failure in creation of node " + nodeKind, ex ) ;
		}
		return id ;
	}
	*/
	
	public BasicSNode( Node node )
	{ 
		super( node ) ;
	}
	
	public BasicSNode( String nodeKind )
	{ 
		this( (Node)SStorable.newStorable( "node/" + nodeKind ) ) ;
	}
	
	public BasicSNode( String nodeKind, String storeName )
	{ 
		this( (Node)SStorable.newStorable( "node/" + nodeKind, storeName ) ) ;
	}
	
	public BasicSNode( UniqueId id )
	{ 
		super( SStorable.newStorable( id ) ) ;
	}
	
	private Node nodeValue()
	{
		return ((Node)getData()) ;
	}
	
	/*
	public void refillWith( Enumeration elts )
	{
		fillWith( elts, true ) ;
	}
	
	public void fillWith( Enumeration elts )
	{
		fillWith( elts, false ) ;
	}
	
	private void fillWith( Enumeration elts, boolean doClear )
	{
		Node values = nodeValue() ;
		//if ( doClear ) // ????
		//	values.clear() ;
		for ( ; elts.hasMoreElements() ; )
		{
			Object o = elts.nextElement() ;
			if ( o instanceof SSequence )
			{
				SSequence s = (SSequence)o ;
				values.put( s.at( 0 ), s.at( 1 ) ) ;
			}
		}
		setContentData( values ) ;
	}
	*/
	
	/**
	 * Get all the values.
	 */
	public Enumeration elements()
	{
		return 
			( new EnumerationTransformer
					( keys()
					, new NodeAttrTransformer( nodeValue() )
					)
			) ;
	}
	
	/**
	 * Get all the keys and values in sequences.
	 */
	public Enumeration keysAndValues()
	{
		return 
			( new EnumerationTransformer
					( keys()
					, new NodePairTransformer( nodeValue() )
					)
			) ;
	}
	
	/**
	 * Get all the keys.
	 */
	public Enumeration keys()
	{
		try
		{
			return nodeValue().keys() ;
		}
		catch ( SkitIOException ex )
		{
			return new EmptyEnumeration() ;
		}
	}
	
	/**
	 * Get the size.
	 */
	public int getSize()
	{
		try
		{
			return nodeValue().getSize() ;
		}
		catch ( SkitIOException ex )
		{
			skit.log.Logger.warn( "error in getting node size", ex ) ;
			return 0 ;
		}
	}
	
	/**
	 * Get a value of map at a key.
	 */
	public SValue at( SValue key )
	{
		try
		{
			return (SValue)nodeValue().getAttr( (SString)key ) ;
		}
		catch ( Exception ex )
		{
			skit.log.Logger.warn( "error in getting node attr " + key, ex ) ;
			return BasicSValue.nil() ;
		}	
	}
	
	/**
	 * Check if composite can be updated.
	 */
	public boolean isUpdateable()
	{
		return nodeValue().isUpdateable() ;
	}
	
	/**
	 * Update value at a key with value from new one.
	 * Allowed only when updateable.
	 */
	public void updateAt( SValue key, SValue v )
	{
		//System.out.println( "SNODE UPD AT " + key + "/" + v ) ;
		try
		{
			nodeValue().setAttr( (SString)key, v ) ;
		}
		catch ( Exception ex )
		{
			skit.log.Logger.warn( "error in setting node attr " + key, ex ) ;
		}	
	}
	
	/**
	 * Remove value at a key.
	 * Allowed only when updateable.
	 */
	public void removeAt( SValue key )
	{
		//System.out.println( "SNODE REM AT " + key ) ;
		try
		{
			nodeValue().removeAttr( (SString)key ) ;
		}
		catch ( Exception ex )
		{
			skit.log.Logger.warn( "error in removing node attr " + key, ex ) ;
		}	
	}
	
	/**
	 * Fill already instantiated object with values from SReadableReader
	 */
	public void fillWithSReadables( Enumeration in )
		throws IOException, SkitIOException
	{
		if ( ! in.hasMoreElements() )
			throw new SkitIOException( "expected id for SNode" ) ;
		
		setData( SStorable.newStorable( (UniqueId)in.nextElement() ) ) ;
		//super.fillWithSReadables( in ) ;
	}
	
	/**
	 * Write the info for the content on an appropriate writer.
	 */
	public void writeSpecialInfo( SWritableWriter out )
		throws SkitIOException, IOException
	{
		out.writeSWritable( nodeValue().getId() ) ;
		//super.writeSpecialInfo( out ) ;
	}

	
}


