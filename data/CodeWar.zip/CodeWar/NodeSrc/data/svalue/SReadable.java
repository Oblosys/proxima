package skit.data.value ;

import skit.* ;
import java.io.* ;

/**
 * Something which can be read as a SValue (and later be written as such),
 * using SReadableReader.
 * @see skit.data.value.SReadableReader
 */
public interface SReadable
{
	/**
	 * Read the info for the content from an appropriate reader.
	 */
	//public void fillContent( SReadableReader in )
	//	throws SkitIOException, IOException ;

}