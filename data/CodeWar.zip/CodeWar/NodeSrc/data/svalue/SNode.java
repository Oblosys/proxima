package skit.data.value ;

//import skit.textio.* ;
//import skit.value.* ;
//import skit.value.type.* ;
//import java.util.* ;
import skit.util.* ;
//import skit.id.* ;
import skit.* ;
import skit.data.* ;
//import skit.data.content.* ;
//import skit.data.node.* ;
import skit.data.store.* ;
//import com.objectspace.jgl.*;
import java.io.* ;
import java.util.* ;

/**
 * Skit value.
 * Nodes. The extra methods provide some extra functionality for checking and w.r.t.
 * handling of exceptions.
 * 
 * @see skit.data.value.Storable
 */
public interface SNode extends SKeyValue, Storable
{
	/**
	 * Check if attribute with given name exist.
	 *
	 * @param	key	The name of the attribute.
	 * @return 	true if the value exists.
	 */
	public boolean hasAttr( SString key )
		throws SkitIOException ;
	
	/**
	 * Get the value of an attribute.
	 *
	 * @param	key	The name of the attribute.
	 * @return The value, or null if none exists.
	 */
	public SValue getAttr( SString key )
		throws SkitIOException ;
	
	/**
	 * Remove an attribute.
	 *
	 * @param	key	The name of the attribute.
	 */
	public void removeAttr( SString key )
		throws SkitIOException ;
	
	/**
	 * Set the value of an attribute.
	 * 
	 * @param	key	The name of the attribute.
	 * @param	val	The value of the attribute.
	 */
	public void setAttr( SString key, SValue val )
		throws SkitIOException ;
	
	/**
	 * Get all the names of the attributes
	 * Pass an exception if it occurs.
	 */
	public Enumeration keysUncaught()
		throws SkitIOException ;
	
	/**
	 * Get the size.
	 * Don't handle possible exceptions.
	 */
	public int getSizeUncaught()
		throws SkitIOException ;
	
}


