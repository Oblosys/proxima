package skit.data.value ;

import skit.textio.* ;
import java.io.* ;
import java.util.* ;
//import skit.value.* ;
//import skit.value.type.* ;
import skit.* ;
import skit.data.* ;
import skit.data.content.* ;

/**
 * Skit values.
 * Values with a content which can be changed.
 */
public abstract class SContentValue extends BasicSValue
//	implements Serializable, SReadWritable, Cloneable
//, TextInputable, TextOutputable
{
	//protected Content content ;
	
	public SContentValue()
	{
		
	}
	
	protected SContentValue( Content c )
	{
		super( c ) ;
	}
	
	public SContentValue( SValue otherV )
	{
		super( otherV ) ;
	}
	
	/**
	 * Get the content.
	 */
	public Content getContent()
	{
		return (Content)getData() ;
	}
	
	/**
	 * Set the content.
	 */
	public void setContent( Content o )
	{
		setData( o ) ;
	}
	
	/**
	 * Get the data of the Content.
	 */
	public Object getContentData()
	{
		try
		{
			return getContent().get() ;
		}
		catch ( Exception ex )
		{
			skit.log.Logger.log( "error in getting sval content", ex ) ;
			return null ;
		}
	}
	
	/**
	 * Set the data of the Content.
	 */
	protected void setContentData( Object o )
	{
		try
		{
			getContent().set( o ) ;
		}
		catch ( Exception ex )
		{
			skit.log.Logger.log( "error in setting sval content", ex ) ;
		}
	}
	
	/**
	 * Replace the content holder, copy the value.
	 */
	public void switchContent( Content newContent )
	{
		try
		{
			newContent.set( getContent().get( ) ) ;
			setContent( newContent ) ;
		}
		catch ( Exception ex )
		{
			skit.log.Logger.log( "error in switching sval content", ex ) ;
		}		
	}
	
	/**
	 * Write the info for the content on an appropriate writer.
	 */
	public void writeInfo( SWritableWriter out )
		throws SkitIOException, IOException
	{
		getContent().writeInfo( out, this ) ;
	}

	/**
	 * Update with content of another SValue.
	 * Uses updateFieldsWith to do the actual work.
	 * @see updateFieldsWith
	 */
	public void updateWith( SContentValue otherV )
	{
		setContentData( otherV.getContentData() ) ;
	}
	
	/**
	 * @see skit.value.SingleValue
	 */
	public Object typeCheckableContent()
		throws SkitIOException
	{
		return getContentData() ;
	}
	
	/**
	 * Do extra work after cloning.
	 * Meant to be overridden.
	 * Make sure super.postCopy() is invoked first.
	 */
	public void postCopy()
		throws SkitException
	{
		setContent( (Content)getContent().copy() ) ;
	}
	
	/**
	 * @see skit.ObjectFunctionality.
	 */
	protected void postShallowCopy()
		throws SkitException
	{
		super.postShallowCopy() ;
		setContent( (Content)getContent().shallowCopy() ) ;
	}
	
	/*
	protected boolean equalsRest( SValue o )
	{
		return content.equals( ((SContentValue)o).getContent() ) ;
//		return getClass().isInstance( o ) && equalsSValue( (SValue)o ) ;
	}
	*/
	
	//protected abstract boolean equalsSValue( SValue o ) ;
	
	/*
	public int hashCode()
	{
		return content.hashCode() ;
	}
	*/

}