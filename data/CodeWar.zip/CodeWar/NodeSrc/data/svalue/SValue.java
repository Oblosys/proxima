package skit.data.value ;

import skit.util.* ;
import java.io.* ;
import java.util.* ;
//import skit.value.* ;
//import skit.value.type.* ;
import skit.* ;
import skit.data.* ;
import skit.data.content.* ;

/**
 * Skit values.
 * Values.
 */
public interface SValue extends Serializable, SReadWritable, Cloneable, Printable, ObjectBehavior
//, TextInputable, TextOutputable
{
	/**
	 * Check if nil.
	 */
	public boolean equalsNil() ;
	
	/**
	 * Check if empty.
	 */
	//public boolean isEmpty() ;
	
	/**
	 * Check if eof.
	 */
	public boolean equalsEof() ;
	
	/**
	 * @see skit.value.Value
	 */
	public boolean satisfies( Type tp ) ;
	
	/**
	 * Update with content of another SValue.
	 * Uses updateFieldsWith to do the actual work.
	 * @see updateFieldsWith
	 */
	public void updateWith( SValue otherV ) ;
	
	/**
	 * @see skit.value.SingleValue
	 */
	//public Object typeCheckableContent()
	//	throws SkitIOException ;
	
	/**
	 * Get a copy.
	 */
	//public SValue copy()
	//	throws SkitException ;

	/**
	 * Test on equality.
	 */
	public boolean equals( Object o ) ;
	

}