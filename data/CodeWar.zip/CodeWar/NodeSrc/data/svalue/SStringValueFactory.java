package skit.data.value ;

import skit.factory.* ;
import skit.data.store.* ;
import java.io.* ;

public class SStringValueFactory extends SValueFactory
{
	private final static String impl = "string" ;
	private final static String paramDescr = "the string" ;
	
	public SStringValueFactory()
	{
	}
	
	/**
	 * @see skit.factory.Factory
	 */
	public String getImplementationName()
	{
		return impl ;
	}
	
	/**
	 * @see skit.factory.Factory
	 */
	public String getParamDescr()
	{
		return paramDescr ;
	}
	
	/**
	 * @see skit.factory.Factory
	 */
	public Object makeIt( Object param )
		throws skit.SkitException
	{
		return BasicSValue.newString( (String)param ) ;
	}
	
}