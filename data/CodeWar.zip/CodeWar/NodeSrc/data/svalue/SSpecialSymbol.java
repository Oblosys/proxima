package skit.lang.scheme ;

/**
 * Scheme language.
 * Special symbol.
 */
public class SSpecialSymbol extends SSymbol
{
	public static final String SPECIAL_PREFIX = "#!" ;
	
	private SSpecialSymbol( String str )
	{
		super( SPECIAL_PREFIX + str ) ;
	}
	
	/**
	 * Make a new symbol of a string.
	 */
	public static SSpecialSymbol newSpecialSymbol( String str )
	{
		return super.newSymbol( SPECIAL_PREFIX + str ) ;
	}

}