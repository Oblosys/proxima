package skit.data.value ;

import skit.lang.* ;
import skit.data.* ;
import skit.data.value.* ;
import skit.data.content.* ;
import java.io.* ;
import java.util.* ;
import skit.* ;

/**
 * A BasicSReadableReader reads a SValue, or datum.
 * @see skit.data.value.SReadableReader
 * @see skit.data.value.SValueable
 */
public class BasicSReadableReader implements SReadableReader
{
	private TokenReader tokens ;
	protected Token token ;
	
	private static TokenReaderInfo tokenInfo ;
	
	static
	{
		TokenPredicate nrPrefixPred = new NrPrefixPredicate() ;
		TokenPredicate nrFirstPred = new NrFirstPredicate() ;
		TokenPredicate idSinglePred = new IdSinglePredicate() ;
		TokenPredicate idFirstPred = new IdFirstPredicate() ;
		TokenPredicate idRestPred = new TokenOrPredicate( nrFirstPred, new IdSpecialPredicate() ) ;
		TokenPredicate idPred = new TokenOrPredicate( idFirstPred, idRestPred ) ;
		tokenInfo = 
			new TokenReaderInfo
				( " \t\r\n" 	// whitespace
				, '\n'			// line separator
				, idSinglePred	// single char tokens
				//, "()'`,@.#+-"	// single char tokens
				, '"'			// string quote
				, '\\'			// string escape
				, ';'			// comment start
				, '\n'			// comment 
				, idFirstPred
				, idPred
				, nrPrefixPred
				, nrFirstPred
				, nrFirstPred
				) ;
	}
	
	public BasicSReadableReader( Reader in )
	{
		tokens = new TokenReader( in, tokenInfo ) ;
		try
		{
			stepToken() ;
		}
		catch ( IOException e )
		{
			skit.log.Logger.log( "error in SValue reader", e ) ;
		}
	}
	
	public BasicSReadableReader( String inStr )
	{
		this ( new StringReader( inStr ) ) ;
	}
	
	private Token stepToken()
		throws IOException
	{
		token = tokens.stepToken() ;
		//System.out.println( "RD STEP " + token ) ;
		return token ;
	}
	
	private void error( String msg )
		throws SkitIOException
	{
		throw new SkitIOException( "scheme parse error at " + tokens + ": " + msg ) ;
	}
	
	private SValue readSValueList( boolean allowDot )
		throws SkitIOException, IOException
	{
		if ( token.equals( ')' ) )
			return BasicSValue.empty() ;
		
		SPair res = BasicSValue.newPair( BasicSValue.empty(), BasicSValue.empty() ) ;
		SPair cur = res ;
		for ( ; true ; )
		{
			cur.setHead( (SValue)readSReadable() ) ;
			if ( allowDot && token.equals( '.' ) )
			{
				stepToken() ;
				cur.setTail( (SValue)readSReadable() ) ;
				break ;
			}
			else if ( token.equals( ')' ) )
			{
				break ;
			}
			SPair newCur = BasicSValue.newPair( BasicSValue.empty(), BasicSValue.empty() ) ;
			cur.setTail( newCur ) ;
			cur = newCur ;
		}
		return res ;
	}
	
	private SValue readSValueVector()
		throws SkitIOException, IOException
	{
		SVector v = BasicSValue.newVector( svalueListLister() ) ;
		return v ;
	}
	
	private SReadable readSSpecialReadable( String whichSValue, String whichContent )
		throws SkitIOException, IOException
	{
		SReadable res ;
		//System.out.println( "READ special: " + whichSValue + "/" + whichContent ) ;
		try
		{
			Class svalCl = null ;
			Class contCl = null ;
			SSpecialReadable cont = null ;
			if ( whichSValue != null )
				svalCl = (Class)skit.Globals.getSValueMimeRegistry().resolve( whichSValue ) ;
			if ( whichContent != null )
				cont = (SSpecialReadable)skit.Globals.getSReadWritableFactory().makeIt( whichContent ) ;

			if ( cont == null )
				throw new SkitIOException( "missing content mime type while reading" ) ;
			
			//cont = fill( cont, svalueListLister() ) ;
			cont = cont.fillWithSReadables( svalueListLister() ) ;
			
			if ( svalCl == null )
			{
				res = cont ;
			}
			else
			{
				SContentValue sval = (SContentValue)svalCl.newInstance() ;
				sval.setContent( (Content)cont ) ;
				res = sval ;
			}
				
			//System.out.println( "READ special class: " + res.getClass() ) ;
			return res ;
		}
		catch( Exception ex )
		{
			skit.log.Logger.log( "error in readSSpecialReadable", ex ) ;
			throw new SkitIOException( "failure in special sreadable read: " + ex.toString() ) ;
		}
	}
	
	/**
	 * Meant to be overridden.
	 */
	/*
	protected SSpecialReadable fill( SSpecialReadable what, Enumeration in )
		throws SkitIOException, IOException
	{
		return what.fillWithSReadables( in ) ;
	}
	*/
	
	private Enumeration svalueListLister( )
	{
		return new ListReader( this ) ;
	}
	
	public SReadable readSReadable()
		throws SkitIOException, IOException
	{
		SReadable res = null ;
		boolean doStepToken = true ;
		
		if ( token.isId() )
		{
			if ( token.equals( '(' ) )
			{
				stepToken() ;
				res = readSValueList( false ) ;
				if ( ! ( token.equals( ')' ) ) )
					error( "expected ')'" ) ;
			}
			else if ( token.equals( '#' ) )
			{
				stepToken() ;
				if ( token.equals( '(' ) )
				{
					stepToken() ;
					res = readSValueVector() ;
					//doStepToken = false ;
				}
				else if ( token.equals( 't' ) || token.equals( 'f' ) )
				{
					res = BasicSValue.newBool( token.equals( 't' ) ) ;
				}
				/*
				else if ( token.equals( '#' ) )
				{
					stepToken() ;
					if ( token.equals( '(' ) )
					{
						res = BasicSValue.newMap( (SSequence)readSReadable() ) ;
						doStepToken = false ;
					}
					else
						error( "expected '(', '#' or t/f" ) ;
				}
				*/
				else
				{
					String whichSValue = null ;
					String whichContent = null ;
					if ( ! token.equals( '#' ) )
					{
						whichSValue = token.strValue() ;
						stepToken() ;
					}
					if ( ! token.equals( '#' ) )
						error( "expected '#'" ) ;

					stepToken() ;
					
					if ( ! token.equals( '(' ) )
					{
						whichContent = token.strValue() ;
						stepToken() ;
					}
					
					if ( token.equals( '(' ) )
					{
						stepToken() ;
						res = readSSpecialReadable( whichSValue, whichContent ) ; 
						if ( ! ( token.equals( ')' ) ) )
							error( "expected ')'" ) ;
					}
					else
						error( "expected '(', '#' or t/f" ) ;
				}
			}
			else if ( token.equals( '\'' ) )
			{
				stepToken() ;
				if ( ! token.equalsEof() )
				{
					res = BasicSValue.newList( SSymbol.quote, (SValue)readSReadable() ) ;
					doStepToken = false ;
				}
				else
					error( "unexpected eof" ) ;
			}
			else
			{
				res = BasicSValue.newSymbol( token.strValue() ) ;
			}
		}
		else if ( token.isStr() )
		{
			res = BasicSValue.newString( token.strValue() ) ;
		}
		else if ( token.isNum() )
		{
			res = BasicSValue.newInt( token.longValue() ) ;
		}
		else if ( token.equalsEof() )
		{
			res = BasicSValue.eof() ;
		}
		else
		{
			error( "unexpected token" ) ;
		}
		if ( doStepToken )
			stepToken() ;
		return res ;
	}
	
	/*
	protected SValue readSValueable( String key )
		throws SkitIOException, IOException
	{
		try
		{
			SString type = (SString)readSReadable() ;
			Class svalCl = (Class)skit.Globals.getSValueableRegistry().resolve( type.strValue() ) ;
			SValueable sval = (SValueable)svalCl.newInstance() ;
			sval.fillWithSReadables( svalueListLister() ) ;
			//return new SAny( sval ) ;
			return null ;
		}
		catch( Exception ex )
		{
			skit.log.Logger.log( "error in readSValueable", ex ) ;
			throw new SkitIOException( "failure in svaluable read: " + ex.toString() ) ;
		}
	}
	*/
	
	/**
	 * Flush data, but do not close.
	 */
	public void flush()
		throws IOException, SkitIOException
	{
	}
	
	/**
	 * Flush data and close.
	 */
	public void close()
		throws IOException, SkitIOException
	{
		tokens.close() ;
	}
	
	public void test()
		throws IOException
	{
		for ( ; ! token.equalsEof() ; stepToken() )
		{
			System.out.println( tokens + " // " + token ) ;
		}
	}
	
}

class IdFirstPredicate implements TokenPredicate
{
	public IdFirstPredicate()
	{
	}
	
	/**
	 * Check if a character satisfies a predicate
	 */
	public boolean satisfies( int ch )
	{
		char c = (char)ch ;
		return 
//				Character.isLetter( c )
				( ( c >= 'a' ) && ( c <= 'z' ) )
			||	( ( c >= 'A' ) && ( c <= 'Z' ) )
			||	"!$%&*/:<=>?~_^".indexOf( c ) >= 0
			;
	}
	
}

class IdSpecialPredicate implements TokenPredicate
{
	public IdSpecialPredicate()
	{
	}
	
	/**
	 * Check if a character satisfies a predicate
	 */
	public boolean satisfies( int ch )
	{
		char c = (char)ch ;
		return 
				"+-.".indexOf( c ) >= 0
			;
	}
	
}

class IdSinglePredicate implements TokenPredicate
{
	public IdSinglePredicate()
	{
	}
	
	/**
	 * Check if a character satisfies a predicate
	 */
	public boolean satisfies( int ch )
	{
		char c = (char)ch ;
		return 
				"()'`,@.#+-".indexOf( c ) >= 0
			;
	}
	
}

class NrFirstPredicate implements TokenPredicate
{
	public NrFirstPredicate()
	{
	}
	
	/**
	 * Check if a character satisfies a predicate
	 */
	public boolean satisfies( int ch )
	{
		char c = (char)ch ;
		return 
			//	Character.isDigit( c )
				"0123456789".indexOf( c ) >= 0
			;
	}
	
}

class NrPrefixPredicate implements TokenPredicate
{
	public NrPrefixPredicate()
	{
	}
	
	/**
	 * Check if a character satisfies a predicate
	 */
	public boolean satisfies( int ch )
	{
		char c = (char)ch ;
		return c == '-' ;
			//	Character.isDigit( c )
			//	"0123456789".indexOf( c ) >= 0
			;
	}
	
}

class ListReader implements Enumeration
{
	private BasicSReadableReader reader ;
	private boolean error ;
	
	public ListReader( BasicSReadableReader r )
	{
		reader = r ;
		error = false ;
		findNext() ;
	}
	
	private void findNext()
	{
	}
	
	public boolean hasMoreElements()
	{
		return ! ( reader.token.equals( ')' ) || error ) ;
	}
	
	public Object nextElement()
	{
		Object res = null ;
		try
		{
			res = reader.readSReadable() ;
		}
		catch ( Exception ex )
		{
			error = true ;
			skit.log.Logger.warn( "error in reading list as enum", ex ) ;
		}
		return res ;
	}
}

