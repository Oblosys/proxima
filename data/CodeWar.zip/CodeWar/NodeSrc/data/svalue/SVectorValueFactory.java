package skit.data.value ;

import skit.factory.* ;
import skit.data.store.* ;
import java.io.* ;

public class SVectorValueFactory extends SValueFactory
{
	private final static String impl = "vector" ;
	private final static String paramDescr = "the string describing the vector" ;
	
	public SVectorValueFactory()
	{
	}
	
	/**
	 * @see skit.factory.Factory
	 */
	public String getImplementationName()
	{
		return impl ;
	}
	
	/**
	 * @see skit.factory.Factory
	 */
	public String getParamDescr()
	{
		return paramDescr ;
	}
	
	/**
	 * @see skit.factory.Factory
	 */
	public Object makeIt( Object param )
		throws skit.SkitException
	{
		try
		{
			if ( param instanceof String )
			{
				SReadableReader reader = new BasicSReadableReader( (String)param ) ;
				return reader.readSReadable() ;
			}
			else
				return BasicSValue.newVector() ;
		}
		catch ( Exception e )
		{
			skit.log.Logger.log( "error in factory make", e ) ;
		}
		return null ;
	}
	
}