package skit.data.value ;

import skit.factory.* ;

public abstract class SValueFactory
	implements Factory
{
	private final static String categ = "svalue" ;
	
	/**
	 * @see skit.factory.Factory
	 */
	public String getCategoryName()
	{
		return categ ;
	}
	
}