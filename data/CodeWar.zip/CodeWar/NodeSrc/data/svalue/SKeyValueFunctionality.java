package skit.data.value ;

import java.util.* ;
import skit.data.* ;
import skit.util.* ;
//import skit.util.* ;
//import skit.* ;
//import skit.data.* ;
//import com.objectspace.jgl.*;
//import java.io.* ;

/**
 * Skit value.
 * key/value pair functionality.
 * Some actual work is delegated to this class.
 * Later.... ???? more
 */
public class SKeyValueFunctionality
{
	/**
	 * Update with values from other one.
	 */
	public static void updateWith( SKeyValue kv, SKeyValue other )
	{
		for ( Enumeration e = other.keysAndValues() ; e.hasMoreElements() ; )
		{
			SSequence kvp = (SSequence)e.nextElement() ;
			kv.updateAt( (SValue)kvp.at( 0 ), kvp.at( 1 ) ) ;
		}
	}

	/**
	 * Get all the keys and values in sequences.
	 */
	public static Enumeration keysAndValues( SKeyValue kv )
	{
		return 
			( new EnumerationTransformer
					( kv.keys()
					, new KeyVal2SeqTransformer( kv )
					)
			) ;
	}
	
	/**
	 * Get all the keys and values in sequences.
	 */
	public static Enumeration elements( SKeyValue kv )
	{
		return 
			( new EnumerationTransformer
					( kv.keys()
					, new Key2ValTransformer( kv )
					)
			) ;
	}
	

	public static void appendStringRepr( StringBuffer buf, SKeyValue kv )
	{
		for ( Enumeration e = kv.keysAndValues() ; e.hasMoreElements() ; )
		{
			SSequence kvp = (SSequence)e.nextElement() ;
			PrintableFunctionality.appendStringRepr( buf, kvp.at( 0 ), kvp.at( 1 ), PrintableFunctionality.BRACKET_KEYVAL ) ;
		}
	}
}


/**
 * @see skit.util.EnumerationTransformer
 */
class KeyVal2SeqTransformer implements Transformer
{
	SKeyValue map ;
	
	public KeyVal2SeqTransformer( SKeyValue m )
	{
		map = m ;
	}
	
	public Object transform( Object key )
	{
		SValue v = BasicSValue.newVector( (SValue)key , map.at( (SValue)key ) ) ;
		return v ;
	}
}

/**
 * @see skit.util.EnumerationTransformer
 */
class Key2ValTransformer implements Transformer
{
	SKeyValue map ;
	
	public Key2ValTransformer( SKeyValue m )
	{
		map = m ;
	}
	
	public Object transform( Object key )
	{
		SValue v = map.at( (SValue)key ) ;
		return v ;
	}
}
