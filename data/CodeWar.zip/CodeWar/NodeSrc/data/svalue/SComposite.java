package skit.data.value ;

//import skit.value.* ;
import java.util.* ;

/**
 * Skit value.
 * Composite.
 */
public interface SComposite extends SReadWritable, CompositeBehavior, SValue
{
}