package skit.data.node ;

public class NodeIOException extends skit.SkitException
{
	public NodeIOException( String msg )
	{
		super( msg ) ;
	}
}