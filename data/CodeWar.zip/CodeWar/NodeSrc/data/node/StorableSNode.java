package skit.data.node ;

import com.objectspace.jgl.* ;
import skit.data.store.* ;
//import skit.value.* ;
import skit.* ;
import skit.id.* ;
import skit.util.* ;
import skit.data.value.* ;
import java.io.* ;
import java.util.Enumeration ;

public class StorableSNode extends BasicStorable
	implements SNode//, Node
{
	private final static int MIN_NR_META = 1 ;
	private final static int MIN_NR_DATA = 0 ;
	
	private final static int META_MAP = 0 ;
	
	public StorableSNode()
	{
	}

	public StorableSNode( String storeName )
	{
		this( storeName, null ) ;
	}

	public StorableSNode( String storeName, UniqueId id )
	{
		super( storeName, id ) ;
		putMeta( META_MAP, new SMap() ) ;
	}

	/**
	 * Get the minimal number of meta parts.
	 */
	protected int minNrOfMetaParts()
	{
		return MIN_NR_META ;
	}
	
	/**
	 * Get the minimal number of meta parts.
	 */
	protected int minNrOfDataParts()
	{
		return MIN_NR_DATA ;
	}
	
	/**
	 * Get the size.
	 * Don't handle possible exceptions.
	 */
	public int getSizeUncaught()
		throws SkitIOException
	{
		SMap m = (SMap)getMeta( META_MAP ) ;
		return m.getSize() ;
	}
	
	/**
	 * Get the size.
	 */
	public int getSize()
	{
		try
		{
			return getSizeUncaught() ;
		}
		catch ( SkitIOException ex )
		{
			skit.log.Logger.warn( "error in getting node size", ex ) ;
			return 0 ;
		}
	}
	
	/**
	 * Remove the position info.
	 */
	private void removePosition( SString key )
	{
		SMap m = (SMap)getMeta( META_MAP ) ;
		m.removeAt( key ) ;
		putMeta( META_MAP, m ) ;
	}
	
	/**
	 * Get the position in the data part of the attribute, create if indicated
	 * an entry.
	 */
	private synchronized int getPosition( SString key, boolean doCreate )
	{
		SMap m = (SMap)getMeta( META_MAP ) ;
		Object posO = m.at( key ) ;
		int pos ;
		if ( posO == null )
		{
			if ( doCreate )
			{
				pos = allocDataSlot( BasicSValue.nil() ) ;
				m.updateAt( key, BasicSValue.newInt( pos ) ) ;
				putMeta( META_MAP, m ) ;
			}
			else
				pos = ILLEGAL_POS ;
		}
		else
			pos = ((SInt)posO).intValue() ;
		//System.out.println( "NODE GET POS " + key + "/" + pos + "/" + m ) ;
		return pos ;
	}
	
	/**
	 * Get the position in the data part of the attribute, create if indicated
	 * an entry.
	 */
	private synchronized int getPosition( String key, boolean doCreate )
	{
		return getPosition( BasicSValue.newString( key ), doCreate ) ;
	}
	
	/**
	 * Make data as used for change notification.
	 */
	private SequenceBehavior makeNotifyData( SString key, SValue val )
	{
		return BasicSValue.newVector( key, val ) ;
	}

	/**
	 * Check if attribute with given name exist.
	 *
	 * @param	key	The name of the attribute.
	 * @return 	true if the value exists.
	 */
	public boolean hasAttr( SString key )
		throws SkitIOException
	{
		int pos = getPosition( key, false ) ;
		return ( pos != ILLEGAL_POS ) ;
	}
	
	/**
	 * Get the value of an attribute.
	 *
	 * @param	key	The name of the attribute.
	 * @return The value, or null if none exists.
	 */
	public synchronized SValue getAttr( SString key )
		throws SkitIOException
	{
		int pos = getPosition( key, false ) ;
		//System.out.println( "get attr " + key + "/" + pos ) ;
		return ( pos == ILLEGAL_POS ) ? null : (SValue)getData( pos ) ;
	}
	
	/**
	 * Get a value of node at a key.
	 */
	public SValue at( SValue key )
	{
		try
		{
			return (SValue)getAttr( (SString)key ) ;
		}
		catch ( Exception ex )
		{
			skit.log.Logger.warn( "error in getting node attr " + key + ", substitute nil", ex ) ;
			return BasicSValue.nil() ;
		}	
	}
	
	/**
	 * Get a value at a key.
	 */
	public SValue at( String key )
	{
		return at( BasicSValue.newString( key ) ) ;
	}
	
	/**
	 * Set the value of an attribute.
	 * 
	 * @param	key	The name of the attribute.
	 * @param	val	The value of the attribute.
	 */
	public synchronized void setAttr( SString key, SValue val )
		throws SkitIOException
	{
		//System.out.println( "NODE SET ATTR " + key + "/" + val ) ;
		int pos = getPosition( key, true ) ;
		SValue oldVal = (SValue)getData( pos ) ;
		putData( pos, val ) ;
		sync() ;
		if ( oldVal.equalsNil() ) // ??? is Empty ????
		{
			notifyDataAsAdd
				( makeNotifyData( key, val )
				) ;
		}
		else
		{
			notifyDataAsUpdate
				( makeNotifyData( key, oldVal )
				, makeNotifyData( key, val )
				) ;
		}
	}
	
	/**
	 * Update value at a key with value from new one.
	 * Allowed only when updateable.
	 */
	public void updateAt( SValue key, SValue v )
	{
		//System.out.println( "SNODE UPD AT " + key + "/" + v ) ;
		try
		{
			setAttr( (SString)key, v ) ;
			//sync() ;
		}
		catch ( Exception ex )
		{
			skit.log.Logger.warn( "error in setting node attr " + key + ", ignoring it", ex ) ;
		}	
	}
	
	/**
	 * Update value at a key with value from new one.
	 * Allowed only when updateable.
	 */
	public void updateAt( String key, SValue v )
	{
		updateAt( BasicSValue.newString( key ), v ) ;
	}
	
	/**
	 * Remove an attribute.
	 *
	 * @param	key	The name of the attribute.
	 */
	public synchronized void removeAttr( SString key )
		throws SkitIOException
	{
		int pos = getPosition( key, false ) ;
		if ( pos != ILLEGAL_POS )
		{
			SValue oldVal = (SValue)getData( pos ) ;
			deAllocDataSlot( pos ) ;
			removePosition( key ) ;
			sync() ;
			notifyDataAsRemove( makeNotifyData( key, oldVal ) ) ;
		}
	}
	
	
	/**
	 * Remove value at a key.
	 * Allowed only when updateable.
	 */
	public void removeAt( SValue key )
	{
		//System.out.println( "SNODE REM AT " + key ) ;
		try
		{
			removeAttr( (SString)key ) ;
		}
		catch ( Exception ex )
		{
			skit.log.Logger.warn( "error in removing node attr " + key + ", ignoring it", ex ) ;
		}	
	}
	
	/**
	 * Remove value at a key.
	 * Allowed only when updateable.
	 */
	public void removeAt( String key )
	{
		removeAt( BasicSValue.newString( key ) ) ;
	}
	
	/**
	 * Check for existence of key.
	 */
	public boolean hasAt( SValue key )
	{
		try
		{
			return hasAttr( (SString)key ) ;
		}
		catch ( Exception ex )
		{
			skit.log.Logger.warn( "error in checking existence of node attr " + key + ", returning false", ex ) ;
			return false ;
		}	
	}
	
	/**
	 * Check for existence of key.
	 */
	public boolean hasAt( String key )
	{
		return hasAt( BasicSValue.newString( key ) ) ;
	}
	
	/**
	 * Get all the names of the attributes
	 */
	public Enumeration keys()
	{
		try
		{
			return keysUncaught() ;
		}
		catch ( SkitIOException ex )
		{
			skit.log.Logger.warn( "error in getting attribute names, ignoring it", ex ) ;
			return new EmptyEnumeration() ;
		}
	}
	
	/**
	 * Get all the names of the attributes.
	 * Pass an exception if it occurs.
	 */
	public Enumeration keysUncaught()
		throws SkitIOException
	{
		return ((SMap)getMeta( META_MAP )).keys() ;
	}
	
	/**
	 * Get all the values.
	 */
	public Enumeration elements()
	{
		return SKeyValueFunctionality.elements( this ) ;
		/*
		return 
			( new EnumerationTransformer
					( keys()
					, new NodeAttrTransformer( this )
					)
			) ;
		*/
	}
	
	/**
	 * Get all the keys and values in sequences.
	 */
	public Enumeration keysAndValues()
	{
		return SKeyValueFunctionality.keysAndValues( this ) ;
		/*
		return 
			( new EnumerationTransformer
					( keys()
					, new NodePairTransformer( this )
					)
			) ;
		*/
	}
	
	/**
	 * Update with values from other one.
	 */
	public void updateWith( SKeyValue other )
	{
		SKeyValueFunctionality.updateWith( this, other ) ;
	}
		
	/**
	 * Update with values from other one.
	 */
	public void updateWith( SValue other )
	{
		updateWith( (SKeyValue)other ) ;
	}
		
	/*
	public String toString()
	{
		return getMeta( META_MAP ).toString() ;
	}
	*/
	
	/**
	 * Get all the fixed svalues to be put on the writer.
	 * Meant to be overridden/implemented in subclass.
	 */
	/*
	public Enumeration getWriterFixedSValues( )
	{
		return new EnumerationSequence( new OneEnumeration( getMeta( META_MAP ) ), super.getWriterFixedSValues() ) ;
	}
	*/
	
	/**
	 * Write the info for the content on an appropriate writer.
	 */
	/*
	public void writeSpecialInfo( SWritableWriter out )
		throws SkitIOException, IOException
	{
		//out.writeSWritable( getMeta( META_MAP ) ) ;
		super.writeSpecialInfo( out ) ;
		//out.writeSWritables( getWriterFixedSValues( ) ) ;
	}
	*/
	
	/**
	 * Fill already instantiated object with values from SReadableReader
	 */
	/*
	public void fillWithSReadables( Enumeration in )
		throws IOException, SkitIOException
	{
		//putMeta( META_MAP, (SReadWritable)in.nextElement() ) ;
		super.fillWithSReadables( in ) ;
	}
	*/
	

	/**
	 * Make a nice string representation.
	 * Append it on the StringBuffer
	 */
	/*
	public void appendStringRepr( StringBuffer buf )
	{
		SKeyValueFunctionality.appendStringRepr( buf, this ) ;
		//PrintableFunctionality.appendStringRepr( buf, this, PrintableFunctionality.BRACKET_DEFAULT ) ;
	}
	*/

	/**
	 * Meant to be overridden.
	 */
	/*
	public void toStringBuffer( StringBuffer buf )
	{
	}
	*/
	
	/*
	public String toString()
	{
		return BasicSValue.toString( this ) ;
	}
	*/
	
	
}

