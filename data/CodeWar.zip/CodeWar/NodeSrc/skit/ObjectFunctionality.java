package skit ;

/**
 * The shared behavior for a (skit) object.
 */
public abstract class ObjectFunctionality
	implements ObjectBehavior
{
	/**
	 * Get a copy.
	 */
	public static Object copy( ObjectBehavior o )
		throws SkitException
	{
		ObjectBehavior newO = (ObjectBehavior)o.shallowCopy() ;
		newO.postCopy() ;
		return newO ;
	}
	
	/**
	 * Get a copy.
	 */
	public Object copy()
		throws SkitException
	{
		return copy( this ) ;
	}
	
	/**
	 * Get a copy, but only the top level of an object structure.
	 */
	public Object shallowCopy()
		throws SkitException
	{
		try
		{
			//ObjectBehavior newO = (ObjectBehavior)(o).clone() ;
			ObjectFunctionality newO = (ObjectFunctionality)clone() ;
			newO.postShallowCopy() ;
			return newO ;
		}
		catch ( CloneNotSupportedException e )
		{
			skit.log.Logger.log( "error in shallow copy of object", e ) ;
			throw new SkitException( "failed to shallow copy object" ) ;
		}
	}
	
	/**
	 * Do extra work after shallow copying.
	 * Meant to be overridden, meant to be used internally only (by the copy methods).
	 * Make sure super.postShallowCopy() is invoked first.
	 */
	protected void postShallowCopy()
		throws SkitException
	{
	}

	/**
	 * Do extra work after copying.
	 * Meant to be overridden, meant to be used internally only (by the copy methods).
	 * Make sure super.postCopy() is invoked first.
	 */
	public void postCopy()
		throws SkitException
	{
	}

}