package skit.textio ;

import java.io.* ;

/**
 * Concrete implementation for text input.
 */
public class TextInput extends PushbackReader
{
	public static final String BLANK_CHARS = " \t\n\r" ;
	
	public static final int EOF = -1 ;
	
	public TextInput( Reader in )
	{
		super( in ) ;
	}
	
	public int lookAhead()
		throws IOException
	{
		int c = read() ;
		unread( c ) ;
		return c ;
	}
	
	/**
	 * Read characters into buffer.
	 * @return	The last read character.
	 */
	public void skipBlanks()
		throws IOException
	{
		readCharsWhile( null, BLANK_CHARS ) ;
	}
	
	/**
	 * Read characters into buffer.
	 * @return	The last read character.
	 */
	public int readCharsWhile( StringBuffer buf, String okChars )
		throws IOException
	{
		int c ;
		for ( c = read() ; (c != EOF) && (okChars.indexOf( c ) >= 0) ; c = read() )
		{
			if ( buf != null )
				buf.append( c ) ;
		}
		unread( c ) ;
		return c ;
	}
	
	/**
	 * Read characters into buffer.
	 * @return	The last read character.
	 */
	public int readCharsUntil( StringBuffer buf, String stopChars )
		throws IOException
	{
		int c ;
		for ( c = read() ; (c != EOF) && (stopChars.indexOf( c ) < 0) ; c = read() )
		{
			if ( buf != null )
				buf.append( c ) ;
		}
		unread( c ) ;
		return c ;
	}
	
}