package skit.textio ;

/**
 * Interface for that which may be printed on text,
 * properly layout by indents.
 * @see skit.textio.TextInputable
 */
public interface TextOutputable
{
	/**
	 * Print on output with indent.
	 * @param	inputable	Write in such a way that it can be read via TextInputable
	 */
	public void print( TextOutput out ) ;
	
}