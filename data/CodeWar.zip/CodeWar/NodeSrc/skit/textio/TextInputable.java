package skit.textio ;

/**
 * Interface for that which may be read from text.
 * This involves parsing, so later parsing convenience methods will have to be added.
 * @see skit.textio.TextOutputable
 */
public interface TextInputable
{
	/**
	 * Read from input.
	 * It is assumed that an instance of the class already has been created.
	 * This method just reads values and fills itself with the content read.
	 */
	public Object read( TextInput in ) ;

}