package skit.textio ;

import java.io.* ;

/**
 * Concrete implementation for text output.
 */
public class TextOutput extends PrintWriter
{
	public TextOutput( Writer o )
	{
		super( o ) ;
	}
	
	/**
	 * Indent.
	 */
	public void indent( int amount )
	{
		
	}

	/**
	 * Spaces.
	 */
	public void space( int amount )
	{
		// ????
		write( ' ' ) ;
	}

	/**
	 * Newline.
	 */
	public void nl()
	{
		// ????
		write( '\n' ) ;
	}

}