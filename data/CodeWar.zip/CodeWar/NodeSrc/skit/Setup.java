package skit ;

import skit.factory.* ;
import skit.data.* ;
import skit.change.* ;
import skit.data.node.* ;
import skit.data.store.* ;
import skit.util.* ;
import com.objectspace.jgl.* ;
import java.util.* ;
import skit.data.value.* ;

/**
 * Setting up the system
 */
public class Setup
{
	private static void registerMIME( Registry r, String mainMime, String subMime, String classPre, String clName )
	{
		String mime = mainMime + MIMEType.mimeSep + subMime ;
		String fullClassName = classPre + clName ;
		try
		{
			Class cl = Class.forName( fullClassName ) ;
			//MIMEType tp = new MIMEType( mainMime, subMime, cl ) ;
			Class tp = cl ;
			r.register( mime, tp ) ;
		}
		catch ( ClassNotFoundException e )
		{
			skit.log.Logger.warn( "error in mime binding between " + mime + " and " + fullClassName, e ) ;
		}
	}
	
	private static void registerSValue( Registry sr, String mainMime, String subMime, String svalCl )
	{
		registerMIME( sr, mainMime, subMime, "skit.data.value.S", svalCl ) ;
	}
	
	private static void registerSValue( Registry sr, Registry cr, String mainMime, String subMime, String svalCl, String javaCl )
	{
		registerSValue( sr, mainMime, subMime, svalCl ) ;
		registerSWritable( cr, mainMime, subMime, "data.content." + javaCl ) ;
	}
	
	private static void registerSWritable( Registry r, String mainMime, String subMime, String javaCl )
	{
		registerMIME( r, mainMime, subMime, "skit.", javaCl ) ;
	}
	
	private static void registerRef( Registry rr,  String mainMime, String subMime, String javaCl )
	{
		registerMIME( rr, mainMime, subMime, "skit.data.", javaCl ) ;
	}
	
	/**
	 * Init SValue stuff.
	 */
	private static void initSValues( Registry svalueMimeRegistry, Registry swriteableRegistry )
	{
		registerSValue( svalueMimeRegistry, swriteableRegistry, "text", "symbol", "Symbol", "SymbolDataContent" ) ;
		registerSValue( svalueMimeRegistry, swriteableRegistry, "text", "plain", "String", "StringDataContent" ) ;
		//registerSValue( svalueMimeRegistry, swriteableRegistry, "num", "int", "Int", "IntDataContent" ) ;
		registerSValue( svalueMimeRegistry, swriteableRegistry, "bool", "plain", "Bool", "BoolDataContent" ) ;
		//registerSValue( svalueMimeRegistry, swriteableRegistry, "keyed", "map", "Map", "MapDataContent" ) ;
		//registerSValue( svalueMimeRegistry, swriteableRegistry, "seq", "vec", "Vector", "SeqDataContent" ) ;

		//registerSValue( svalueMimeRegistry, "keyed", "node", "Node" ) ;
		//registerSValue( svalueMimeRegistry, "seq", "vec", "Vector" ) ;
		//registerSValue( svalueMimeRegistry, "keyed", "map", "Map" ) ;
	}

	/**
	 * Init SReadWritable stuff.
	 */
	private static void initSReadWritable( Registry swriteableRegistry )
	{
		registerSWritable( swriteableRegistry, "struct", "store-info", "data.store.StoreInfo" ) ;
		registerSWritable( swriteableRegistry, "struct", "part-info", "data.store.PartInfo" ) ;
		registerSWritable( swriteableRegistry, "struct", "relmeta-info", "data.relation.RelationMetaInfo" ) ;
		registerSWritable( swriteableRegistry, "struct", "part1-info", "data.store.OnePartInfo" ) ;
		registerSWritable( swriteableRegistry, "struct", "store-parts", "data.store.StoreParts" ) ;

		registerSWritable( swriteableRegistry, "type", "stype", "data.value.SType" ) ;

		registerSWritable( swriteableRegistry, "id", "unique", "id.UniqueId" ) ;
		
		registerSWritable( swriteableRegistry, "node", "stored", "data.node.StorableSNode" ) ;
		
		registerSWritable( swriteableRegistry, "relation", "stored", "data.relation.StorableSRelation" ) ;

		registerSWritable( swriteableRegistry, "ref", "file", "data.content.FileContent" ) ;

		//registerSValue( swriteableRegistry, "keyed", "node", "Node" ) ;
		registerSValue( swriteableRegistry, "keyed", "map", "Map" ) ;

		//registerSValue( swriteableRegistry, "queried", "rel", "Relation" ) ;

	}

	/**
	 * Init at least one store.
	 */
	private static void initStorage( Storage storage, Progress progress )
	{
		String storeName = "root" ;
		Store store = new SequentialSValueStore( storeName, progress ) ;
		storage.registerAsDefaultStore( store ) ;
		try
		{
			store.open( new StoredStoreInitialiser() ) ;
		}
		catch ( Exception ex )
		{
			skit.log.Logger.log( "exception while trying to open/init store " + storeName, ex ) ;
		}
	}

	/**
	 * Finalize the storage.
	 */
	private static void finiStorage( Storage storage )
	{
		try
		{
			storage.close() ;
		}
		catch ( Exception ex )
		{
			skit.log.Logger.log( "exception while trying to close storage", ex ) ;
		}
	}

	/**
	 * Do the initialization
	 */
	public static void init( Progress progress )
	{
		// change management
		Globals.setChangeManager( ChangeManager.newChangeManager() ) ;
		
		// type mapping setup
			// for svalues & mime
		Registry svalueMimeRegistry = new TreeRegistry( "mime-svalue", MIMEType.mimeSep, false, true ) ;
		Registry swriteableRegistry = new TreeRegistry( "mime-content", MIMEType.mimeSep, false, true ) ;

		// Patch added by Martijn
		// Without this, registerMime causes a StaticInitializer error
		/////////////////////////////////////////////////
		System.out.println("Strangely patched NodeLib");
		Object o = new skit.data.value.SBool();
		/////////////////////////////////////////////////

		initSValues( svalueMimeRegistry, swriteableRegistry ) ;
		initSReadWritable( swriteableRegistry ) ;
		
		Globals.setSValueMimeRegistry( svalueMimeRegistry ) ;		
		Globals.setSWritableMimeRegistry( swriteableRegistry ) ;
		
			// for refs & mime
		//Registry refMimeRegistry = new TreeRegistry( "mime-ref", MIMEType.mimeSep, false, true ) ;
		
		//Globals.setRefMimeRegistry( refMimeRegistry ) ;		
		
		// factory setup
		Factories fs ;
		
		Globals.setFactories( fs = Factories.newFactories() ) ;
		Globals.setSReadWritableFactory( new SReadWritableFactory() ) ;
		
		// storage setup (factories must be available)
		Storage storage ;
		Globals.setStorage( storage = Storage.newStorage() ) ;
		initStorage( storage, progress ) ;
		
		/*
		fs.registerFactory( "sval", new skit.id.UniqueIdFactory() ) ;
		//fs.registerFactory( new skit.data.store.UniqueIdFactory() ) ;
		fs.registerFactory( new skit.data.value.SStringValueFactory() ) ;
		fs.registerFactory( new skit.data.value.SVectorValueFactory() ) ;
		//fs.registerFactory( new skit.value.BasicSingleValueFactory() ) ;
		//fs.registerFactory( new skit.value.BasicCompositeValueFactory() ) ;
		//fs.registerFactory( new skit.value.type.BasicTypeFactory() ) ;
		fs.registerFactory( new skit.data.node.StoredNodeFactory() ) ;
		fs.registerFactory( new skit.data.relation.StoredRelationFactory() ) ;
		*/

		/*
		// registry for SValuable's setup
		Registry svalRegistry ;
		
		Globals.setSValueableRegistry( svalRegistry = new FlatRegistry( "svalueables", false, false ) ) ;
		Set examples = new HashSet() ;
		try
		{
			examples.add( fs.make( "id", "unique", null ) ) ;
		}
		catch ( SkitException e )
		{
			skit.log.Logger.warn( "failed to make svaluable example", e ) ;
		}
		for ( Enumeration e = examples.elements() ; e.hasMoreElements() ; )
		{
			try
			{
				SReadWritable sval = (SReadWritable)e.nextElement() ;
				//svalRegistry.register( sval.getName(), sval.getCreationClass() ) ;
			}
			catch ( Exception ex )
			{
				skit.log.Logger.log( "error in registering svalue examples", ex ) ;
			}
		}
		*/
		
		/*
		try
		{
			//svalRegistry.register( Class.forName( "skit.data.value.
		}
		catch ( ClassNotFoundException e )
		{
		}
		*/
		
	}

	/**
	 * Do the finalization
	 */
	public static void fini()
	{
		finiStorage( skit.Globals.getStorage() ) ;
	}
}