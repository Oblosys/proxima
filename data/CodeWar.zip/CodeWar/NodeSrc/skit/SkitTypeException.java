package skit ;

public class SkitTypeException extends SkitException
{
	public SkitTypeException( String msg )
	{
		super( msg ) ;
	}
}