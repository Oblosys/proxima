package skit ;

public class SkitIOException extends SkitException
{
	public SkitIOException( String msg )
	{
		super( msg ) ;
	}
}