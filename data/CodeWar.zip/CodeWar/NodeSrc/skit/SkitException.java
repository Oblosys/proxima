package skit ;

public class SkitException extends Exception
{
	public SkitException( String msg )
	{
		super( msg ) ;
	}
}