package skit ;

public abstract class SkitEvent extends java.util.EventObject
{
	public SkitEvent( Object source )
	{
		super( source ) ;
	}
}