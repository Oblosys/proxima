package skit ;

/**
 * The basic behavior for a (skit) object.
 */
public interface ObjectBehavior extends Cloneable
{
	/**
	 * Get a copy.
	 */
	public Object copy()
		throws SkitException ;
	
	/**
	 * Get a copy, but only the top level of an object structure.
	 */
	public Object shallowCopy()
		throws SkitException ;
	
	/**
	 * Do extra work after copying.
	 * Meant to be overridden, meant to be used internally only (by the copy methods).
	 * Make sure super.postCopy() is invoked first.
	 */
	public void postCopy()
		throws SkitException ;

}