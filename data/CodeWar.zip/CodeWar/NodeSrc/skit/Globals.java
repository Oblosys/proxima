package skit ;

import skit.factory.Factories ;
import skit.data.store.Storage ;
import skit.data.SReadWritableFactory ;
import skit.util.Registry ;
import skit.change.ChangeManager ;

/**
 * Global variables.
 * Meant for either bootstrapping services or global available one-of-a-kind (singleton) services.
 */
public class Globals
{
	/**
	 * The default/current Factories.
	 */
	private static Factories theFactories ;

	/**
	 * @return The default/current Factories.
	 */
	public static Factories getFactories()
	{
		return theFactories ;
	}

	/**
	 * Set the default/current Factories.
	 */
	public static void setFactories( Factories f )
	{
		theFactories = f ;
	}

	/**
	 * The default/current Storage.
	 */
	private static Storage theStorage ;

	/**
	 * @return The default/current Storage.
	 */
	public static Storage getStorage()
	{
		return theStorage ;
	}

	/**
	 * Set the default/current Storage.
	 */
	public static void setStorage( Storage f )
	{
		theStorage = f ;
	}

	/**
	 * The default/current ChangeManager.
	 */
	private static ChangeManager theChangeManager ;

	/**
	 * @return The default/current Storage.
	 */
	public static ChangeManager getChangeManager()
	{
		return theChangeManager ;
	}

	/**
	 * Set the default/current ChangeManager.
	 */
	public static void setChangeManager( ChangeManager cm )
	{
		theChangeManager = cm ;
	}

	/**
	 * The default/current SValue <-> MIME registry.
	 */
	private static Registry theSValueMimeRegistry ;

	/**
	 * @return The default/current SValue <-> MIME registry.
	 */
	public static Registry getSValueMimeRegistry()
	{
		return theSValueMimeRegistry ;
	}

	/**
	 * Set the default/current SValue <-> MIME registry.
	 */
	public static void setSValueMimeRegistry( Registry f )
	{
		theSValueMimeRegistry = f ;
	}

	/**
	 * The default/current Content <-> MIME registry.
	 */
	private static Registry theSWritableMimeRegistry ;

	/**
	 * @return The default/current Content <-> MIME registry.
	 */
	public static Registry getSWritableMimeRegistry()
	{
		return theSWritableMimeRegistry ;
	}

	/**
	 * Set the default/current Content <-> MIME registry.
	 */
	public static void setSWritableMimeRegistry( Registry f )
	{
		theSWritableMimeRegistry = f ;
	}

	/**
	 * The default/current Ref <-> MIME registry.
	 */
	//private static Registry theRefMimeRegistry ;

	/**
	 * @return The default/current Ref <-> MIME registry.
	 */
	/*
	public static Registry getRefMimeRegistry()
	{
		return theRefMimeRegistry ;
	}
	*/

	/**
	 * Set the default/current Ref <-> MIME registry.
	 */
	/*
	public static void setRefMimeRegistry( Registry f )
	{
		theRefMimeRegistry = f ;
	}
	*/

	/**
	 * The registry for SValueable's.
	 */
	private static SReadWritableFactory theSReadWritableFactory ;

	/**
	 * @return The default/current SReadWritableFactory.
	 */
	public static SReadWritableFactory getSReadWritableFactory()
	{
		return theSReadWritableFactory ;
	}

	/**
	 * Set the default/current SReadWritableFactory.
	 */
	public static void setSReadWritableFactory( SReadWritableFactory f )
	{
		theSReadWritableFactory = f ;
	}

}