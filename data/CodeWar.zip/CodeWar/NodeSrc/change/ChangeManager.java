package skit.change ;

import skit.data.value.* ;
//import skit.id.* ;
import com.objectspace.jgl.* ;
import java.util.* ;

/**
 * A ChangeManager takes care of propagating a received change to interested
 * ChangeReceivers.
 * ChangeManager instance is a singleton.
 */
public class ChangeManager
{
	private static ChangeManager theChangeManager = null ;
	
	private Sequence changeGroups ;
	
	private ChangeManager()
	{
		changeGroups = new Array() ;
	}
	
	/**
	 * Create a singleton ChangeManager.
	 */
	public static ChangeManager newChangeManager()
	{
		if ( theChangeManager == null )
			theChangeManager = new ChangeManager() ;
		return theChangeManager ;
	}
	
	/**
	 * Create a new ChangeGroup.
	 */
	public ChangeGroup newChangeGroup()
	{
		ChangeGroup chgr = new ChangeGroup( this ) ;
		changeGroups.add( chgr ) ;
		return chgr ;
	}
	
	/**
	 * Remove a ChangeGroup.
	 */
	public void removeGroup( ChangeGroup chgr )
	{
		changeGroups.remove( chgr ) ;
	}
	
	private void propagate( ChangeEvent evt )
	{
		for ( Enumeration e = changeGroups.elements() ; e.hasMoreElements() ; )
		{
			((ChangeGroup)e.nextElement()).changeUpdate( evt, this ) ;
		}
	}
	
	/**
	 * Something has changed.
	 * Encoded into ChangeEvent.
	 * Propagate it.
	 */
	public void changed( ChangeEvent evt )
	{
		System.out.println( evt ) ;
		propagate( evt ) ;
	}
	
	/**
	 * Tell that an identifiable value has changed.
	 * Passing the newly added value.
	 */
	public void changed( Object val, int kind, SequenceBehavior oldV, SequenceBehavior newV )
	{
		ChangeEvent evt = new ChangeEvent( val, kind, oldV, newV ) ;
		changed( evt ) ;
	}
	
	/**
	 * Tell that an identifiable value has changed.
	 * Passing the newly added value.
	 */
	public void changedAdd( Object val, SequenceBehavior newV )
	{
		changed( val, ChangeEvent.CHANGE_ADD, null, newV ) ;
	}
	
	/**
	 * Tell that an identifiable value has changed.
	 * Passing the old removed value.
	 */
	public void changedRemove( Object val, SequenceBehavior oldV )
	{
		changed( val, ChangeEvent.CHANGE_REMOVE, oldV, null ) ;
	}
	
	/**
	 * Tell that an identifiable value has changed.
	 * Passing the old and new value.
	 */
	public void changedUpdate( Object val, SequenceBehavior oldV, SequenceBehavior newV )
	{
		changed( val, ChangeEvent.CHANGE_UPDATE, oldV, newV ) ;
	}
	
}