package skit.change ;

import skit.data.value.* ;
import skit.id.* ;
import skit.util.* ;

/**
 * A ChangeEvent encodes a change.
 */
public class ChangeEvent extends skit.SkitEvent
{
	// ???? not this way I guess
	public static final int CHANGE_ADD = 0 ;
	public static final int CHANGE_REMOVE = 1 ;
	public static final int CHANGE_UPDATE = 2 ;
	
	private int changeKind ;
	private SequenceBehavior oldValue, newValue ;
	
	private static String[] kindToStr = { "add", "remove", "update" } ;
	
	public ChangeEvent( Object source, int kind, SequenceBehavior oldV, SequenceBehavior newV )
	{
		super( source ) ;
		changeKind = kind ;
		oldValue = oldV ;
		newValue = newV ;
	}
	
	public ChangeEvent( Object source, ChangeEvent evt, Transformer valTransform )
	{
		this
			( source
			, evt.getChangeKind()
			, (SequenceBehavior)valTransform.transform( evt.getOldValue() )
			, (SequenceBehavior)valTransform.transform( evt.getNewValue() )
			) ;
	}
	
	public boolean isAdd()
	{
		return changeKind == CHANGE_ADD ;
	}
	
	public boolean isRemove()
	{
		return changeKind == CHANGE_REMOVE ;
	}
	
	public boolean isUpdate()
	{
		return changeKind == CHANGE_UPDATE ;
	}
	
	public int getChangeKind()
	{
		return changeKind ;
	}
	
	private String getChangeKindStr()
	{
		return kindToStr[ getChangeKind() ] ;
	}
	
	public SequenceBehavior getOldValue()
	{
		return oldValue ;
	}
	
	public SequenceBehavior getNewValue()
	{
		return newValue ;
	}
	
	public String toString()
	{
		return "Change (" + getChangeKindStr() + ") in " + getSource() + ": " + getOldValue() + "->" + getNewValue() ;
	}
	
}