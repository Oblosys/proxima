package skit.change ;

import skit.data.value.* ;
import com.objectspace.jgl.* ;
import com.objectspace.jgl.predicates.* ;
import java.util.* ;

/**
 * A ChangeGroup administrates a group of change dependencies.
 * It is done this way to avoid mixup with actual dependants,
 * especially the breaking down of dependencies.
 */
public class ChangeGroup
	implements ChangeListener
{
	private Map groupies ;
	private ChangeManager changeManager ;
	
	public ChangeGroup( ChangeManager cm )
	{
		changeManager = cm ;
		groupies = new HashMap( new IdenticalTo() ) ;
	}
	
	/**
	 * Add dependency w.r.t. a change.
	 * The change will be propagated from fromObj to toObj
	 */
	public void addChangePropagationFromTo( Object fromObj, ChangeListener toObj )
	{
		Object o = groupies.get( fromObj ) ;
		if ( o == null )
			groupies.put( fromObj, toObj ) ;
		else
		{
			Sequence dependents ;
			if ( o instanceof ChangeListener )
			{
				dependents = new Array() ;
				dependents.add( o ) ;
				groupies.put( fromObj, dependents ) ;
			}
			else
			{
				dependents = (Sequence)o ;
			}
			dependents.add( toObj ) ;
		}
	}

	/**
	 * Remove dependency w.r.t. a change.
	 */
	public void removeChangePropagationFromTo( Object fromObj, ChangeListener toObj )
	{
		Object o = groupies.get( fromObj ) ;
		if ( o == null )
			return ;
		
		if ( ( o instanceof ChangeListener ) && ( o == toObj ) )
			groupies.remove( fromObj ) ;
		else
		{
			Sequence dependents = (Sequence)o ;
			dependents.remove( toObj ) ;
			if ( dependents.isEmpty() )
				groupies.remove( fromObj ) ;
		}
	}

	/**
	 * Receive the change.
	 * Propagate it.
	 */
	public void changeUpdate( ChangeEvent evt, ChangeManager fromMgr )
	{
		Object fromObj = evt.getSource() ;
		Object o = groupies.get( fromObj ) ;
		if ( o == null )
			return ;
		
		if ( o instanceof ChangeListener )
			((ChangeListener)o).changeUpdate( evt, fromMgr ) ;
		else
		{
			Sequence dependents = (Sequence)o ;
			for ( Enumeration e = dependents.elements() ; e.hasMoreElements() ; )
			{
				ChangeListener cl = (ChangeListener)e.nextElement() ;
				cl.changeUpdate( evt, fromMgr ) ;
			}
		}
	}
	
	/**
	 * Stop the group, remove it.
	 */
	public void close()
	{
		changeManager.removeGroup( this ) ;
	}

}