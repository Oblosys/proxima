package skit.change ;

/**
 * A ChangeListener receives changes,
 * encoded in a ChangeEvent.
 * @see skit.change.ChangeEvent
 */
public interface ChangeListener extends java.util.EventListener
{
	/**
	 * Receive the change.
	 */
	public void changeUpdate( ChangeEvent evt, ChangeManager fromMgr ) ;

}