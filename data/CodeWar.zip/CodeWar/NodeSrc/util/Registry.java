package skit.util ;

import com.objectspace.jgl.*;
import java.util.* ;
import skit.util.* ;
import skit.SkitException ;

/**
 * A Registry is a repository for resources with a name.
 * Besides that, if indicated a default value is maintained.
 * The default is either set explicitly under impl name "default" for a category,
 * or is the first resource added for a category.
 */
public interface Registry
{
	/**
	 * Get the key for default value.
	 */
	public String getDefaultKey() ;
	
	/**
	 * Get the separator used.
	 * @return	The separator, or null when none is used.
	 */
	public String getSeparator() ;
	
	/**
	 * Get the size of the registry
	 */
	//public int getSize( ) ;
	
	/**
	 * Get the name of the registry
	 */
	public String getName( ) ;
	
	/**
	 * Register the resource.
	 */
	public void register( String key, Object r ) ;
	
	/**
	 * Register the resource as default, within a prefix
	 */
	public void registerAsDefault( String withIn, Object r ) ;
	
	/**
	 * Find a resource.
	 * @return The resource, or null if none available.
	 */
	public Object resolve( String key ) ;
	
	/**
	 * Find key for resource.
	 * The actual behavior depends on the specific implementation,
	 * that is, if it is supported.
	 */
	public String reverseResolve( Object r ) ;
	
	/**
	 * @return An Enumeration of all available resource names.
	 */
	public Enumeration resourceKeys() ;
		
	/**
	 * @return An Enumeration of all available resources.
	 */
	public Enumeration resources() ;
		
}