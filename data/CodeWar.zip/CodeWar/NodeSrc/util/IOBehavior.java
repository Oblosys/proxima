package skit.util ;

import java.io.* ;
import skit.* ;

/**
 * Behavior excpected from objects interacting via IO.
 */
public interface IOBehavior
{
	/**
	 * Flush data, but do not close.
	 */
	public void flush()
		throws IOException, SkitIOException ;
	
	/**
	 * Flush data and close.
	 */
	public void close()
		throws IOException, SkitIOException ;
	
}