package skit.util ;

import java.util.* ;

/**
 * Enumeration taking elements of another Enumeration but transforming
 * them on the fly.
 */
public class EnumerationTransformer implements Enumeration
{
	private Enumeration incoming ;
	private Transformer transformer ;
	
	public EnumerationTransformer( Enumeration in, Transformer trf )
	{
		incoming = in ;
		transformer = trf ;
	}
	
	public boolean hasMoreElements()
	{
		return incoming.hasMoreElements() ;
	}
	
	public Object nextElement()
	{
		return transformer.transform( incoming.nextElement() ) ;
	}
}

