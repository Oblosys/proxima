package skit.util ;

import java.util.* ;

/**
 * Enumeration taking elements of another Enumeration but filtering out
 * elements on the fly.
 * Optionally, a transformer can be specified.
 * @see skit.util.Transformer
 * @see skit.util.Predicate
 */
public class EnumerationFilter implements Enumeration
{
	private Enumeration incoming ;
	private Predicate predicate ;
	private Transformer transform ;
	private Object next ;
	private boolean hasNext ;
	
	public EnumerationFilter( Enumeration in, Predicate pred, Transformer trf )
	{
		incoming = in ;
		predicate = pred ;
		transform = trf ;
		findNext() ;
	}
	
	public EnumerationFilter( Enumeration in, Predicate pred )
	{
		this( in, pred, null ) ;
	}
	
	private void findNext()
	{
		hasNext = false ;
		for (;;)
		{
			if ( incoming.hasMoreElements() )
			{
				Object v = incoming.nextElement() ;
				if ( predicate.predicate( v ) )
				{
					hasNext = true ;
					next = ( transform != null ? transform.transform( v ) : v ) ;
					return ;
				}
			}
			else
				return ;
		}
	}
	
	public boolean hasMoreElements()
	{
		return hasNext ;
	}
	
	public Object nextElement()
	{
		if ( hasMoreElements() )
		{
			Object res = next ;
			findNext() ;
			return res ;
		}
		else
			return null ;
	}
}

