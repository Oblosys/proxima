package skit.util ;

/**
 * Interface for transforming elements of a stream
 * @see skit.util.EnumerationTransformer
 */
public interface Transformer
{
	public Object transform( Object o ) ;
}

