package skit.util ;

import java.util.* ;

/**
 * One element enumeration
 */
public class OneEnumeration implements Enumeration
{
	private Object val ;
	
	public OneEnumeration( Object v )
	{
		val = v ;
	}
	
	public boolean hasMoreElements()
	{
		return val != null ;
	}
	
	public Object nextElement()
	{
		Object res = val ;
		//System.out.println( "ENUM ONE " + res ) ;
		val = null ;
		return res ;
	}
}