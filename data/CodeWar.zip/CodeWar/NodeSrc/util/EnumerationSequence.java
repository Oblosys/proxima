package skit.util ;

import java.util.* ;

/**
 * Enumeration combining two other Enumerations, delivering first all the values of
 * the first one, then the second.
 * ???? todo: combine with EnumerationEnumeration
 */
public class EnumerationSequence implements Enumeration
{
	private Enumeration[] in ;
	private int inCount ;
	
	public EnumerationSequence( Enumeration e1, Enumeration e2 )
	{
		in = new Enumeration[ 2 ] ;
		in[ 0 ] = e1 ;
		in[ 1 ] = e2 ;
		inCount = 0 ;
		findNext() ;
	}
	
	public void findNext()
	{
		while ( inCount < in.length && ( ! in[ inCount ].hasMoreElements() ) )
			inCount++ ;
	}
	
	public boolean hasMoreElements()
	{
		return inCount < in.length && in[ inCount ].hasMoreElements() ;
	}
	
	public Object nextElement()
	{
		if ( hasMoreElements() )
		{
			Object res = in[ inCount ].nextElement() ;
			//System.out.println( "ENUM SEQ " + res ) ;
			findNext() ;
			return res ;
		}
		else
			return null ;
	}
}
