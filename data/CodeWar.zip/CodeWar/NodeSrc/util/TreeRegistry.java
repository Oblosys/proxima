package skit.util ;

import com.objectspace.jgl.*;
import java.util.* ;
//import skit.util.* ;
import skit.SkitException ;

/**
 * TreeRegistry implements a tree of registries.
 * Names are denoted by parts separated by a separator.
 * A TreeRegistry can be compared to a simple directory service,
 * mapping names/paths onto objects.
 * @see skit.util.FlatRegistry
 * @see skit.util.Registry
 */
public class TreeRegistry
	implements Registry
{
	private Map reverse ;
	private FlatRegistry topRegistry ;
	private boolean hasDefault ;
	private String name ;
	private String separator ;
	
	public TreeRegistry( String nm, String sep, boolean useDef, boolean doReverse )
	{
		name = nm ;
		hasDefault = useDef ;
		separator = sep ;
		topRegistry = new FlatRegistry( nm, hasDefault, false ) ;
		reverse = doReverse ? new HashMap() : null ;
	}
	
	/**
	 * Get the key for default value.
	 */
	public String getDefaultKey()
	{
		return topRegistry.getDefaultKey() ;
	}

	/**
	 * Get the separator used.
	 * @return	The separator, or null when none is used.
	 */
	public String getSeparator()
	{
		return separator ;
	}
	
	/**
	 * Get the name of the registry
	 */
	public String getName( )
	{
		return name ;
	}
	
	private Object findAndReplace
					( String key
					, Object newO
					, boolean extendIfNeeded
					//, boolean useDefault
					)
	{
		String head = key ;
		String tail = null ;
		int sepPos = key.indexOf( separator ) ;
		
		if ( sepPos > 0 )
		{
			head = key.substring( 0, sepPos ) ;
			tail = key.substring( sepPos+1, key.length() ) ;
		}
		
		Object res = topRegistry.resolve( head ) ;
		
		if ( tail != null )
		{
			if ( res == null && extendIfNeeded )
				topRegistry.register( head, res = new TreeRegistry( getName() + separator, separator, hasDefault, false ) ) ;

			if ( res instanceof TreeRegistry )
				res = ((TreeRegistry)res).findAndReplace( tail, newO, extendIfNeeded ) ;
			else
				res = null ;
		}
		else
		{
			if ( newO != null )
				topRegistry.register( head.intern(), newO ) ;
		}
		
		return res ;
	}
	
	private void addResource( String key, Object r )
	{
		findAndReplace( key, r, true ) ;
		if ( reverse != null )
			reverse.put( r, key ) ;
	}
	
	/**
	 * Register the resource.
	 */
	public void register( String key, Object r )
	{
		addResource( key, r ) ;
	}
	
	/**
	 * Register the resource as default.
	 */
	public void registerAsDefault( String withIn, Object r )
	{
		addResource( (withIn == null ? "" : withIn + separator) + getDefaultKey(), r ) ;
	}
	
	/**
	 * Find a resource.
	 * @return The resource, or null if none available.
	 */
	public Object resolve( String key )
	{
		Object res = findAndReplace( key, null, false ) ;
		return res ;
	}
	
	/**
	 * Find key for resource.
	 */
	public String reverseResolve( Object r )
	{
		return reverse != null ? (String)reverse.get( r ) : null ;
	}
	
	/**
	 * @return An Enumeration of all available resource names.
	 */
	public Enumeration resourceKeys()
	{
		// ???? not right yet...
		return topRegistry.resourceKeys() ;
	}
	
	/**
	 * @return An Enumeration of all available resources.
	 */
	public Enumeration resources()
	{
		// ???? not right yet...
		return topRegistry.resources() ;
	}
		
	public String toString()
	{
		return topRegistry.toString() ;
	}
		
}