package skit.util ;

/**
 * Interface for matching elements of a stream.
 * @see skit.util.Predicate
 * @see skit.util.EnumerationFilter
 * @see skit.util.Predicate
 */
public interface Matcher
{
	boolean matchWith( Object o, Object with ) ;
}
