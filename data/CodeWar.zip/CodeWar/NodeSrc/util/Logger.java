package skit.log ;

/**
 * Log a message plus exception (if any).
 */
public class Logger
{
	private static void doLog( String kind, String s, Exception e )
	{
		System.err.println( kind.toUpperCase() + ": " + s ) ;
		if ( e != null )
			e.printStackTrace( System.err ) ;
	}

	public static void log( String s, Exception e )
	{
		doLog( "log", s, e ) ;
	}

	public static void log( String se )
	{
		log( se, null ) ;
	}
	
	public static void warn( String s, Exception e )
	{
		doLog( "warn", s, e ) ;
	}

	public static void fatal( String s, Exception e )
	{
		doLog( "fatal", s, e ) ;
	}

}