package skit.util ;

import java.util.* ;

/**
 * A moment in time.
 */
public class Timestamp
{
	private long time ;

	/**
	 * Make a timestamp with current time.
	 */
	public static long timestamp()
	{
		return System.currentTimeMillis() ;
	}
	
	/**
	 * Make a timestamp with current time.
	 */
	public Timestamp()
	{
		time = timestamp() ;
	}
	
	/**
	 * Get the time.
	 */
	public long getTime()
	{
		return time ;
	}
	
	/**
	 * Get the time.
	 */
	public Date getDate()
	{
		return new Date( getTime() )  ;
	}
	
}