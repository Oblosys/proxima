package skit.util ;

/**
 * Interface for checking a predicate of a stream for filtering out
 * elements of a stream.
 * @see skit.util.EnumerationFilter
 */
public interface Predicate
{
	boolean predicate( Object o ) ;
}
