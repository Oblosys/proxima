package skit.util ;

import java.util.* ;
import java.io.* ;
//import skit.data.* ;
//import skit.util.* ;
//import skit.util.* ;
//import skit.* ;
//import skit.data.* ;
//import com.objectspace.jgl.*;
//import java.io.* ;

/**
 * Printing functionality
 */
public class PrintableFunctionality
{
	public static final int BRACKET_NONE = 0 ;
	public static final int BRACKET_DEFAULT = 1 ;
	public static final int BRACKET_KEYVAL = 2 ;
	public static final int BRACKET_RSHIP = 3 ;
	public static final int BRACKET_COMMA = 4 ;
	public static final int BRACKET_STOREID = 5 ;
	
	private static final int NR_OF_BRACKETS = 6 ;
	
	private static BracketInfo[] brackets ;
	
	static
	{
		brackets = new BracketInfo[ NR_OF_BRACKETS ] ;
		brackets[ BRACKET_NONE ] = new BracketInfo( "", "", "" ) ;
		brackets[ BRACKET_DEFAULT ] = new BracketInfo( "[", "]", "," ) ;
		brackets[ BRACKET_KEYVAL ] = new BracketInfo( "<", ">", ":" ) ;
		brackets[ BRACKET_RSHIP ] = new BracketInfo( "<", ">", "," ) ;
		brackets[ BRACKET_COMMA ] = new BracketInfo( "", "", "," ) ;
		brackets[ BRACKET_STOREID ] = new BracketInfo( "[", "]", ":" ) ;
	}
	
	private static BracketInfo getInfo( int bracket )
	{
		BracketInfo bracketInfo = null ;
		bracketInfo = ( bracket >= 0 && bracket < NR_OF_BRACKETS )
						? brackets[ bracket ]
						: brackets[ BRACKET_DEFAULT ] ;
		return bracketInfo ;
	}
	
	/*
	public static void appendStringRepr( StringBuffer buf, Printable val, int bracket )
	{
		appendStringRepr( buf, val, getInfo( bracket ) ) ;
	}
	*/
	
	public static void appendStringRepr( StringBuffer buf, Printable v1, Printable v2, int bracket )
	{
		appendStringRepr( buf, v1, v2, getInfo( bracket ) ) ;
	}
	
	public static void appendStringRepr( StringBuffer buf, Printable v1, Printable v2, BracketInfo br )
	{
		buf.append( br.open ) ;
		v1.appendStringRepr( buf ) ;
		buf.append( br.sep ) ;
		v2.appendStringRepr( buf ) ;
		buf.append( br.close ) ;
	}
	
	/*
	public static void appendStringRepr( StringBuffer buf, Printable val )
	{
		appendStringRepr( buf, val, getInfo( BRACKET_NONE ) ) ;
	}
	
	private static void appendStringRepr( StringBuffer buf, Printable val, BracketInfo br )
	{
		buf.append( br.open ) ;
		val.toStringBuffer( buf ) ;
		buf.append( br.close ) ;
	}
	*/
	
	public static void appendStringRepr( StringBuffer buf, Enumeration vals, int bracket )
	{
		appendStringRepr( buf, vals, getInfo( bracket ) ) ;
	}
	
	private static void appendStringRepr( StringBuffer buf, Enumeration vals, BracketInfo br )
	{
		buf.append( br.open ) ;
		for ( ; vals.hasMoreElements() ; )
		{
			Object o = vals.nextElement() ;
			if ( o instanceof Printable )
			{
				Printable v = (Printable)o ;
				v.appendStringRepr( buf ) ;
			}
			else
			{
				buf.append( o.toString() ) ;
			}
			if ( vals.hasMoreElements() )
				buf.append( br.sep ) ;
		}
		buf.append( br.close ) ;
	}
	
	public static String toString( Printable val )
	{
		StringBuffer buf = new StringBuffer() ;
		val.appendStringRepr( buf ) ;
		//appendStringRepr( buf, val, BRACKET_NONE ) ;
		return buf.toString() ;
	}
	
}

class BracketInfo
{
	public String open ;
	public String close ;
	public String sep ;
	
	public BracketInfo( String o, String c, String s )
	{
		open = o ;
		close = c ;
		sep = s ;
	}
}

