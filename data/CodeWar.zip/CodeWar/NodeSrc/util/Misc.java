package skit.util ;

import java.util.* ;

/**
 * Misc utils
 */
public class Misc
{
	/**
	 * Make a vector of an Enumeration
	 * @param	e	the Enumeration
	 */
	public static Vector vector( Enumeration e )
	{
		Vector v = new Vector( 10 ) ;
		for( ; e.hasMoreElements() ; )
		{
			Object el ;
			v.addElement( el = e.nextElement() ) ;
		}
		return v ;
	}
	
	/**
	 * Make a String of an Enumeration.
	 * Use as extra parameters values which have to be put in front, back and as separator.
	 * @param	e	the Enumeration
	 */
	public static void enumerationToString( StringBuffer buf, Enumeration e, String pre, String sep, String post )
	{
		buf.append( pre ) ;
		for ( ; e.hasMoreElements() ; )
		{
			buf.append( e.nextElement().toString() ) ;
			if ( e.hasMoreElements() )
				buf.append( sep ) ;
		}
		buf.append( post ) ;
	}
	
	/**
	 * Put a number of spaces into StringBuffer
	 */
	public static void spaces( StringBuffer buf, int amount )
	{
		while ( amount-- > 0 )
		{
			buf.append( ' ' ) ;
		}
	}
	
	/**
	 * Return a number of spaces
	 */
	public static String spaces( int amount )
	{
		StringBuffer buf = new StringBuffer( amount ) ;
		spaces( buf, amount ) ;
		return buf.toString() ;
	}
	
}