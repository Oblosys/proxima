package skit.util ;

import java.io.* ;
import java.util.* ;
//import skit.value.* ;
//import skit.value.type.* ;
//import skit.* ;

/**
 * Printable values
 */
public interface Printable
{
	/**
	 * Make a nice string representation.
	 * Append it on the StringBuffer
	 */
	public void appendStringRepr( StringBuffer buf ) ;

	/**
	 * Make a string representation, to be used by appendStringRepr.
	 */
	//public void toStringBuffer( StringBuffer buf ) ;

}