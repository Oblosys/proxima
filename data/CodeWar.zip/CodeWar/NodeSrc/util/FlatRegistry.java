package skit.util ;

import com.objectspace.jgl.*;
import java.util.* ;
import skit.util.* ;
import skit.SkitException ;

/**
 * A Registry is a repository for resources with a name.
 * Besides that, if indicated a default value is maintained.
 * The default is either set explicitly under impl name "default" for a category,
 * or is the first resource added for a category.
 */
public class FlatRegistry
	implements Registry
{
	private Map resources ;
	private Map reverse ;
	private boolean hasDefault ;
	private String name ;
	
	private final static String STR_DEFAULT = "default".intern() ;
	
	public FlatRegistry( String nm, boolean df, boolean doReverse )
	{
		resources = new HashMap() ;
		reverse = doReverse ? new HashMap() : null ;
		hasDefault = df ;
		name = nm.intern() ;
	}
	
	/**
	 * Get the key for default value.
	 */
	public String getDefaultKey()
	{
		return STR_DEFAULT ;
	}
	
	
	/**
	 * Get the separator used, here none is used.
	 * @return	null.
	 */
	public String getSeparator()
	{
		return null ;
	}
	
	/**
	 * Get the size.
	 */
	private int getSize()
	{
		return resources.size() ;
	}
	
	/**
	 * Get the name of the registry
	 */
	public String getName( )
	{
		return name ;
	}
	
	private Object find( String key )
	{
		return resources.get( key ) ;
	}
	
	private void addResource( String key, Object r )
	{
		resources.put( key.intern(), r ) ;
		if ( reverse != null )
			reverse.put( r, key ) ;
			
	}
	
	/**
	 * Register the resource.
	 */
	public void register( String key, Object r )
	{
		if ( getSize() == 0 && hasDefault )
			registerAsDefault( null, r ) ;
		addResource( key, r ) ;
	}
	
	/**
	 * Register the resource as default.
	 */
	public void registerAsDefault( String withIn, Object r )
	{
		addResource( STR_DEFAULT, r ) ;
	}
	
	/**
	 * Find a resource.
	 * @return The resource, or null if none available.
	 */
	public Object resolve( String key )
	{
		Object res = find( key ) ;
		if ( res == null && hasDefault )
			res = find( STR_DEFAULT ) ;
		return res ;
	}
	
	/**
	 * Find key for resource.
	 */
	public String reverseResolve( Object r )
	{
		return reverse != null ? (String)reverse.get( r ) : null ;
	}
	
	/**
	 * @return An Enumeration of all available resource names.
	 */
	public Enumeration resourceKeys()
	{
		return resources.keys() ;
	}
		
	/**
	 * @return An Enumeration of all available resources.
	 */
	public Enumeration resources()
	{
		return resources.elements() ;
	}
		
	public String toString()
	{
		return "FlatRegistry " + getName() + ": " + resources.toString() ;
	}
		
}