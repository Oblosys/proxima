package skit.util ;

import java.util.* ;

/**
 * Empty enumeration
 */
public class EmptyEnumeration implements Enumeration
{
	public EmptyEnumeration()
	{
	}
	
	public boolean hasMoreElements()
	{
		return false ;
	}
	
	public Object nextElement()
	{
		return null ;
	}
}
