package skit.util ;

/**
 * Showing the progress.
 */
public interface Progress
{
	/**
	 * Start.
	 * @param	total	The amount to be done.
	 */
	public void start( int total, String what ) ;

	/**
	 * The fraction of change which causes a progress notification.
	 */
	public float getNotificationFraction(  ) ;

	/**
	 * Notify the fraction done.
	 */
	public void notify( float fractDone ) ;

	/**
	 * Stop.
	 */
	public void stop() ;

}
