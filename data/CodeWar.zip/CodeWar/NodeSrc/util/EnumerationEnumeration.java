package skit.util ;

import java.util.* ;

/**
 * Enumeration combining Enumeration of other Enumerations,
 * delivering first all the values of
 * the first one, then the second, and so on.
 */
public class EnumerationEnumeration implements Enumeration
{
	private Enumeration inEnums ;
	private Enumeration curEnum ;
	
	public EnumerationEnumeration( Enumeration enums )
	{
		inEnums = enums ;
		curEnum = inEnums.hasMoreElements()
					? (Enumeration)inEnums.nextElement()
					: new EmptyEnumeration() ;
		//findNext() ;
	}
	
	public void findNext()
	{
		while ( ( ! curEnum.hasMoreElements() ) && inEnums.hasMoreElements() )
		{
			curEnum = (Enumeration)inEnums.nextElement() ;
		}
	}
	
	public boolean hasMoreElements()
	{
		return curEnum.hasMoreElements() ;
	}
	
	public Object nextElement()
	{
		if ( hasMoreElements() )
		{
			Object res = curEnum.nextElement() ;
			//System.out.println( "ENUM ENUM " + res ) ;
			findNext() ;
			return res ;
		}
		else
			return null ;
	}

}
