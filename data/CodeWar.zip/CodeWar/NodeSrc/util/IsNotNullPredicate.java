package skit.util ;

/**
 * Check if value is not nul..
 * @see skit.util.Predicate
 * @see skit.util.EnumerationFilter
 */
public class IsNotNullPredicate implements Predicate
{
	public IsNotNullPredicate()
	{
	}
	
	public boolean predicate( Object v )
	{
		return v != null ;
	}
}

