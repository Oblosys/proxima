package skit.util ;

/**
 * Check if value matches.
 * @see skit.util.EnumerationFilter
 * @see skit.util.Predicate
 */
public class MatchPredicate implements Predicate
{
	private Matcher matcher ;
	private Object matchWith ;

	public MatchPredicate( Matcher m, Object o )
	{
		matcher = m ;
		matchWith = o ;
	}

	public boolean predicate( Object v )
	{
		return matcher.matchWith( v, matchWith ) ;
	}
}

