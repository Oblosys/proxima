package skit.util ;

import java.util.* ;

/**
 * "Words of a string" enumeration
 */
public class WordEnumeration implements Enumeration
{
	private StringTokenizer tokens ;

	public WordEnumeration( String s )
	{
		tokens = new StringTokenizer( s ) ;
	}

	public boolean hasMoreElements()
	{
		return tokens.hasMoreTokens() ;
	}

	public Object nextElement()
	{
		return tokens.nextToken() ;
	}
}
