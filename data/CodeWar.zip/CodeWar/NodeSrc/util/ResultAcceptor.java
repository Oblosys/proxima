package skit.util ;

/**
 * ResultAcceptor handles results, either as confirmation or cancellation
 */
public interface ResultAcceptor
{
	/**
	 * The result (data) is valid/confirmed
	 */
	void confirmResult( Object data ) ;

	/**
	 * The result (data) is invalid/canceled
	 */
	void cancelResult( Object data ) ;
}
