import skit.* ;
import skit.id.* ;
import skit.util.* ;
import skit.data.* ;
import skit.change.* ;
import skit.data.content.* ;
import skit.data.node.* ;
import skit.data.relation.* ;
import skit.factory.* ;
import skit.data.value.* ;
import skit.wrap.* ;
/*
   Test class for Skit Node Library
*/

public class Test
{

	public static void main(String args[]) 
	{
		System.out.println( "Skit Node Lib test facility" );
		
		try
		{
			Setup.init( new skit.data.store.StoreProgress() );
		
			SValue root = skit.Globals.getStorage().getCurrentStore().getRoot();
			SRelation defaultRelation = skit.Globals.getStorage().getCurrentStore().getDirectory();
			
			
			QuerySpec relationsqs = QuerySpec.from( "? \"Relations\" ?" );
			Query relationsQuery = defaultRelation.query( relationsqs ) ;
			SValue relations = relationsQuery.nextRelationship().at( 2 );
			
			
			System.out.println( "retrieving test relation by query" );
			
			QuerySpec relqs = QuerySpec.from( "? \"TestRel\" ?" );
			Query relQuery = defaultRelation.query( relqs ) ;
			SRelation retrievedRel = null;
			
			if ( relQuery.hasMoreElements() )
				retrievedRel = (SRelation)relQuery.nextRelationship().at( 2 );			
			
			if (retrievedRel == null)
			{
				System.out.println( "Relation not retrieved, creating" );
				RelationMetaInfo rmeta =
					new RelationMetaInfo
							( new SType( BasicSValue.nil() )
							, (SSequence)BasicSValue.from( "#(first second)" )
							, (SSequence)BasicSValue.from( "#(0)" )
							) ;
				SRelation newRelation = BasicSValue.newStoredRelation( rmeta, "root" ) ;
				
				/* adding to root node */				
				
				Relationship rship = defaultRelation.newEmptyRelationship();
				rship.updateAppend( root );
				rship.updateAppend( BasicSValue.newString( "TestRel" ) );
				rship.updateAppend( newRelation );
				
				// tupel (root, "TestRel", newRelation) toevoegen aan
				// default directory relation
				defaultRelation.add( rship, false );
	
				Relationship rship1 = newRelation.newEmptyRelationship();
				rship1.updateAppend( BasicSValue.newString( "parent" ) );
				rship1.updateAppend( BasicSValue.newString( "child" ) );
	
				// tupel ("parent", "child") toevoegen aan newRelation
				newRelation.add( rship1, false );
	
				System.out.println( "Added tuple to relation" );
	
			}
			else
			{
				System.out.println( "Successful, relation contains: ");
				System.out.println( "Relation is " + retrievedRel );
				System.out.println( "Relation is " + ((StorableSRelation)retrievedRel).getId() );
				
				
				// Dit gaat fout:
				
				System.out.println( "Dit gaat fout" );
				try
				{
					System.out.println( "type is"+retrievedRel.getType() );
					System.out.println( "Het is goed gegaan." );
				} 
			
				catch ( Exception ex )
				{
					System.out.println( "Het is fout gegaan." );
					ex.printStackTrace();
				}

				
				retrievedRel = patchSRelation( retrievedRel );

				// Nadat hij gepatched is gaat het wel goed.

				System.out.println( "Dit gaat goed" );				
				try
				{
					System.out.println( "type is"+retrievedRel.getType() );
					System.out.println( "Het is goed gegaan." );
				} 
			
				catch ( Exception ex )
				{
					System.out.println( "Het is fout gegaan." );
					ex.printStackTrace();
				}
	
			}
						
			Setup.fini();
		}
		catch ( Exception e ) 
		{
			
			System.out.println( "Skit Exception during testing." );
			e.printStackTrace();
			System.out.println( "Press the any key" );
			try { System.in.read(); } catch ( Exception e2 ) {}
			System.exit( 1 );
		}	
		
		
		
		System.out.println( "End of testing. Press return" );
		try { System.in.read(); } catch (java.io.IOException e) {}
	}
	
	static private SRelation patchSRelation( SRelation srel )
	{
		return new StorableSRelation( "root", (UniqueId)((StorableSRelation)srel).getId());

	}


/* Dirty relatie dump methoden

 	static public void dumpBRelation( SRelation relation )
 	{
 		try 
 		{
			QuerySpec allqs = QuerySpec.from( "? ?" );	
			Query allQuery = relation.query( allqs ) ;
			
			System.out.println( "Dump for binary relation : " + relation );
			while ( allQuery.hasMoreElements() ) 
			{
				Relationship rs = allQuery.nextRelationship();
					
				System.out.println( rs.at( 0 ) + " ---- " +
								    rs.at( 1 ) );				
			}
		} catch (Exception e) 
		{
			System.out.println( "dumpBRelation: SkitException" );
		}
 	}   

 	static public void dumpTRelation( SRelation relation )
 	{
 		try 
 		{
			QuerySpec allqs = QuerySpec.from( "? ? ?" );	
			Query allQuery = relation.query( allqs ) ;
			
			System.out.println( "Dump for ternary relation : " + relation );
			while ( allQuery.hasMoreElements() ) 
			{
				Relationship rs = allQuery.nextRelationship();
					
				System.out.println( rs.at( 0 ) + " ---- " +
								    rs.at( 1 ) + " ---- " +
							        rs.at( 2 ) );				
			}
		} catch (Exception e) 
		{
			System.out.println( "dumpTRelation: SkitException" );
		}
 	}   
*/	
}
