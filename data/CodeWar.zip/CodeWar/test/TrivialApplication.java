import com.sun.java.swing.*;
import java.awt.*;

/*
	Trivial application that displays a string - 4/96 PNL
*/

public class TrivialApplication
{

	public static void main(String args[]) 
	{
		JFrame testframe = new JFrame();
  	    JPanel panel = new JPanel(true);
	    testframe.getContentPane().add("Center",panel);
	    panel.setLayout(new BorderLayout());
        JLabel label = new JLabel("blablablabla");
        label.setSize(30,30);
        panel.add("Center", label);
        
		testframe.pack();
		testframe.show();
		System.out.println("v1");
	    try 
	    {
	        UIManager.setLookAndFeel("com.sun.java.swing.plaf.windows.WindowsLookAndFeel");
	  	} 	    
	    catch (Exception exc)        
	    {
			exc.printStackTrace();
			System.out.println(exc);
		}
	}
}
