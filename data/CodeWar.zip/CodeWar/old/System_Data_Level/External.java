//## //## Source file:  System_Data_Level/External.java
//## //## Subsystem:  System Data Level
//## //## Module: External

//##begin module.cm preserve=no
/*   %X% %Q% %Z% %W% */
//##end module.cm

//##begin module.cp preserve=no
//##end module.cp

package System_Data_Level;

//##begin module.additionalImports preserve=no
//##end module.additionalImports

//##begin module.imports preserve=yes
//##end module.imports

import System_Data_Level.JDK_Packages.Serializable;


// ==================================================================

//##begin module.declarations preserve=no
//##end module.declarations

//##begin module.additionalDeclarations preserve=yes
//##end module.additionalDeclarations

public interface External {
    //##begin External.initialDeclarations preserve=yes
    //##end External.initialDeclarations

    public Reference m_Reference;

    public void getValue();

    public void setValue();

    //##begin External.additionalDeclarations preserve=yes
    //##end External.additionalDeclarations

}

