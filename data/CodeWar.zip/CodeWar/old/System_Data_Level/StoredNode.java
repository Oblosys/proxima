//## //## Source file:  System_Data_Level/StoredNode.java
//## //## Subsystem:  System Data Level
//## //## Module: StoredNode

//##begin module.cm preserve=no
/*   %X% %Q% %Z% %W% */
//##end module.cm

//##begin module.cp preserve=no
//##end module.cp

package System_Data_Level;

//##begin module.additionalImports preserve=no
//##end module.additionalImports

//##begin module.imports preserve=yes
//##end module.imports



// ==================================================================

//##begin module.declarations preserve=no
//##end module.declarations

//##begin module.additionalDeclarations preserve=yes
//##end module.additionalDeclarations

public interface StoredNode extends Node {
    //##begin StoredNode.initialDeclarations preserve=yes
    //##end StoredNode.initialDeclarations



    //##begin StoredNode.additionalDeclarations preserve=yes
    //##end StoredNode.additionalDeclarations

}

