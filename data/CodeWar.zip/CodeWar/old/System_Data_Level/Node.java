//## //## Source file:  System_Data_Level/Node.java
//## //## Subsystem:  System Data Level
//## //## Module: Node

//##begin module.cm preserve=no
/*   %X% %Q% %Z% %W% */
//##end module.cm

//##begin module.cp preserve=no
//##end module.cp

package System_Data_Level;

//##begin module.additionalImports preserve=no
//##end module.additionalImports

//##begin module.imports preserve=yes
//##end module.imports

import System_Data_Level.JDK_Packages.Serializable;
import Skit_Data_Level.SkitObject;


// ==================================================================

//##begin module.declarations preserve=no
//##end module.declarations

//##begin module.additionalDeclarations preserve=yes
//##end module.additionalDeclarations

/**
Nodes bestaan in twee toestanden, 
expanded en collapsed. Collapsed houdt in dat alleen interne referenties
naar alle attributen ingeladen zijn, zonder dat de objecten voor
die attributen ingeladen zijn.. Expanded houdt in dat alle attributen
ingeladen zijn. Nodes worden expanded zodra een attribuut opgevraagd
wordt.

Hoe een attribuut wordt ingeladen is afhankelijk van het type
van het attribuut.

Is het een Node, dan wordt deze collapsed ingeladen.

Overige
objecten worden in hun geheel ingeladen. Dit betekent niet dat voor
een Reference ook het gerefereerde object wordt ingeladen, dat is
namelijk alleen aan te spreken m.b.v. de get en setValue operaties.

Bij
het aanspreken van een  Attribuut wordt ook onderscheid gemaakt op
basis van het type.
 
Bij Reference objecten wordt het resultaat van get en setValue
operaties opgelevert, terwijl bij alle andere objecten het attribuut
object zelf opgeleverd wordt.


*/
public interface Node extends Serializable {
    //##begin Node.initialDeclarations preserve=yes
    //##end Node.initialDeclarations

    Bool m_expanded;
    String m_nodeRef;
    public Attribute m_Attribute;
    public SkitObject m_SkitObject;
    public Vector m_Serializable = new Vector();

    void getAttribute( String);

    void setAttribute( String);

    void expand();
    Vector find_by_key(String Attribute) {
    //##begin Node::find_by_key.body preserve=yes
    //##end Node::find_by_key.body

    }

    //##begin Node.additionalDeclarations preserve=yes
    //##end Node.additionalDeclarations

}

