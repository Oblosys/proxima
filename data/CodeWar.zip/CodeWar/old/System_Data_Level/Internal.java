//## //## Source file:  System_Data_Level/Internal.java
//## //## Subsystem:  System Data Level
//## //## Module: Internal

//##begin module.cm preserve=no
/*   %X% %Q% %Z% %W% */
//##end module.cm

//##begin module.cp preserve=no
//##end module.cp

package System_Data_Level;

//##begin module.additionalImports preserve=no
//##end module.additionalImports

//##begin module.imports preserve=yes
//##end module.imports



// ==================================================================

//##begin module.declarations preserve=no
//##end module.declarations

//##begin module.additionalDeclarations preserve=yes
//##end module.additionalDeclarations

public interface Internal extends Attribute {
    //##begin Internal.initialDeclarations preserve=yes
    //##end Internal.initialDeclarations


    void getValue();

    void setValue();

    //##begin Internal.additionalDeclarations preserve=yes
    //##end Internal.additionalDeclarations

}

