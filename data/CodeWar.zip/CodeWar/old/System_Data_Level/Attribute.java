//## //## Source file:  System_Data_Level/Attribute.java
//## //## Subsystem:  System Data Level
//## //## Module: Attribute

//##begin module.cm preserve=no
/*   %X% %Q% %Z% %W% */
//##end module.cm

//##begin module.cp preserve=no
//##end module.cp

package System_Data_Level;

//##begin module.additionalImports preserve=no
//##end module.additionalImports

//##begin module.imports preserve=yes
//##end module.imports

import System_Data_Level.JDK_Packages.Serializable;


// ==================================================================

//##begin module.declarations preserve=no
//##end module.declarations

//##begin module.additionalDeclarations preserve=yes
//##end module.additionalDeclarations

public interface Attribute extends Serializable {
    //##begin Attribute.initialDeclarations preserve=yes
    //##end Attribute.initialDeclarations

    public Node m_Node;


    //##begin Attribute.additionalDeclarations preserve=yes
    //##end Attribute.additionalDeclarations

}

