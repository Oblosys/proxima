//## //## Source file:  Skit_Data_Level/SkitObject.java
//## //## Subsystem:  Skit Data Level
//## //## Module: SkitObject

//##begin module.cm preserve=no
/*   %X% %Q% %Z% %W% */
//##end module.cm

//##begin module.cp preserve=no
//##end module.cp

package Skit_Data_Level;

//##begin module.additionalImports preserve=no
//##end module.additionalImports

//##begin module.imports preserve=yes
//##end module.imports

import System_Data_Level.Node;
import Glue.BrowsableWrapper;
import Glue.VisibleWrapper;
import Glue.ManageableWrapper;


// ==================================================================

//##begin module.declarations preserve=no
//##end module.declarations

//##begin module.additionalDeclarations preserve=yes
//##end module.additionalDeclarations

public interface SkitObject {
    //##begin SkitObject.initialDeclarations preserve=yes
    //##end SkitObject.initialDeclarations

    public Node m_Node;
    public BrowsableWrapper m_BrowsableWrapper;
    public VisibleWrapper m_VisibleWrapper;
    public ManageableWrapper m_ManageableWrapper;


    //##begin SkitObject.additionalDeclarations preserve=yes
    //##end SkitObject.additionalDeclarations

}

