//## //## Source file:  Glue/Wrapper.java
//## //## Subsystem:  Glue
//## //## Module: Wrapper

//##begin module.cm preserve=no
/*   %X% %Q% %Z% %W% */
//##end module.cm

//##begin module.cp preserve=no
//##end module.cp

package Glue;

//##begin module.additionalImports preserve=no
//##end module.additionalImports

//##begin module.imports preserve=yes
//##end module.imports



// ==================================================================

//##begin module.declarations preserve=no
//##end module.declarations

//##begin module.additionalDeclarations preserve=yes
//##end module.additionalDeclarations

/**
Een Wrapper legt de link tussen een statische methode die  nodig
is om een interface te implementeren, en de dynamische attributen
van de Skit Objecten. 

Wrappers implementeren methodes door gebruik te maken van get
en setAttribute. Een VisibleWrapper kan bijvoorbeeld de getIcon methode
implementeren door een getAttribute("ICON") naar het bijbehorende
SkitObject te sturen.


*/
public interface Wrapper {
    //##begin Wrapper.initialDeclarations preserve=yes
    //##end Wrapper.initialDeclarations


    protected void getAttribute( String);

    protected void setAttribute();

    //##begin Wrapper.additionalDeclarations preserve=yes
    //##end Wrapper.additionalDeclarations

}

