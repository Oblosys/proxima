//## //## Source file:  Glue/VisibleWrapper.java
//## //## Subsystem:  Glue
//## //## Module: VisibleWrapper

//##begin module.cm preserve=no
/*   %X% %Q% %Z% %W% */
//##end module.cm

//##begin module.cp preserve=no
//##end module.cp

package Glue;

//##begin module.additionalImports preserve=no
//##end module.additionalImports

//##begin module.imports preserve=yes
//##end module.imports

import Visual_Interface.Visible;
import Skit_Data_Level.SkitObject;


// ==================================================================

//##begin module.declarations preserve=no
//##end module.declarations

//##begin module.additionalDeclarations preserve=yes
//##end module.additionalDeclarations

public interface VisibleWrapper extends Wrapper {
    //##begin VisibleWrapper.initialDeclarations preserve=yes
    //##end VisibleWrapper.initialDeclarations

    public SkitObject m_wrapped;

    void getIcon();

    void doubleClick();

    //##begin VisibleWrapper.additionalDeclarations preserve=yes
    //##end VisibleWrapper.additionalDeclarations

}

