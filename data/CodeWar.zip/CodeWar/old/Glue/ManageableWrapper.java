//## //## Source file:  Glue/ManageableWrapper.java
//## //## Subsystem:  Glue
//## //## Module: ManageableWrapper

//##begin module.cm preserve=no
/*   %X% %Q% %Z% %W% */
//##end module.cm

//##begin module.cp preserve=no
//##end module.cp

package Glue;

//##begin module.additionalImports preserve=no
//##end module.additionalImports

//##begin module.imports preserve=yes
//##end module.imports

import Visual_Interface.Manageable;
import Skit_Data_Level.SkitObject;


// ==================================================================

//##begin module.declarations preserve=no
//##end module.declarations

//##begin module.additionalDeclarations preserve=yes
//##end module.additionalDeclarations

public interface ManageableWrapper extends BrowsableWrapper {
    //##begin ManageableWrapper.initialDeclarations preserve=yes
    //##end ManageableWrapper.initialDeclarations

    public SkitObject m_wrapped;

    void setChildren();

    //##begin ManageableWrapper.additionalDeclarations preserve=yes
    //##end ManageableWrapper.additionalDeclarations

}

