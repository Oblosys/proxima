//## //## Source file:  Main/SkitMain.java
//## //## Module: SkitMain

//##begin module.cm preserve=no
/*   %X% %Q% %Z% %W% */
//##end module.cm

//##begin module.cp preserve=no
//##end module.cp

package Main;

//##begin module.additionalImports preserve=no
//##end module.additionalImports

//##begin module.imports preserve=yes
import com.sun.java.swing.*;
import java.io.*;
//##end module.imports



// ==================================================================

//##begin module.declarations preserve=no
//##end module.declarations

//##begin module.additionalDeclarations preserve=yes
//##end module.additionalDeclarations

public class SkitMain {
    //##begin SkitMain.initialDeclarations preserve=yes
    //##end SkitMain.initialDeclarations


    void main( String[] args) {
    //##begin SkitMain::main%349932E00082.body preserve=yes
    //##end SkitMain::main%349932E00082.body
      System.out.println("Un key, por favor");

      try
      {
        System.in.read();
      }
      catch (IOException e)
      {
      }
      System.out.println("Gracias");

   

    }

    //##begin SkitMain.additionalDeclarations preserve=yes
    //##end SkitMain.additionalDeclarations

}

