//## //## Source file:  Visual_Interface/Browsable.java
//## //## Subsystem:  Visual Interface
//## //## Module: Browsable

//##begin module.cm preserve=no
/*   %X% %Q% %Z% %W% */
//##end module.cm

//##begin module.cp preserve=no
//##end module.cp

package Visual_Interface;

//##begin module.additionalImports preserve=no
//##end module.additionalImports

//##begin module.imports preserve=yes
//##end module.imports



// ==================================================================

//##begin module.declarations preserve=no
//##end module.declarations

//##begin module.additionalDeclarations preserve=yes
//##end module.additionalDeclarations

/**
Browsable objecten bevatten kinderen die bekeken kunnen worden.
*/
public interface Browsable extends Visible {
    //##begin Browsable.initialDeclarations preserve=yes
    //##end Browsable.initialDeclarations

    public Vector m_Visible = new Vector();

    /**
    Representeert alle methoden die toegang tot child knopen geven. 
    
    */
    void getChildren();

    void getExpandedIcon();

    //##begin Browsable.additionalDeclarations preserve=yes
    //##end Browsable.additionalDeclarations

}

