//## //## Source file:  Visual_Interface/Manageable.java
//## //## Subsystem:  Visual Interface
//## //## Module: Manageable

//##begin module.cm preserve=no
/*   %X% %Q% %Z% %W% */
//##end module.cm

//##begin module.cp preserve=no
//##end module.cp

package Visual_Interface;

//##begin module.additionalImports preserve=no
//##end module.additionalImports

//##begin module.imports preserve=yes
//##end module.imports



// ==================================================================

//##begin module.declarations preserve=no
//##end module.declarations

//##begin module.additionalDeclarations preserve=yes
//##end module.additionalDeclarations

/**
Bij een Manageable object kunnen ook kinderen toegevoegd en verwijderd
worden.
*/
public interface Manageable extends Browsable {
    //##begin Manageable.initialDeclarations preserve=yes
    //##end Manageable.initialDeclarations


    /**
    Representeert alle methoden die child knopen kunnen toevoegen en
    verwijderen. Moet waarschijnlijk ook rekening houden met onderlinge
    posities van child knopen.
    */
    void setChildren();

    //##begin Manageable.additionalDeclarations preserve=yes
    //##end Manageable.additionalDeclarations

}

