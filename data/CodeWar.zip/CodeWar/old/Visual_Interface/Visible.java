//## //## Source file:  Visual_Interface/Visible.java
//## //## Subsystem:  Visual Interface
//## //## Module: Visible

//##begin module.cm preserve=no
/*   %X% %Q% %Z% %W% */
//##end module.cm

//##begin module.cp preserve=no
//##end module.cp

package Visual_Interface;

//##begin module.additionalImports preserve=no
//##end module.additionalImports

//##begin module.imports preserve=yes
//##end module.imports

import TreeBrowser_Interface.TreeBrowsable;


// ==================================================================

//##begin module.declarations preserve=no
//##end module.declarations

//##begin module.additionalDeclarations preserve=yes
//##end module.additionalDeclarations

/**
Visible objecten zijn zichtbaar in Browsers. doubleClick() is nog
niet helemaal duidelijk.
*/
public interface Visible {
    //##begin Visible.initialDeclarations preserve=yes
    //##end Visible.initialDeclarations

    public Browsable m_contains;

    void getIcon();

    void doubleClick();

    //##begin Visible.additionalDeclarations preserve=yes
    //##end Visible.additionalDeclarations

}

