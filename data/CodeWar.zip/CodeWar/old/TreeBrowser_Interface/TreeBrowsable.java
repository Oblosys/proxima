//## //## Source file:  TreeBrowser_Interface/TreeBrowsable.java
//## //## Subsystem:  TreeBrowser Interface
//## //## Module: TreeBrowsable

//##begin module.cm preserve=no
/*   %X% %Q% %Z% %W% */
//##end module.cm

//##begin module.cp preserve=no
//##end module.cp

package TreeBrowser_Interface;

//##begin module.additionalImports preserve=no
//##end module.additionalImports

//##begin module.imports preserve=yes
//##end module.imports

import TreeBrowser_Implementation.TreeBrowser;


// ==================================================================

//##begin module.declarations preserve=no
//##end module.declarations

//##begin module.additionalDeclarations preserve=yes
//##end module.additionalDeclarations

public interface TreeBrowsable {
    //##begin TreeBrowsable.initialDeclarations preserve=yes
    //##end TreeBrowsable.initialDeclarations

    public TreeBrowser m_TreeBrowser;

    void getCollapsedIcon();

    void getExpandedIcon();

    void getChildAt( Int);

    void insertChildAt( Int);

    void isLeaf();

    //##begin TreeBrowsable.additionalDeclarations preserve=yes
    //##end TreeBrowsable.additionalDeclarations

}

