//## //## Source file:  TreeBrowser_Implementation/SkitTreeNode.java
//## //## Subsystem:  TreeBrowser Implementation
//## //## Module: SkitTreeNode

//##begin module.cm preserve=no
/*   %X% %Q% %Z% %W% */
//##end module.cm

//##begin module.cp preserve=no
//##end module.cp

package TreeBrowser_Implementation;

//##begin module.additionalImports preserve=no
//##end module.additionalImports

//##begin module.imports preserve=yes
//##end module.imports

import TreeBrowser_Implementation.SWING_Packages.DefaultMutableTreeNode;


// ==================================================================

//##begin module.declarations preserve=no
//##end module.declarations

//##begin module.additionalDeclarations preserve=yes
//##end module.additionalDeclarations

public interface SkitTreeNode extends DefaultMutableTreeNode {
    //##begin SkitTreeNode.initialDeclarations preserve=yes
    //##end SkitTreeNode.initialDeclarations


    void getChildren();

    void getIcon();

    void getTextRep();

    void isLeaf();

    //##begin SkitTreeNode.additionalDeclarations preserve=yes
    //##end SkitTreeNode.additionalDeclarations

}

