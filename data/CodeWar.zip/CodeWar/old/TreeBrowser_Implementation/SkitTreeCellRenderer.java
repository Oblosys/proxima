//## //## Source file:  TreeBrowser_Implementation/SkitTreeCellRenderer.java
//## //## Subsystem:  TreeBrowser Implementation
//## //## Module: SkitTreeCellRenderer

//##begin module.cm preserve=no
/*   %X% %Q% %Z% %W% */
//##end module.cm

//##begin module.cp preserve=no
//##end module.cp

package TreeBrowser_Implementation;

//##begin module.additionalImports preserve=no
//##end module.additionalImports

//##begin module.imports preserve=yes
//##end module.imports

import TreeBrowser_Implementation.SWING_Packages.JLabel;


// ==================================================================

//##begin module.declarations preserve=no
//##end module.declarations

//##begin module.additionalDeclarations preserve=yes
//##end module.additionalDeclarations

/**
Bepaalt hoe de data in de tree op het scherm gezet zal worden
*/
public interface SkitTreeCellRenderer extends JLabel {
    //##begin SkitTreeCellRenderer.initialDeclarations preserve=yes
    //##end SkitTreeCellRenderer.initialDeclarations


    void paint();

    //##begin SkitTreeCellRenderer.additionalDeclarations preserve=yes
    //##end SkitTreeCellRenderer.additionalDeclarations

}

