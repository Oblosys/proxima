//## //## Source file:  TreeBrowser_Implementation/SkitTreeModel.java
//## //## Subsystem:  TreeBrowser Implementation
//## //## Module: SkitTreeModel

//##begin module.cm preserve=no
/*   %X% %Q% %Z% %W% */
//##end module.cm

//##begin module.cp preserve=no
//##end module.cp

package TreeBrowser_Implementation;

//##begin module.additionalImports preserve=no
//##end module.additionalImports

//##begin module.imports preserve=yes
//##end module.imports

import TreeBrowser_Implementation.SWING_Packages.DefaultTreeModel;


// ==================================================================

//##begin module.declarations preserve=no
//##end module.declarations

//##begin module.additionalDeclarations preserve=yes
//##end module.additionalDeclarations

public interface SkitTreeModel extends DefaultTreeModel {
    //##begin SkitTreeModel.initialDeclarations preserve=yes
    //##end SkitTreeModel.initialDeclarations

    public TreeBrowser m_TreeBrowser;


    //##begin SkitTreeModel.additionalDeclarations preserve=yes
    //##end SkitTreeModel.additionalDeclarations

}

